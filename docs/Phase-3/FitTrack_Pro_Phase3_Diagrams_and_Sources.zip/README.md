# FitTrack Pro – Phase 3 Software Design Document (CSAI 203, Fall 2026)

Team: Youssef Hassan Elsaid (202402456), Ali Elwakeel (202402383). Instructor: Dr. Mohamed Sami Rakha.
Status: design only. Nothing is implemented or tested. The technology stack is a proposal that requires team confirmation.

## Contents
| Path | What it is |
|---|---|
| FitTrack_Pro_Phase3_Design_Document.docx / .pdf | The SDD (DOCX has live TOC/figure fields; PDF rendered with Liberation Serif as a Times New Roman substitute) |
| FitTrack_Pro_Traceability_Matrix.xlsx | Sheet 1: FR-01..FR-24 -> controller, model/service, sequence diagram, UI, tables. Sheet 2: UC coverage |
| diagrams/ | Fig 1-16 and Fig 22 as PNG (architecture, MVC interaction, class diagrams, 8 sequence diagrams, ER) |
| wireframes/ | Fig 17-21 UI mockups (PNG). The prompt's "Figure 1-5" wireframes = document Figs 17-21 |
| diagram_sources/ | Editable sources: .dot/.svg (Graphviz), .mmd (Mermaid sequence), .html (class layer figures), ER SVG |
| wireframe_sources/ | HTML sources of the five mockups |
| code/ | Generators (gen_*.py), schema.py (single source for ER and dictionary), checks.py, build.py, schema.sql (DDL derived from the schema) |

## Figure numbering
1 architecture, 2 MVC interaction, 3-5 domain classes, 6 controllers, 7 services, 8 repositories/rules, 9-16 sequence diagrams (1A, 1B, 2, 3, 4, 5A, 5B, 6), 17-21 UI mockups, 22 ER diagram.

## Regenerate
Needs Graphviz, Mermaid CLI, headless Chrome, python-docx, openpyxl, LibreOffice. From code/: render diagrams (gen_*.py; `mmdc -c mmd_config.json -s 3 -i X.mmd -o X.png`), then `python3 build.py`.
