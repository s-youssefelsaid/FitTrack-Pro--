"""ER diagram (crow's foot) drawn as hand-routed orthogonal SVG from schema.py, so the ER and the data dictionary share one source."""
import subprocess, re
from schema import TABLES, RELS
ROOT="/home/claude/fittrack_sdd"; IMG=f"{ROOT}/img"; SRC=f"{ROOT}/src"
W,HH,RH=250,28,22
X={0:30,1:430,2:830,3:1230}
POS={ "weight_entries":(0,30),"workouts":(0,240),"exercise_entries":(0,440),"fitness_goals":(0,680),
 "reminders":(1,30),"users":(1,270),"smart_recommendations":(1,580),
 "foods":(2,30),"meal_entries":(2,300),
 "routine_shares":(3,30),"favorite_routines":(3,215),"workout_routines":(3,380),"routine_exercises":(3,610)}
T={n:(c) for n,_p,c in TABLES}
def box(n):
    cx,y=POS[n]; x=X[cx]; h=HH+RH*len(T[n]); return x,y,W,h
def rowy(n,col):
    x,y,w,h=box(n); i=[c[0] for c in T[n]].index(col); return y+HH+RH*(i+.5)
L=lambda n:box(n)[0]; R=lambda n:box(n)[0]+W; TOP=lambda n:box(n)[1]; BOT=lambda n:box(n)[1]+box(n)[3]
CX=lambda n:box(n)[0]+W/2
# path from child end to parent end
P={}
def rel(child,col,parent,pts): P[(child,col)]=pts
rel("fitness_goals","user_id","users",[(R("fitness_goals"),rowy("fitness_goals","user_id")),(330,rowy("fitness_goals","user_id")),(330,420),(L("users"),420)])
rel("workouts","user_id","users",[(R("workouts"),rowy("workouts","user_id")),(L("users"),rowy("workouts","user_id"))])
rel("exercise_entries","workout_id","workouts",[(CX("exercise_entries"),TOP("exercise_entries")),(CX("exercise_entries"),BOT("workouts"))])
rel("meal_entries","user_id","users",[(L("meal_entries"),rowy("meal_entries","user_id")),(R("users"),rowy("meal_entries","user_id"))])
rel("meal_entries","food_id","foods",[(CX("meal_entries")+40,TOP("meal_entries")),(CX("meal_entries")+40,BOT("foods"))])
rel("foods","owner_user_id","users",[(L("foods"),rowy("foods","owner_user_id")),(705,rowy("foods","owner_user_id")),(705,320),(R("users"),320)])
rel("weight_entries","user_id","users",[(R("weight_entries"),rowy("weight_entries","user_id")),(355,rowy("weight_entries","user_id")),(355,284),(L("users"),284)])
rel("workout_routines","user_id","users",[(L("workout_routines"),rowy("workout_routines","user_id")),(1170,rowy("workout_routines","user_id")),(1170,650),(730,650),(730,490),(R("users"),490)])
rel("routine_exercises","routine_id","workout_routines",[(CX("routine_exercises"),TOP("routine_exercises")),(CX("routine_exercises"),BOT("workout_routines"))])
rel("routine_shares","routine_id","workout_routines",[(R("routine_shares"),rowy("routine_shares","routine_id")),(1520,rowy("routine_shares","routine_id")),(1520,470),(R("workout_routines"),470)])
rel("routine_shares","recipient_user_id","users",[(L("routine_shares"),rowy("routine_shares","recipient_user_id")),(1110,rowy("routine_shares","recipient_user_id")),(1110,610),(770,610),(770,410),(R("users"),410)])
rel("favorite_routines","user_id","users",[(L("favorite_routines"),rowy("favorite_routines","user_id")),(1140,rowy("favorite_routines","user_id")),(1140,630),(750,630),(750,450),(R("users"),450)])
rel("favorite_routines","routine_id","workout_routines",[(CX("favorite_routines"),BOT("favorite_routines")),(CX("favorite_routines"),TOP("workout_routines"))])
rel("reminders","user_id","users",[(CX("reminders"),BOT("reminders")),(CX("reminders"),TOP("users"))])
rel("smart_recommendations","user_id","users",[(CX("smart_recommendations"),TOP("smart_recommendations")),(CX("smart_recommendations"),BOT("users"))])
rel("smart_recommendations","goal_id","fitness_goals",[(L("smart_recommendations"),rowy("smart_recommendations","goal_id")),(R("fitness_goals"),rowy("smart_recommendations","goal_id"))])
rel("smart_recommendations","routine_id","workout_routines",[(R("smart_recommendations"),rowy("smart_recommendations","routine_id")),(1200,rowy("smart_recommendations","routine_id")),(1200,520),(L("workout_routines"),520)])
# fix exact joins: routine_shares->routines enters right edge at 470 ; ok
INK="#2B2B2B"
def end_marker(x,y,p2,card):
    dx,dy=p2[0]-x,p2[1]-y; n=(dx*dx+dy*dy)**.5; dx,dy=dx/n,dy/n; px,py=-dy,dx
    s=""
    def line(a,b,c,d): return f'<line x1="{a:.1f}" y1="{b:.1f}" x2="{c:.1f}" y2="{d:.1f}" stroke="{INK}" stroke-width="1.6"/>'
    def bar(t): return line(x+dx*t+px*7,y+dy*t+py*7,x+dx*t-px*7,y+dy*t-py*7)
    def crow():
        t=14; return line(x+dx*t,y+dy*t,x+px*8,y+py*8)+line(x+dx*t,y+dy*t,x-px*8,y-py*8)+line(x+dx*t,y+dy*t,x,y)
    def circ(t): return f'<circle cx="{x+dx*t:.1f}" cy="{y+dy*t:.1f}" r="4.5" fill="#fff" stroke="{INK}" stroke-width="1.6"/>'
    if card=="1": s=bar(8)+bar(13)
    elif card=="0..1": s=bar(8)+circ(15)
    elif card in("0..*","0..10"): s=crow()+circ(20)
    elif card=="1..30": s=crow()+bar(19)
    # numeric text
    tx,ty=x+dx*30+px*(-11 if abs(dx)<.5 else 0)+ (0 if abs(dx)<.5 else 0), y+dy*30+py*(0)
    if abs(dx)>.5: tx,ty=x+dx*34,y+17
    else: tx,ty=x-11,y+dy*34+4
    s+=f'<text x="{tx:.1f}" y="{ty:.1f}" font-size="12" fill="#444" text-anchor="{"middle" if abs(dx)>.5 else "end"}">{card}</text>'
    return s
def table_svg(n):
    x,y,w,h=box(n); s=f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="#fff" stroke="#1E9A8E" stroke-width="2"/>'
    s+=f'<rect x="{x}" y="{y}" width="{w}" height="{HH}" fill="#1E9A8E"/><text x="{x+w/2}" y="{y+19}" text-anchor="middle" font-size="15" font-weight="700" fill="#fff">{n}</text>'
    for i,(c,t,k,cons,d) in enumerate(T[n]):
        yy=y+HH+RH*i; bg={"PK":"#FFF3C4","FK":"#E3F0FF","UQ":"#EDE3FF"}.get(k,"#fff")
        s+=f'<rect x="{x+1}" y="{yy}" width="{w-2}" height="{RH}" fill="{bg}"/>'
        if k: s+=f'<text x="{x+8}" y="{yy+15}" font-size="12" font-weight="700" fill="#222">{k}</text>'
        st=' font-style="italic"' if cons.startswith("NULL") else ""
        s+=f'<text x="{x+38}" y="{yy+15}" font-size="13.5" fill="#111"{st}>{c}</text>'
    return s
def build():
    body=""
    labels={}
    for r in RELS:
        ch,col,par,cc,pc,lab,od=r; pts=P[(ch,col)]
        body+=f'<polyline points="{" ".join(f"{a:.1f},{b:.1f}" for a,b in pts)}" fill="none" stroke="{INK}" stroke-width="1.5"/>'
    for r in RELS:
        ch,col,par,cc,pc,lab,od=r; pts=P[(ch,col)]
        body+=end_marker(pts[0][0],pts[0][1],pts[1],cc)+end_marker(pts[-1][0],pts[-1][1],pts[-2],pc)
        # verb label on the longest segment
        best=max(range(len(pts)-1),key=lambda i:abs(pts[i+1][0]-pts[i][0])+abs(pts[i+1][1]-pts[i][1]))
        a,b=pts[best],pts[best+1]; mx,my=(a[0]+b[0])/2,(a[1]+b[1])/2
        if abs(a[0]-b[0])>abs(a[1]-b[1]): body+=f'<text x="{mx:.1f}" y="{my-6:.1f}" font-size="11.5" fill="#1E6F66" text-anchor="middle" font-style="italic" paint-order="stroke" stroke="#fff" stroke-width="3">{lab}</text>'
        else: body+=f'<text x="{mx+6:.1f}" y="{my:.1f}" font-size="11.5" fill="#1E6F66" font-style="italic" paint-order="stroke" stroke="#fff" stroke-width="3">{lab}</text>'
    for n in POS: body+=table_svg(n)
    legend=('<g transform="translate(1230,830)" font-size="12" fill="#222"><text x="0" y="0" font-weight="700">Legend</text>'
      '<rect x="0" y="8" width="18" height="12" fill="#FFF3C4" stroke="#999"/><text x="26" y="18">PK primary key</text>'
      '<rect x="0" y="26" width="18" height="12" fill="#E3F0FF" stroke="#999"/><text x="26" y="36">FK foreign key</text>'
      '<rect x="0" y="44" width="18" height="12" fill="#EDE3FF" stroke="#999"/><text x="26" y="54">UQ unique (lower-case)</text>'
      '<text x="0" y="74" font-style="italic">italic = nullable column</text>'
      '<text x="0" y="92">Crow\'s foot ends show the cardinality</text><text x="0" y="108">of the entity at that end; text gives</text><text x="0" y="124">the same cardinality in numbers.</text></g>')
    VW,VH=1650,985
    svg=(f'<svg xmlns="http://www.w3.org/2000/svg" width="{VW}" height="{VH}" viewBox="0 0 {VW} {VH}" font-family="Liberation Sans, Arial, sans-serif">'
         f'<rect width="{VW}" height="{VH}" fill="#fff"/>{body}{legend}</svg>')
    open(f"{SRC}/fig22_er_diagram.svg","w").write(svg)
    open(f"{SRC}/ui/er.html","w").write(f"<!doctype html><html><body style='margin:0'>{svg}</body></html>")
    subprocess.run(["google-chrome","--headless=new","--no-sandbox","--disable-gpu","--hide-scrollbars",f"--window-size={VW},{VH}","--force-device-scale-factor=2",f"--screenshot={IMG}/fig22_er_diagram.png",f"file://{SRC}/ui/er.html"],check=True,capture_output=True)
build()
