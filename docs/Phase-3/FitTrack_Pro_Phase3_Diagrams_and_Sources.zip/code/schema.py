"""Single source of truth for the FitTrack Pro relational schema (proposed: PostgreSQL).
The ER diagram, the data dictionary and the SQL DDL are all generated from TABLES,
so they cannot disagree with each other."""

# column tuple: (name, type, key, nullability/default/check text, description)
# key: 'PK', 'FK', 'UQ', '' ; constraint text goes in the 4th element
TABLES = [
 ("users", "Registered accounts and profiles (FR-01 to FR-03).", [
  ("user_id", "BIGINT", "PK", "Identity, NOT NULL", "Surrogate key of the account."),
  ("full_name", "VARCHAR(60)", "", "NOT NULL; CHECK length 2-60", "Display name."),
  ("email", "VARCHAR(254)", "UQ", "NOT NULL; unique on lower(email)", "Login identifier, case-insensitive unique."),
  ("password_hash", "VARCHAR(255)", "", "NOT NULL", "Salted one-way hash; the plain password is never stored."),
  ("height_cm", "NUMERIC(4,1)", "", "NULL; CHECK 50-250", "Optional height."),
  ("preferred_routine_category", "VARCHAR(12)", "", "NULL; CHECK in routine categories", "Input to Smart Coach rules SR-01 and SR-04."),
  ("registration_date", "TIMESTAMPTZ", "", "NOT NULL; DEFAULT now()", "Account creation time."),
  ("failed_login_count", "SMALLINT", "", "NOT NULL; DEFAULT 0", "Consecutive failures inside the 15-minute window (FR-02). Design addition D-01."),
  ("failed_window_start", "TIMESTAMPTZ", "", "NULL", "Time of the first failure in the current 15-minute window (FR-02). Design addition D-01."),
  ("lockout_until", "TIMESTAMPTZ", "", "NULL", "Login refused until this instant (FR-02). Design addition D-01."),
 ]),
 ("fitness_goals", "Personal targets of four goal types (FR-04 to FR-06).", [
  ("goal_id", "BIGINT", "PK", "Identity, NOT NULL", "Surrogate key of the goal."),
  ("user_id", "BIGINT", "FK", "NOT NULL; FK users(user_id)", "Owner."),
  ("goal_type", "VARCHAR(10)", "", "NOT NULL; CHECK in CALORIES, FREQUENCY, DURATION, WEIGHT", "Goal type."),
  ("title", "VARCHAR(60)", "", "NOT NULL", "User-entered title."),
  ("target_value", "NUMERIC(8,2)", "", "NOT NULL; CHECK range per goal_type (FR-04 limits)", "kcal, sessions/week, minutes/week or kg."),
  ("unit", "VARCHAR(12)", "", "NOT NULL", "Unit label matching goal_type."),
  ("start_date", "DATE", "", "NOT NULL", "First day of the goal period."),
  ("end_date", "DATE", "", "NULL; CHECK end_date >= start_date", "Optional last day."),
  ("status", "VARCHAR(8)", "", "NOT NULL; DEFAULT 'ACTIVE'; CHECK in ACTIVE, INACTIVE", "Deactivated goals are kept, never erased."),
 ]),
 ("workouts", "Logged workout sessions (FR-07, FR-09).", [
  ("workout_id", "BIGINT", "PK", "Identity, NOT NULL", "Surrogate key of the session."),
  ("user_id", "BIGINT", "FK", "NOT NULL; FK users(user_id)", "Owner."),
  ("workout_date", "DATE", "", "NOT NULL", "Session date; not in the future (service rule CR-2)."),
  ("activity_type", "VARCHAR(16)", "", "NOT NULL; CHECK in the 8 activity types", "Fixed activity list."),
  ("duration_minutes", "SMALLINT", "", "NOT NULL; CHECK 1-600", "Duration."),
  ("notes", "VARCHAR(500)", "", "NULL", "Optional notes."),
 ]),
 ("exercise_entries", "Optional exercise details inside a workout (FR-08).", [
  ("exercise_id", "BIGINT", "PK", "Identity, NOT NULL", "Surrogate key of the entry."),
  ("workout_id", "BIGINT", "FK", "NOT NULL; FK workouts ON DELETE CASCADE", "Owning workout (composition)."),
  ("exercise_name", "VARCHAR(60)", "", "NOT NULL", "Exercise name."),
  ("sets", "SMALLINT", "", "NOT NULL; CHECK 1-20", "Number of sets."),
  ("repetitions", "SMALLINT", "", "NOT NULL; CHECK 1-200", "Repetitions per set."),
  ("resistance_kg", "NUMERIC(6,2)", "", "NULL; CHECK 0-1000", "Empty for body-weight exercises."),
  ("notes", "VARCHAR(200)", "", "NULL", "Optional notes."),
  ("sequence_number", "SMALLINT", "", "NOT NULL; UNIQUE (workout_id, sequence_number)", "Keeps entries in the order added. Design addition D-02."),
 ]),
 ("foods", "System foods and user-owned custom foods (FR-12).", [
  ("food_id", "BIGINT", "PK", "Identity, NOT NULL", "Surrogate key of the food."),
  ("food_name", "VARCHAR(60)", "", "NOT NULL", "Food name; duplicates per owner allowed after a warning."),
  ("serving_description", "VARCHAR(80)", "", "NOT NULL", "For example '1 cup cooked'."),
  ("calories_per_serving", "NUMERIC(7,2)", "", "NOT NULL; CHECK 0-5000", "Required nutrition value."),
  ("protein_g", "NUMERIC(6,2)", "", "NULL; CHECK 0-1000", "NULL means unknown, never zero."),
  ("carbs_g", "NUMERIC(6,2)", "", "NULL; CHECK 0-1000", "NULL means unknown."),
  ("fat_g", "NUMERIC(6,2)", "", "NULL; CHECK 0-1000", "NULL means unknown."),
  ("source", "VARCHAR(6)", "", "NOT NULL; CHECK in SYSTEM, CUSTOM", "Origin of the record."),
  ("owner_user_id", "BIGINT", "FK", "NULL; FK users(user_id); CHECK (source='SYSTEM') = (owner_user_id IS NULL)", "Owner of a custom food; NULL for system foods."),
 ]),
 ("meal_entries", "One food eaten in a meal, with a nutrition snapshot (FR-11, FR-13).", [
  ("meal_entry_id", "BIGINT", "PK", "Identity, NOT NULL", "Surrogate key of the entry."),
  ("user_id", "BIGINT", "FK", "NOT NULL; FK users(user_id)", "Owner."),
  ("food_id", "BIGINT", "FK", "NOT NULL; FK foods(food_id) ON DELETE RESTRICT", "Food used; foods referenced by meals cannot be removed."),
  ("meal_date", "DATE", "", "NOT NULL", "Date eaten; not in the future (service rule CR-2)."),
  ("meal_type", "VARCHAR(9)", "", "NOT NULL; CHECK in BREAKFAST, LUNCH, DINNER, SNACK", "Meal type."),
  ("serving_quantity", "NUMERIC(5,2)", "", "NOT NULL; CHECK 0.1-50", "Servings eaten."),
  ("estimated_calories", "NUMERIC(8,2)", "", "NOT NULL", "Snapshot: calories per serving x quantity at logging time."),
  ("estimated_protein_g", "NUMERIC(8,2)", "", "NULL", "Snapshot; NULL when the food had no protein value."),
  ("estimated_carbs_g", "NUMERIC(8,2)", "", "NULL", "Snapshot; NULL when unknown."),
  ("estimated_fat_g", "NUMERIC(8,2)", "", "NULL", "Snapshot; NULL when unknown."),
  ("nutrition_complete", "BOOLEAN", "", "NOT NULL", "TRUE when all three macronutrients were known."),
  ("notes", "VARCHAR(200)", "", "NULL", "Optional notes."),
 ]),
 ("weight_entries", "Body-weight measurements (FR-14).", [
  ("weight_id", "BIGINT", "PK", "Identity, NOT NULL", "Surrogate key of the measurement."),
  ("user_id", "BIGINT", "FK", "NOT NULL; FK users(user_id)", "Owner."),
  ("measurement_date", "DATE", "", "NOT NULL; UNIQUE (user_id, measurement_date)", "One entry per user per date."),
  ("weight_kg", "NUMERIC(4,1)", "", "NOT NULL; CHECK 20-400", "Body weight."),
  ("note", "VARCHAR(200)", "", "NULL", "Optional note."),
 ]),
 ("workout_routines", "Reusable routines, private by default (FR-18).", [
  ("routine_id", "BIGINT", "PK", "Identity, NOT NULL", "Surrogate key of the routine."),
  ("user_id", "BIGINT", "FK", "NOT NULL; FK users(user_id)", "Owner."),
  ("title", "VARCHAR(60)", "", "NOT NULL; CHECK length 3-60; UNIQUE (user_id, lower(title))", "Unique per owner (case-insensitive, D-05)."),
  ("category", "VARCHAR(12)", "", "NOT NULL; CHECK in STRENGTH, CARDIO, FLEXIBILITY, HIIT, MIXED, OTHER", "Routine category."),
  ("description", "VARCHAR(500)", "", "NULL", "Optional description."),
  ("created_at", "TIMESTAMPTZ", "", "NOT NULL; DEFAULT now()", "Creation time."),
  ("updated_at", "TIMESTAMPTZ", "", "NOT NULL; DEFAULT now()", "Last change time."),
 ]),
 ("routine_exercises", "Ordered planned exercises of a routine (FR-18).", [
  ("item_id", "BIGINT", "PK", "Identity, NOT NULL", "Surrogate key of the item."),
  ("routine_id", "BIGINT", "FK", "NOT NULL; FK workout_routines ON DELETE CASCADE", "Owning routine (composition)."),
  ("exercise_name", "VARCHAR(60)", "", "NOT NULL", "Exercise name."),
  ("target_sets", "SMALLINT", "", "NOT NULL; CHECK 1-20", "Planned sets."),
  ("target_repetitions", "SMALLINT", "", "NOT NULL; CHECK 1-200", "Planned repetitions."),
  ("target_resistance", "NUMERIC(6,2)", "", "NULL; CHECK 0-1000", "Planned resistance in kg."),
  ("sequence_number", "SMALLINT", "", "NOT NULL; UNIQUE (routine_id, sequence_number)", "Position in the routine; 1 to 30 items per routine (service rule)."),
 ]),
 ("routine_shares", "Read-only in-application grants (FR-20, FR-21).", [
  ("share_id", "BIGINT", "PK", "Identity, NOT NULL", "Surrogate key of the grant."),
  ("routine_id", "BIGINT", "FK", "NOT NULL; FK workout_routines ON DELETE CASCADE", "Shared routine."),
  ("recipient_user_id", "BIGINT", "FK", "NOT NULL; FK users(user_id)", "Recipient; never the owner (service rule)."),
  ("shared_at", "TIMESTAMPTZ", "", "NOT NULL; DEFAULT now()", "Grant time."),
  ("revoked_at", "TIMESTAMPTZ", "", "NULL", "NULL while active; set on revocation."),
 ]),
 ("favorite_routines", "Routines a user has starred (FR-19).", [
  ("favorite_id", "BIGINT", "PK", "Identity, NOT NULL", "Surrogate key of the favorite."),
  ("user_id", "BIGINT", "FK", "NOT NULL; FK users(user_id)", "User who starred the routine."),
  ("routine_id", "BIGINT", "FK", "NOT NULL; FK workout_routines ON DELETE CASCADE; UNIQUE (user_id, routine_id)", "Starred routine."),
  ("saved_at", "TIMESTAMPTZ", "", "NOT NULL; DEFAULT now()", "Time starred."),
 ]),
 ("reminders", "In-app workout and meal-logging reminders (FR-23).", [
  ("reminder_id", "BIGINT", "PK", "Identity, NOT NULL", "Surrogate key of the reminder."),
  ("user_id", "BIGINT", "FK", "NOT NULL; FK users(user_id)", "Owner; at most 10 per user (service rule)."),
  ("reminder_type", "VARCHAR(7)", "", "NOT NULL; CHECK in WORKOUT, MEAL", "Reminder type."),
  ("reminder_time", "TIME", "", "NOT NULL", "Time of day in the browser's local zone."),
  ("days_of_week", "SMALLINT", "", "NOT NULL; CHECK 1-127", "Bit mask Mon=1 ... Sun=64; at least one day."),
  ("label", "VARCHAR(60)", "", "NULL", "Optional label named in FR-23. Design addition D-03."),
  ("is_active", "BOOLEAN", "", "NOT NULL; DEFAULT TRUE", "Deactivated reminders never appear."),
 ]),
 ("smart_recommendations", "Stored, explainable Smart Coach output (FR-22).", [
  ("recommendation_id", "BIGINT", "PK", "Identity, NOT NULL", "Surrogate key."),
  ("user_id", "BIGINT", "FK", "NOT NULL; FK users(user_id)", "Recipient of the suggestion."),
  ("rule_id", "VARCHAR(5)", "", "NOT NULL; CHECK in SR-01 to SR-04", "Rule that produced it."),
  ("message", "VARCHAR(300)", "", "NOT NULL", "Suggestion text, with disclaimer added at display time."),
  ("explanation", "VARCHAR(600)", "", "NOT NULL", "'Why am I seeing this?' text: inputs and condition met."),
  ("created_at", "TIMESTAMPTZ", "", "NOT NULL; DEFAULT now()", "Creation time."),
  ("status", "VARCHAR(9)", "", "NOT NULL; DEFAULT 'ACTIVE'; CHECK in ACTIVE, DISMISSED, EXPIRED", "EXPIRED added by design (D-04)."),
  ("dismissed_at", "TIMESTAMPTZ", "", "NULL", "Starts the 14-day suppression. Design addition D-04."),
  ("goal_id", "BIGINT", "FK", "NULL; FK fitness_goals(goal_id)", "Optional referenced goal."),
  ("routine_id", "BIGINT", "FK", "NULL; FK workout_routines ON DELETE CASCADE", "Optional suggested routine."),
 ]),
]

# relationships: (child, child_col, parent, cardinality child side, parent side, label, ondelete)
RELS = [
 ("fitness_goals", "user_id", "users", "0..*", "1", "sets", ""),
 ("workouts", "user_id", "users", "0..*", "1", "logs", ""),
 ("exercise_entries", "workout_id", "workouts", "0..*", "1", "contains", "CASCADE"),
 ("meal_entries", "user_id", "users", "0..*", "1", "logs", ""),
 ("meal_entries", "food_id", "foods", "0..*", "1", "uses", "RESTRICT"),
 ("foods", "owner_user_id", "users", "0..*", "0..1", "owns custom", ""),
 ("weight_entries", "user_id", "users", "0..*", "1", "records", ""),
 ("workout_routines", "user_id", "users", "0..*", "1", "owns", ""),
 ("routine_exercises", "routine_id", "workout_routines", "1..30", "1", "contains", "CASCADE"),
 ("routine_shares", "routine_id", "workout_routines", "0..*", "1", "shared via", "CASCADE"),
 ("routine_shares", "recipient_user_id", "users", "0..*", "1", "receives", ""),
 ("favorite_routines", "user_id", "users", "0..*", "1", "stars", ""),
 ("favorite_routines", "routine_id", "workout_routines", "0..*", "1", "saved as", "CASCADE"),
 ("reminders", "user_id", "users", "0..10", "1", "schedules", ""),
 ("smart_recommendations", "user_id", "users", "0..*", "1", "receives", ""),
 ("smart_recommendations", "goal_id", "fitness_goals", "0..*", "0..1", "refers to", ""),
 ("smart_recommendations", "routine_id", "workout_routines", "0..*", "0..1", "suggests", "CASCADE"),
]

# Extra (non-column) constraints shown on the ER diagram and in the DDL
INDEXES = [
 ("uq_users_email", "users", "UNIQUE (lower(email))"),
 ("uq_goal_one_active_per_type", "fitness_goals", "UNIQUE (user_id, goal_type) WHERE status = 'ACTIVE'"),
 ("uq_share_one_active_per_pair", "routine_shares", "UNIQUE (routine_id, recipient_user_id) WHERE revoked_at IS NULL"),
 ("uq_routine_title_per_owner", "workout_routines", "UNIQUE (user_id, lower(title))"),
 ("ix_workouts_user_date", "workouts", "(user_id, workout_date DESC)"),
 ("ix_meals_user_date", "meal_entries", "(user_id, meal_date DESC)"),
 ("ix_shares_recipient", "routine_shares", "(recipient_user_id) WHERE revoked_at IS NULL"),
 ("ix_reco_user_rule", "smart_recommendations", "(user_id, rule_id, status)"),
 ("ix_foods_owner", "foods", "(owner_user_id)"),
]

def n_columns():
    return sum(len(t[2]) for t in TABLES)

def ddl():
    out = ["-- FitTrack Pro proposed PostgreSQL schema (generated from schema.py)", ""]
    for name, _purpose, cols in TABLES:
        out.append(f"CREATE TABLE {name} (")
        lines = []
        for c, t, k, cons, desc in cols:
            lines.append(f"  {c} {t}  -- {cons}")
        out.append(",\n".join(lines))
        out.append(");\n")
    for ix, tb, spec in INDEXES:
        kind = "UNIQUE INDEX" if spec.startswith("UNIQUE") else "INDEX"
        body = spec.replace("UNIQUE ", "", 1) if spec.startswith("UNIQUE") else spec
        out.append(f"CREATE {kind} {ix} ON {tb} {body};")
    return "\n".join(out)

if __name__ == "__main__":
    print(len(TABLES), "tables,", n_columns(), "columns,", len(RELS), "relationships")
