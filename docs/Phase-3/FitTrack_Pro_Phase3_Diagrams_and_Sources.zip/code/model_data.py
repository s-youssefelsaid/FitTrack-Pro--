"""Static design data shared by the DOCX, XLSX and README generators."""

FIGS = {  # key -> (number, final file name, source image, caption)
 "arch":   (1,  "Fig01_architecture_diagram",        "fig01_architecture.png", "Architecture diagram: modular monolith with MVC layers"),
 "mvc":    (2,  "Fig02_mvc_interaction_log_meal",    "fig02_mvc_interaction.png", "MVC interaction diagram for one request (Log a Meal)"),
 "dom1":   (3,  "Fig03_class_domain_account",        "fig03_class_domain_account.png", "Detailed design class diagram, part 1: account, goals, weight and reminders (Model entities)"),
 "dom2":   (4,  "Fig04_class_domain_tracking",       "fig04_class_domain_tracking.png", "Detailed design class diagram, part 2: workouts, exercises, meals and foods (Model entities)"),
 "dom3":   (5,  "Fig05_class_domain_routines_coach", "fig05_class_domain_routines_coach.png", "Detailed design class diagram, part 3: routines, sharing and Smart Coach output (Model entities)"),
 "ctl":    (6,  "Fig06_class_controllers",           "fig06_class_controllers.png", "Detailed design class diagram, part 4: Controller layer"),
 "svc":    (7,  "Fig07_class_services",              "fig07_class_services.png", "Detailed design class diagram, part 5: Model services and validator"),
 "repo":   (8,  "Fig08_class_repositories_rules",    "fig08_class_repositories_rules.png", "Detailed design class diagram, part 6: repositories and Smart Coach rule hierarchy"),
 "s1a":    (9,  "Fig09_seq_1A_register",             "seq01a_register.png", "Sequence diagram 1A: Register Account"),
 "s1b":    (10, "Fig10_seq_1B_login",                "seq01b_login.png", "Sequence diagram 1B: Log In (with lock-out check)"),
 "s2":     (11, "Fig11_seq_2_log_workout",           "seq02_workout.png", "Sequence diagram 2: Log Workout with exercise details"),
 "s3":     (12, "Fig12_seq_3_log_meal",              "seq03_meal.png", "Sequence diagram 3: Log Meal and calculate nutrition"),
 "s4":     (13, "Fig13_seq_4_dashboard",             "seq04_dashboard.png", "Sequence diagram 4: View Dashboard and goal progress"),
 "s5a":    (14, "Fig14_seq_5A_create_routine",       "seq05a_routine_create.png", "Sequence diagram 5A: Create Workout Routine"),
 "s5b":    (15, "Fig15_seq_5B_share_routine",        "seq05b_routine_share.png", "Sequence diagram 5B: Share and revoke a routine"),
 "s6":     (16, "Fig16_seq_6_smart_coach",           "seq06_coach.png", "Sequence diagram 6: Smart Coach recommendations"),
 "ui1":    (17, "Fig17_ui_login_registration",       "fig12_ui1_login_registration.png", "UI mockup 1: Login and Registration"),
 "ui2":    (18, "Fig18_ui_dashboard",                "fig13_ui2_dashboard.png", "UI mockup 2: Dashboard"),
 "ui3":    (19, "Fig19_ui_workout_logging",          "fig14_ui3_workout_logging.png", "UI mockup 3: Workout Logging"),
 "ui4":    (20, "Fig20_ui_meal_logging",             "fig15_ui4_meal_logging.png", "UI mockup 4: Meal Logging and Nutrition"),
 "ui5":    (21, "Fig21_ui_routines_sharing",         "fig16_ui5_routines_sharing.png", "UI mockup 5: Routines and Sharing"),
 "er":     (22, "Fig22_er_diagram",                  "fig22_er_diagram.png", "Entity-relationship diagram (13 tables)"),
}
def F(k): return FIGS[k][0]

# sources for editable diagram files (relative to src/)
SOURCES = {
 "arch": ["fig01_architecture.dot", "fig01_architecture.svg"],
 "mvc": ["fig02_mvc_interaction.dot", "fig02_mvc_interaction.svg"],
 "dom1": ["fig03_class_domain_account.dot", "fig03_class_domain_account.svg"],
 "dom2": ["fig04_class_domain_tracking.dot", "fig04_class_domain_tracking.svg"],
 "dom3": ["fig05_class_domain_routines_coach.dot", "fig05_class_domain_routines_coach.svg"],
 "ctl": ["ui/fig06_class_controllers.html"], "svc": ["ui/fig07_class_services.html"], "repo": ["ui/fig08_class_repositories_rules.html"],
 "s1a": ["seq01a_register.mmd"], "s1b": ["seq01b_login.mmd"], "s2": ["seq02_workout.mmd"], "s3": ["seq03_meal.mmd"],
 "s4": ["seq04_dashboard.mmd"], "s5a": ["seq05a_routine_create.mmd"], "s5b": ["seq05b_routine_share.mmd"], "s6": ["seq06_coach.mmd"],
 "ui1": ["ui/fig12_ui1_login_registration.html"], "ui2": ["ui/fig13_ui2_dashboard.html"], "ui3": ["ui/fig14_ui3_workout_logging.html"],
 "ui4": ["ui/fig15_ui4_meal_logging.html"], "ui5": ["ui/fig16_ui5_routines_sharing.html"],
 "er": ["fig22_er_diagram.svg"],
}

UCS = [  # id, name, actor
 ("UC-01","Register Account","Visitor"),("UC-02","Validate Input Data","Visitor / Registered User (included)"),("UC-03","Log In","Visitor"),
 ("UC-04","Log Out","Registered User"),("UC-05","Manage Profile","Registered User"),("UC-06","Manage Fitness Goals","Registered User"),
 ("UC-07","View Dashboard","Registered User"),("UC-08","Monitor Goal Progress","Registered User"),("UC-09","Select Date Range","Registered User"),
 ("UC-10","Log Workout","Registered User"),("UC-11","Record Exercise Details","Registered User"),("UC-12","Manage Workout Records","Registered User"),
 ("UC-13","View Activity History","Registered User"),("UC-14","Filter and Search Records","Registered User"),("UC-15","Log Meal","Registered User"),
 ("UC-16","Add Custom Food","Registered User"),("UC-17","Calculate Nutrition Totals","Registered User"),("UC-18","Record Weight Entry","Registered User"),
 ("UC-19","Generate Progress Report","Registered User"),("UC-20","Configure Reminders","Registered User"),("UC-21","Manage Workout Routines","Registered User"),
 ("UC-22","Save Favorite Routine","Registered User"),("UC-23","Share Routine","Registered User (owner)"),("UC-24","Revoke Routine Sharing","Registered User (owner)"),
 ("UC-25","Browse Shared Routines","Registered User"),("UC-26","View Smart Coach Recommendations","Registered User"),
 ("UC-27","Evaluate Smart Rules","Registered User (via UC-26)"),("UC-28","Copy Shared Routine","Registered User (recipient)"),
]
UC_COVER = {  # use case -> figure keys that draw it (or None) and note
 "UC-01":("s1a",""),"UC-02":("s1a","validate step in every form scenario (Figs 9, 11, 12, 14)"),"UC-03":("s1b",""),"UC-04":("s1b","alternative flow A4 in Table 'Sequence 1B'"),
 "UC-05":(None,"same validate, service, save pattern as Fig 9"),"UC-06":(None,"same pattern as Fig 14; read side in Fig 13"),
 "UC-07":("s4",""),"UC-08":("s4",""),"UC-09":("s4","range check step"),"UC-10":("s2",""),"UC-11":("s2",""),
 "UC-12":(None,"edit and delete reuse the path of Fig 11"),"UC-13":(None,"read pattern of Fig 13"),"UC-14":(None,"read pattern of Fig 13"),
 "UC-15":("s3",""),"UC-16":("s3","alternative flow A2"),"UC-17":("s3",""),"UC-18":(None,"same pattern as Fig 11"),
 "UC-19":(None,"computation as in Fig 13"),"UC-20":(None,"same pattern as Fig 11"),"UC-21":("s5a",""),"UC-22":("s5b","favorite removal on revoke"),
 "UC-23":("s5b",""),"UC-24":("s5b",""),"UC-25":(None,"read pattern of Fig 15"),"UC-26":("s6",""),"UC-27":("s6",""),"UC-28":(None,"creation path of Fig 14"),
}

# ---------------------------------------------------------------- traceability (FR -> design)
# FR, title, UCs, controller, model/service, sequence key(s) / note, ui key(s) / note, tables
TRACE = [
 ("FR-01","Register Account","UC-01, UC-02","AuthController.register","AuthService.register, User, UserRepository, InputValidator","s1a","ui1","users"),
 ("FR-02","Log In and Log Out","UC-03, UC-04","AuthController.login, logout","AuthService.authenticate, User.isLocked / verifyPassword / recordFailedLogin","s1b","ui1","users"),
 ("FR-03","View and Edit Profile","UC-02, UC-05","ProfileController.show, update","ProfileService, User, UserRepository, InputValidator","~Pattern of Fig {s1a} (validate, service, save)","~Profile page (not mocked up)","users"),
 ("FR-04","Create Fitness Goal","UC-02, UC-06","GoalController.create","GoalService.create, FitnessGoal, GoalRepository","~Pattern of Fig {s5a}","~Goals page (not mocked up)","fitness_goals"),
 ("FR-05","View, Edit and Deactivate Goals","UC-02, UC-06","GoalController.list, update, deactivate, reactivate","GoalService, FitnessGoal.deactivate / reactivate","~Pattern of Fig {s5a}","~Goals page (not mocked up)","fitness_goals"),
 ("FR-06","Monitor Goal Progress","UC-07, UC-08","DashboardController.show; GoalController.list","GoalProgressService.progress, FitnessGoal","s4","ui2","fitness_goals, workouts, meal_entries, weight_entries"),
 ("FR-07","Log Workout Session","UC-02, UC-10","WorkoutController.prefill, log","WorkoutService.log, Workout, WorkoutRepository, RoutineService (prefill)","s2","ui3","workouts, exercise_entries, workout_routines, routine_exercises (prefill read)"),
 ("FR-08","Record Exercise Details","UC-02, UC-11","WorkoutController.log","WorkoutService.log, ExerciseEntry.volume","s2","ui3","exercise_entries"),
 ("FR-09","Edit and Delete Workouts","UC-12","WorkoutController.edit, delete","WorkoutService.update / delete, WorkoutRepository","~Validate and save path of Fig {s2}","ui3","workouts, exercise_entries"),
 ("FR-10","Workout and Meal History with Filtering","UC-13, UC-14","HistoryController.workouts, meals","HistoryService, WorkoutRepository, MealRepository","~Read pattern of Fig {s4}","~Recent list in Fig {ui3}; History page not mocked up","workouts, exercise_entries, meal_entries, foods"),
 ("FR-11","Log Meals and Food Entries","UC-15","MealController.search, logMeal, editMeal, deleteMeal","NutritionService.logMeal, MealEntry.applySnapshot, Food.nutritionFor, MealRepository, FoodRepository","s3","ui4","meal_entries, foods"),
 ("FR-12","Food List and Custom Foods","UC-16","MealController.addCustomFood","NutritionService.addCustomFood, Food, FoodRepository","~Alternative flow A2 of Fig {s3}","ui4","foods"),
 ("FR-13","Nutrition Totals and Target Comparison","UC-15, UC-17","MealController.logMeal","NutritionService.dailyTotals, MealEntry, GoalRepository (calorie goal)","s3","ui4","meal_entries, fitness_goals"),
 ("FR-14","Weight Tracking","UC-18","WeightController.list, record, edit, delete","WeightService, WeightEntry, WeightRepository","~Pattern of Fig {s2}","~Weight page not mocked up; chart in Fig {ui2}","weight_entries"),
 ("FR-15","Dashboard Daily Summary and Empty States","UC-07, UC-08","DashboardController.show","DashboardService.summary, GoalProgressService, CalorieBurnService, ReminderService, SmartCoachService","s4","ui2","workouts, meal_entries, weight_entries, fitness_goals, reminders, smart_recommendations (read)"),
 ("FR-16","Weekly and Monthly Charts and Date-Range Summaries","UC-07, UC-09, UC-19","DashboardController.show","DashboardService.summary, DateRange","s4","ui2","workouts, meal_entries, weight_entries"),
 ("FR-17","Estimated Calories Burned","UC-07, UC-19","DashboardController.show; ReportController.generate","CalorieBurnService.estimate / totalFor, MET table (configuration), WeightRepository.latestOnOrBefore","s4","ui2","workouts, weight_entries"),
 ("FR-18","Create and Manage Workout Routines","UC-02, UC-21","RoutineController.create, edit, delete","RoutineService, WorkoutRoutine, RoutineExercise, RoutineRepository","s5a","ui5","workout_routines, routine_exercises, routine_shares, favorite_routines"),
 ("FR-19","Favorite Routines","UC-22","RoutineController.favorite","RoutineService.toggleFavorite, FavoriteRoutine, RoutineRepository","~Favorite removal on revoke in Fig {s5b}","ui5","favorite_routines"),
 ("FR-20","Share and Revoke Routine Sharing","UC-23, UC-24","RoutineController.share, revoke","RoutineService.share / revoke, RoutineShare, UserRepository.findByEmail","s5b","ui5","routine_shares, favorite_routines, users"),
 ("FR-21","Browse Shared Routines and Copy","UC-25, UC-28","RoutineController.list, copyShared","RoutineService.sharedWith / copyShared, WorkoutRoutine.copyFor","~Creation path of Fig {s5a}","ui5","routine_shares, workout_routines, routine_exercises"),
 ("FR-22","Rule-based Smart Coach","UC-26, UC-27","SmartCoachController.panel, dismiss, explain; DashboardController.show","SmartCoachService, SmartRuleEvaluator, SmartRule (SR-01 to SR-04), SmartRecommendation, RecommendationRepository","s6","ui2","smart_recommendations; reads workouts, fitness_goals, workout_routines, routine_shares, favorite_routines"),
 ("FR-23","Reminders","UC-20","ReminderController.list, create, edit, toggle, delete","ReminderService, Reminder.isDueAt, ReminderRepository","~Pattern of Fig {s2}","~Reminders page not mocked up; due notices in Fig {ui2}","reminders"),
 ("FR-24","Date-Range Progress Reports","UC-09, UC-14, UC-19","ReportController.generate","ReportService.build, CalorieBurnService, GoalProgressService","~Computation as in Fig {s4}","~Reports page not mocked up","workouts, meal_entries, weight_entries, fitness_goals (read; reports are not stored)"),
]

def fmt_seq(v):
    if v.startswith("~"): return v[1:].format(**{k: FIGS[k][0] for k in FIGS})
    return f"Figure {FIGS[v][0]}"
def fmt_ui(v):
    if v.startswith("~"): return v[1:].format(**{k: FIGS[k][0] for k in FIGS})
    return f"Figure {FIGS[v][0]} ({FIGS[v][3].replace('UI mockup ','').split(': ')[-1]})"

# FR -> UC from SRS (Related use cases)
FR_UCS = {t[0]: [u.strip() for u in t[2].split(",")] for t in TRACE}

# MVC mapping rows
MVC_ROWS = [
 ("Browser page templates: RegistrationLoginView, DashboardView (with Smart Coach panel and reminder notices), ProfileView, GoalView, WorkoutView, HistoryView, MealView, WeightView, RoutineView, ReportView, ReminderView","View","Render HTML from a view model, show inline field errors, empty states and flash messages, host the Chart.js charts. Contain no business rules."),
 ("Static assets: dark-theme CSS, Chart.js and small page scripts","View","Presentation only (layout, responsive behaviour, chart drawing from data already computed by the Model)."),
 ("BaseController (abstract)","Controller","Shared request handling: current user from the session, requireLogin, requireOwner, render, redirect, startSession, flash messages."),
 ("AuthController","Controller","Register, log in and log out requests; starts and ends the session (FR-01, FR-02)."),
 ("ProfileController, GoalController","Controller","Profile and goal forms; validation call; ownership check; choose view (FR-03 to FR-05)."),
 ("WorkoutController, HistoryController","Controller","Workout log, edit and delete; history filters and paging (FR-07 to FR-10)."),
 ("MealController, WeightController","Controller","Meal, custom food and weight forms (FR-11 to FR-14)."),
 ("DashboardController, ReportController","Controller","Read-only pages for a selected date range; check range, build view model (FR-06, FR-15 to FR-17, FR-24)."),
 ("RoutineController","Controller","Create, edit, delete, favorite, share, revoke and copy routines (FR-18 to FR-21)."),
 ("ReminderController, SmartCoachController","Controller","Reminder forms; Smart Coach panel, dismiss and explanation requests (FR-22, FR-23)."),
 ("InputValidator","Model (service)","Field rules shared by all forms: ranges, formats, dates, password strength. Called by controllers before a service is invoked."),
 ("AuthService, ProfileService","Model (service)","Account rules: duplicate e-mail, salted hashing, lock-out policy, profile update with current-password check."),
 ("GoalService, GoalProgressService","Model (service)","Goal limits and the one-active-goal-per-type rule; the four progress formulas of FR-06."),
 ("WorkoutService, CalorieBurnService, HistoryService","Model (service)","Workout and exercise rules, MET x weight x hours estimate, filtered paged history."),
 ("NutritionService","Model (service)","Nutrition snapshot at logging time, daily totals, custom foods, food visibility rule."),
 ("WeightService, DashboardService, ReportService","Model (service)","One entry per date, trend data, on-demand summaries and reports (never stored)."),
 ("RoutineService","Model (service)","Routine limits, owner-only change, read-only share, revoke with favorite removal, independent copy."),
 ("ReminderService, SmartCoachService, SmartRuleEvaluator","Model (service)","Maximum of 10 reminders, due-reminder query; rule evaluation, 14-day suppression, maximum of 3 recommendations, explanations."),
 ("SmartRule, SR01RoutineForGoal, SR02FrequencyDecline, SR03GoalReview, SR04CategoryMatch","Model (domain rule)","One class per rule SR-01 to SR-04; each tests its own condition and writes its explanation (Strategy pattern)."),
 ("User, FitnessGoal, Workout, ExerciseEntry, MealEntry, Food, WeightEntry","Model (entity)","Data and entity-level behaviour such as User.isLocked, MealEntry.applySnapshot, Food.nutritionFor, ExerciseEntry.volume."),
 ("WorkoutRoutine, RoutineExercise, RoutineShare, FavoriteRoutine, Reminder, SmartRecommendation","Model (entity)","Routine, sharing, reminder and recommendation data with their own rules (copyFor, revoke, isDueAt, dismiss)."),
 ("UserRepository, GoalRepository, WorkoutRepository, MealRepository, FoodRepository, WeightRepository, RoutineRepository, ReminderRepository, RecommendationRepository","Model (data access)","Only place where SQL or ORM queries appear; every query on user-owned data takes the owner id; one transaction per save."),
 ("Configuration: MET table, Smart Rule thresholds, validation limits, session timeout, lock-out policy","Model (configuration)","Named constants kept outside business code so values can be adjusted without rewriting logic (SRS A6, FR-22)."),
]
