import subprocess, os
ROOT = "/home/claude/fittrack_sdd"
UI = f"{ROOT}/src/ui"
IMG = f"{ROOT}/img"
os.makedirs(UI, exist_ok=True)

CSS = """
*{box-sizing:border-box;margin:0;padding:0}
:root{--bg:#0B0B0C;--s1:#141416;--s2:#1B1B1E;--bd:#2B2B30;--tx:#F3F3F1;--mu:#9B9BA3;--li:#B9F23B;--lid:#8DBF1F;--wa:#F5B93B;--re:#F26B5B}
body{background:var(--bg);color:var(--tx);font-family:'Inter','Liberation Sans',Arial,sans-serif;font-size:14px;line-height:1.35;width:1120px}
.app{display:flex;min-height:100vh}
.side{width:178px;background:var(--s1);border-right:1px solid var(--bd);padding:18px 12px;flex:none}
.logo{display:flex;align-items:center;gap:8px;font-weight:800;font-size:17px;margin:0 6px 22px}
.logo i{width:26px;height:26px;border-radius:7px;background:var(--li);display:inline-block;position:relative}
.logo i:after{content:"";position:absolute;left:8px;top:5px;width:9px;height:16px;background:var(--bg);clip-path:polygon(60% 0,0 58%,45% 58%,35% 100%,100% 38%,55% 38%)}
.logo b{color:var(--li)}
.nav a{display:flex;align-items:center;gap:9px;padding:9px 10px;border-radius:9px;color:var(--mu);font-weight:500;margin-bottom:2px}
.nav a:before{content:"";width:7px;height:7px;border-radius:2px;background:#3A3A40}
.nav a.on{background:rgba(185,242,59,.12);color:var(--li)}.nav a.on:before{background:var(--li)}
.main{flex:1;padding:20px 24px;min-width:0}
.top{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px}
h1{font-size:22px;font-weight:700}.sub{color:var(--mu);font-size:13px;margin-top:2px}
.av{width:34px;height:34px;border-radius:50%;background:var(--s2);border:1px solid var(--bd);display:flex;align-items:center;justify-content:center;font-weight:700;color:var(--li)}
.card{background:var(--s2);border:1px solid var(--bd);border-radius:14px;padding:14px 16px}
.card h3{font-size:13px;font-weight:600;color:var(--mu);text-transform:uppercase;letter-spacing:.04em;margin-bottom:8px}
.big{font-size:27px;font-weight:700}.mu{color:var(--mu)}.sm{font-size:12px}.li{color:var(--li)}
.grid{display:grid;gap:12px}.g4{grid-template-columns:repeat(4,1fr)}.g3{grid-template-columns:repeat(3,1fr)}.g2{grid-template-columns:1fr 1fr}
.chip{display:inline-block;padding:5px 11px;border-radius:999px;border:1px solid var(--bd);color:var(--mu);font-size:12.5px;margin-right:6px}
.chip.on{background:var(--li);color:#0B0B0C;border-color:var(--li);font-weight:600}
.tag{display:inline-block;padding:2px 8px;border-radius:6px;font-size:11.5px;font-weight:600}
.t-ok{background:rgba(185,242,59,.16);color:var(--li)}.t-warn{background:rgba(245,185,59,.16);color:var(--wa)}.t-bad{background:rgba(242,107,91,.16);color:var(--re)}.t-n{background:#2B2B30;color:var(--mu)}
.bar{height:8px;border-radius:6px;background:#2B2B30;overflow:hidden;margin:6px 0}.bar i{display:block;height:100%;background:var(--li);border-radius:6px}
.btn{display:inline-block;padding:10px 18px;border-radius:10px;font-weight:700;background:var(--li);color:#0B0B0C;text-align:center}
.btn.o{background:transparent;color:var(--tx);border:1px solid #44444B;font-weight:600}
.btn.sm{padding:6px 12px;font-size:12.5px;border-radius:8px}
label{display:block;font-size:12.5px;color:var(--mu);margin-bottom:5px;font-weight:500}
.in{background:var(--s1);border:1px solid var(--bd);border-radius:9px;padding:10px 12px;color:var(--tx);min-height:40px}
.in.err{border-color:var(--re)}.err-t{color:var(--re);font-size:12px;margin-top:4px}
.fld{margin-bottom:12px}
table{width:100%;border-collapse:collapse}th{font-size:11.5px;text-transform:uppercase;letter-spacing:.04em;color:var(--mu);text-align:left;padding:6px 8px;font-weight:600}
td{padding:8px;border-top:1px solid var(--bd)}
.note{color:var(--mu);font-size:11.5px;margin-top:10px}
svg{max-width:100%;height:auto}
svg text{font-family:'Inter','Liberation Sans',Arial,sans-serif}
"""

def page(body, name, w=1120, h=800):
    html = f"<!doctype html><html><head><meta charset='utf-8'><style>{CSS}</style></head><body>{body}</body></html>"
    p = f"{UI}/{name}.html"
    open(p, "w").write(html)
    out = f"{IMG}/{name}.png"
    subprocess.run(["google-chrome", "--headless=new", "--no-sandbox", "--disable-gpu", "--hide-scrollbars", f"--window-size={w},{h}",
                    "--force-device-scale-factor=2", f"--screenshot={out}", f"file://{p}"], check=True, capture_output=True)

NAV = ["Dashboard", "Goals", "Workouts", "Nutrition", "Weight", "Routines", "Reports", "Reminders", "Profile"]
def shell(active, title, sub, content, extra_top=""):
    nav = "".join(f'<a class="{"on" if n == active else ""}">{n}</a>' for n in NAV)
    return (f'<div class="app"><div class="side"><div class="logo"><i></i><span>Fit<b>Track</b> Pro</span></div><div class="nav">{nav}</div>'
            f'<div class="note" style="margin-top:26px;padding:0 8px">Log Out</div></div>'
            f'<div class="main"><div class="top"><div><h1>{title}</h1><div class="sub">{sub}</div></div><div style="display:flex;gap:10px;align-items:center">{extra_top}<div class="av">M</div></div></div>{content}</div></div>')

def bars(vals, labels, w=300, h=120, color="#B9F23B"):
    m = max(vals) or 1
    bw = (w - 20) / len(vals)
    s = f'<svg width="{w}" height="{h+22}" viewBox="0 0 {w} {h+22}">'
    for i in range(0, 4):
        y = 8 + i * (h - 8) / 3
        s += f'<line x1="0" x2="{w}" y1="{y:.0f}" y2="{y:.0f}" stroke="#2B2B30"/>'
    for i, v in enumerate(vals):
        bh = (h - 8) * v / m
        s += f'<rect x="{10 + i*bw + 6:.0f}" y="{h - bh:.0f}" width="{bw-12:.0f}" height="{bh:.0f}" rx="4" fill="{color}"/>'
        s += f'<text x="{10 + i*bw + bw/2:.0f}" y="{h+16}" font-size="11" fill="#9B9BA3" text-anchor="middle">{labels[i]}</text>'
    return s + "</svg>"

def line(vals, labels, w=300, h=120, target=None, lo=None, hi=None, color="#B9F23B"):
    lo = min(vals + ([target] if target else [])) * 0.95 if lo is None else lo
    hi = max(vals + ([target] if target else [])) * 1.05 if hi is None else hi
    def y(v): return h - (h - 12) * (v - lo) / (hi - lo)
    step = (w - 24) / (len(vals) - 1)
    pts = " ".join(f"{12 + i*step:.0f},{y(v):.0f}" for i, v in enumerate(vals))
    s = f'<svg width="{w}" height="{h+22}" viewBox="0 0 {w} {h+22}">'
    for i in range(0, 4):
        yy = 8 + i * (h - 8) / 3
        s += f'<line x1="0" x2="{w}" y1="{yy:.0f}" y2="{yy:.0f}" stroke="#2B2B30"/>'
    if target:
        s += f'<line x1="0" x2="{w}" y1="{y(target):.0f}" y2="{y(target):.0f}" stroke="#F5B93B" stroke-dasharray="5 4"/>'
        s += f'<text x="{w-2}" y="{y(target)-4:.0f}" font-size="10.5" fill="#F5B93B" text-anchor="end">target</text>'
    s += f'<polyline points="{pts}" fill="none" stroke="{color}" stroke-width="2.5" stroke-linejoin="round"/>'
    for i, v in enumerate(vals):
        s += f'<circle cx="{12 + i*step:.0f}" cy="{y(v):.0f}" r="3.5" fill="{color}"/>'
        s += f'<text x="{12 + i*step:.0f}" y="{h+16}" font-size="11" fill="#9B9BA3" text-anchor="middle">{labels[i]}</text>'
    return s + "</svg>"

DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

# ---------------------------------------------------------------- UI 1 login and registration
def ui1():
    body = '''<div style="min-height:780px;padding:34px 60px;background:radial-gradient(900px 400px at 50% -10%,rgba(185,242,59,.10),transparent)">
    <div style="text-align:center;margin-bottom:26px"><div class="logo" style="justify-content:center;font-size:26px"><i style="width:36px;height:36px"></i><span>Fit<b>Track</b> Pro</span></div>
    <div class="mu" style="margin-top:6px;font-size:15px">Smart Health &amp; Fitness Tracker. Log workouts, meals and weight. See your progress.</div></div>
    <div class="grid g2" style="gap:28px;align-items:start">
      <div class="card" style="padding:26px 28px"><h1 style="font-size:22px;margin-bottom:4px">Welcome back</h1><div class="sub" style="margin-bottom:18px">Log in to continue</div>
        <div class="fld"><label>Email</label><div class="in">mona@example.com</div></div>
        <div class="fld"><label>Password</label><div class="in" style="display:flex;justify-content:space-between"><span>&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;</span><span class="mu sm">Show</span></div></div>
        <div class="err-t" style="margin:-4px 0 12px">Email or password is incorrect.</div>
        <div class="btn" style="width:100%;padding:12px">Log In</div>
        <div class="mu" style="margin-top:14px;text-align:center">New to FitTrack Pro? <span class="li" style="font-weight:600">Sign up</span></div>
        <div class="note" style="text-align:center">After 5 failed attempts the account is locked for 15 minutes.</div></div>
      <div class="card" style="padding:26px 28px"><h1 style="font-size:22px;margin-bottom:4px">Create your account</h1><div class="sub" style="margin-bottom:18px">Free. Takes under a minute.</div>
        <div class="fld"><label>Full name</label><div class="in">Mona Hassan</div></div>
        <div class="fld"><label>Email</label><div class="in err">mona@example</div><div class="err-t">Enter a valid email address.</div></div>
        <div class="grid g2" style="gap:10px"><div class="fld"><label>Password</label><div class="in">&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;</div></div>
        <div class="fld"><label>Confirm password</label><div class="in">&bull;&bull;&bull;&bull;&bull;&bull;&bull;&bull;</div></div></div>
        <div class="note" style="margin:-6px 0 10px">At least 8 characters, with a letter and a digit.</div>
        <div class="fld"><label>Height in cm (optional)</label><div class="in mu">e.g. 170</div></div>
        <div class="btn" style="width:100%;padding:12px">Sign Up</div>
        <div class="mu" style="margin-top:14px;text-align:center">Already registered? <span class="li" style="font-weight:600">Log in</span></div></div>
    </div><div class="note" style="text-align:center;margin-top:22px">Goals are personal targets, not medical advice. Layout shown at desktop width; the two cards stack on phones.</div></div>'''
    page(body, "fig12_ui1_login_registration", h=730)

# ---------------------------------------------------------------- UI 2 dashboard
def ui2():
    chips = "".join(f'<span class="chip {"on" if i == 0 else ""}">{c}</span>' for i, c in enumerate(["This week", "Last 7 days", "This month", "Last 30 days", "Custom range"]))
    content = f'''
    <div style="margin-bottom:12px">{chips}<span class="mu sm" style="margin-left:6px">Mon 16 Nov to Sun 22 Nov</span></div>
    <div class="grid g4" style="margin-bottom:12px">
      <div class="card"><h3>Workouts today</h3><div class="big">1 <span class="mu" style="font-size:14px;font-weight:500">session</span></div><div class="sm mu">45 minutes total</div></div>
      <div class="card"><h3>Calories consumed</h3><div class="big">1,840 <span class="mu" style="font-size:14px;font-weight:500">/ 2,200 kcal</span></div><div class="bar"><i style="width:84%"></i></div><div class="sm mu">360 kcal remaining</div></div>
      <div class="card"><h3>Est. calories burned <span class="tag t-n" style="margin-left:4px">estimated</span></h3><div class="big">320 <span class="mu" style="font-size:14px;font-weight:500">kcal</span></div><div class="sm mu">1 workout left out: no MET value</div></div>
      <div class="card"><h3>Latest weight</h3><div class="big">78.4 <span class="mu" style="font-size:14px;font-weight:500">kg</span></div><div class="sm li">-0.6 kg since goal start</div></div>
    </div>
    <div class="grid g3" style="margin-bottom:12px">
      <div class="card"><h3>Workout minutes per day</h3>{bars([45,0,60,30,50,75,0], DAYS, 270, 100)}</div>
      <div class="card"><h3>Calories per day vs target</h3>{line([2050,2310,1980,2150,1840,2290,2100], DAYS, 270, 100, target=2200, lo=1700, hi=2500)}</div>
      <div class="card"><h3>Weight over time (kg)</h3>{line([79.4,79.1,78.9,78.8,78.4], ["W1","W2","W3","W4","W5"], 270, 100)}</div>
    </div>
    <div class="grid" style="grid-template-columns:1.05fr 1.25fr .9fr">
      <div class="card"><h3>Goal progress</h3>
        <div style="margin-bottom:9px"><div style="display:flex;justify-content:space-between"><b>Workouts per week</b><span class="tag t-ok">On track</span></div><div class="bar"><i style="width:75%"></i></div><div class="sm mu">3 of 4 sessions</div></div>
        <div style="margin-bottom:9px"><div style="display:flex;justify-content:space-between"><b>Daily calories</b><span class="tag t-warn">Behind</span></div><div class="bar"><i style="width:57%;background:var(--wa)"></i></div><div class="sm mu">4 of 7 days within 10% of target</div></div>
        <div><div style="display:flex;justify-content:space-between"><b>Target weight 76 kg</b><span class="tag t-n">Starts 1 Dec</span></div><div class="sm mu">Starts on 1 Dec</div></div></div>
      <div class="card"><h3>Smart Coach <span class="tag t-n" style="margin-left:4px">rule-based</span></h3>
        <div style="border:1px solid var(--bd);border-radius:10px;padding:9px 11px;margin-bottom:8px"><b>Try "Full Body A" this week</b><div class="sm mu">You are one session short of your weekly target.</div>
          <div class="sm" style="margin-top:5px"><span class="li">Why am I seeing this?</span> &nbsp; <span class="mu">Dismiss</span></div></div>
        <div style="border:1px solid var(--bd);border-radius:10px;padding:9px 11px"><b>Review your calorie goal</b><div class="sm mu">Average intake differed from target by 23% over 5 logged days.</div>
          <div class="sm" style="margin-top:5px"><span class="li">Why am I seeing this?</span> &nbsp; <span class="mu">Dismiss</span></div></div>
        <div class="note">Suggestions from your logged data only. Not medical advice.</div></div>
      <div class="card"><h3>Reminders due</h3><div style="border-left:3px solid var(--li);padding:4px 10px;margin-bottom:8px"><b>Log lunch</b><div class="sm mu">Meal reminder, 13:30</div></div>
        <div class="mu sm">No other reminders today.</div><div class="btn o sm" style="margin-top:12px">Manage reminders</div></div>
    </div>
    <div class="note">Illustrative sample data. Empty widgets show a message that names the missing record and links to the logging action.</div>'''
    page(shell("Dashboard", "Dashboard", "Saturday 21 November", content, '<div class="btn sm">+ Log Workout</div><div class="btn o sm">+ Log Meal</div>'), "fig13_ui2_dashboard", h=800)

# ---------------------------------------------------------------- UI 3 workout logging
def ui3():
    rows = [("Back squat", 4, 8, "80.0", "2,560"), ("Bench press", 3, 10, "60.0", "1,800"), ("Plank", 3, 1, "", "")]
    tr = "".join(f'<tr><td>{n}</td><td>{s}</td><td>{r}</td><td>{k or "<span class=mu>body weight</span>"}</td><td class="li">{v or "n/a"}</td><td class="mu">Remove</td></tr>' for n, s, r, k, v in rows)
    content = f'''<div class="grid" style="grid-template-columns:1.7fr 1fr">
    <div class="card"><h3>New workout</h3>
      <div class="grid" style="grid-template-columns:1fr 1.2fr 1fr;gap:12px">
        <div class="fld"><label>Workout date</label><div class="in">21 Nov 2026</div></div>
        <div class="fld"><label>Activity type</label><div class="in" style="display:flex;justify-content:space-between"><span>Strength Training</span><span class="mu">v</span></div></div>
        <div class="fld"><label>Duration (minutes)</label><div class="in">45</div></div></div>
      <div class="fld"><label>Notes (optional, up to 500 characters)</label><div class="in" style="min-height:56px">Felt strong, add 2.5 kg next week.</div></div>
      <div style="display:flex;justify-content:space-between;align-items:center;margin:14px 0 4px"><b>Exercise entries <span class="mu" style="font-weight:400">(optional)</span></b><span class="mu sm">Prefill from routine: <span class="li">Full Body A</span> (copied once)</span></div>
      <table><tr><th>Exercise</th><th>Sets</th><th>Reps</th><th>Resistance (kg)</th><th>Volume</th><th></th></tr>{tr}</table>
      <div class="btn o sm" style="margin-top:10px">+ Add exercise</div>
      <div class="note">Volume = sets x repetitions x resistance, shown for information only. Resistance may be empty for body-weight exercises.</div>
      <div style="display:flex;gap:10px;margin-top:16px"><div class="btn">Save Workout</div><div class="btn o">Cancel</div></div></div>
    <div class="card"><h3>This week</h3><div class="big">3 <span class="mu" style="font-size:14px;font-weight:500">sessions</span></div><div class="sm mu" style="margin-bottom:12px">Goal: 4 sessions (75%)</div><div class="bar"><i style="width:75%"></i></div>
      <h3 style="margin-top:18px">Recent workouts</h3>
      <div style="border-top:1px solid var(--bd);padding:8px 0"><b>Running</b> <span class="mu sm">Thu 19 Nov</span><div class="sm mu">30 min</div></div>
      <div style="border-top:1px solid var(--bd);padding:8px 0"><b>Yoga</b> <span class="mu sm">Tue 17 Nov</span><div class="sm mu">60 min</div></div>
      <div style="border-top:1px solid var(--bd);padding:8px 0"><b>Strength Training</b> <span class="mu sm">Mon 16 Nov</span><div class="sm mu">50 min &middot; <span class="li">Edit</span> &middot; <span class="mu">Delete</span></div></div>
      <div class="sm li" style="margin-top:6px">Open full history</div></div></div>
    <div class="note">Validation: date not after today, duration 1 to 600 minutes, sets 1 to 20, repetitions 1 to 200, resistance 0 to 1,000 kg. Errors appear beside the field and entered data is kept.</div>'''
    page(shell("Workouts", "Log Workout", "Record a session and optional exercise details", content), "fig14_ui3_workout_logging", h=660)

# ---------------------------------------------------------------- UI 4 meal logging
def ui4():
    seg = "".join(f'<span class="chip {"on" if m == "Lunch" else ""}">{m}</span>' for m in ["Breakfast", "Lunch", "Dinner", "Snack"])
    content = f'''<div class="grid" style="grid-template-columns:1.15fr 1fr">
    <div><div class="card" style="margin-bottom:12px"><h3>Add food to a meal</h3>
      <div class="grid g2" style="gap:12px"><div class="fld"><label>Date</label><div class="in">21 Nov 2026</div></div><div class="fld"><label>Meal type</label><div style="padding-top:2px">{seg}</div></div></div>
      <div class="fld"><label>Food (system list or your custom foods)</label><div class="in">Rice, cooked</div></div>
      <div style="border:1px solid var(--bd);border-radius:10px;margin:-6px 0 12px;overflow:hidden"><div style="padding:8px 12px;background:rgba(185,242,59,.08)">Rice, cooked <span class="mu sm">1 cup</span> <span class="tag t-n" style="float:right">System</span></div>
        <div style="padding:8px 12px;border-top:1px solid var(--bd)">Rice pudding (homemade) <span class="mu sm">1 bowl</span> <span class="tag t-ok" style="float:right">My food</span></div>
        <div style="padding:8px 12px;border-top:1px solid var(--bd)" class="mu sm">Not listed? <span class="li">Add Custom Food</span></div></div>
      <div class="fld" style="max-width:220px"><label>Serving quantity (0.1 to 50)</label><div class="in" style="display:flex;justify-content:space-between"><span>1.5</span><span class="mu">- &nbsp; +</span></div></div>
      <div class="grid g4" style="gap:8px;margin-bottom:12px">
        <div style="background:var(--s1);border-radius:10px;padding:9px"><div class="mu sm">Calories</div><div style="font-size:19px;font-weight:700">308</div><div class="mu sm">kcal</div></div>
        <div style="background:var(--s1);border-radius:10px;padding:9px"><div class="mu sm">Protein</div><div style="font-size:19px;font-weight:700">6.4</div><div class="mu sm">g</div></div>
        <div style="background:var(--s1);border-radius:10px;padding:9px"><div class="mu sm">Carbs</div><div style="font-size:19px;font-weight:700">67.5</div><div class="mu sm">g</div></div>
        <div style="background:var(--s1);border-radius:10px;padding:9px"><div class="mu sm">Fat</div><div style="font-size:19px;font-weight:700">0.7</div><div class="mu sm">g</div></div></div>
      <div class="note" style="margin:-4px 0 12px">Preview = values per serving x quantity. Saved with the entry as a snapshot.</div>
      <div style="display:flex;gap:10px"><div class="btn">Add to Meal</div><div class="btn o">Clear</div></div></div></div>
    <div><div class="card" style="margin-bottom:12px"><h3>Today's meals</h3>
      <table><tr><th>Meal</th><th>Food</th><th>Qty</th><th>kcal</th></tr>
      <tr><td>Breakfast</td><td>Oats with milk</td><td>1</td><td>350</td></tr>
      <tr><td>Lunch</td><td>Rice, cooked</td><td>1.5</td><td>308</td></tr>
      <tr><td>Lunch</td><td>Grilled chicken</td><td>1</td><td>165</td></tr>
      <tr><td>Snack</td><td>Rice pudding</td><td>1</td><td>260</td></tr></table>
      <div class="sm mu" style="margin-top:8px"><span class="li">Edit</span> or <span class="li">Delete</span> an entry (delete asks for confirmation)</div></div>
      <div class="card"><h3>Daily nutrition totals</h3><div class="big">1,083 <span class="mu" style="font-size:14px;font-weight:500">of 2,200 kcal goal</span></div><div class="bar"><i style="width:49%"></i></div>
        <div class="sm mu" style="margin-bottom:10px">1,117 kcal remaining</div>
        <div style="display:flex;gap:16px" class="sm"><span>Protein <b>58 g</b></span><span>Carbs <b>162 g</b></span><span>Fat <b>21 g</b></span></div>
        <div class="tag t-warn" style="margin-top:10px">Macros based on 3 of 4 entries</div></div></div></div>
    <div class="note">Illustrative sample data and nutrition values. Unknown macronutrients are left empty, never counted as zero, and the total says so.</div>'''
    page(shell("Nutrition", "Log Meal", "Foods eaten with serving quantities", content), "fig15_ui4_meal_logging", h=705)

# ---------------------------------------------------------------- UI 5 routines and sharing
def ui5():
    def rc(title, cat, n, star, own=True, by=""):
        acts = ('<span class="btn o sm">Edit</span> <span class="btn o sm">Share</span>' if own else '<span class="btn o sm">View</span> <span class="btn sm">Copy to My Routines</span>')
        meta = f'<div class="sm mu">{n} exercises' + (f' &middot; shared by {by} <span class="tag t-n">read-only</span>' if not own else ' &middot; <span class="tag t-n">private</span>') + '</div>'
        return (f'<div class="card"><div style="display:flex;justify-content:space-between"><b style="font-size:15px">{title}</b><span style="color:{"var(--li)" if star else "#55555C"};font-size:18px">&#9733;</span></div>'
                f'<div style="margin:6px 0"><span class="tag t-ok">{cat}</span></div>{meta}<div style="margin-top:10px">{acts}</div></div>')
    tabs = "".join(f'<span class="chip {"on" if i == 0 else ""}">{t}</span>' for i, t in enumerate(["My Routines", "Favorites", "Shared With Me"]))
    cats = "".join(f'<span class="chip {"on" if i == 0 else ""}" style="font-size:12px">{c}</span>' for i, c in enumerate(["All", "Strength", "Cardio", "Flexibility", "HIIT", "Mixed", "Other"]))
    content = f'''<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px"><div>{tabs}</div><div style="display:flex;gap:8px;align-items:center"><div class="in" style="min-height:34px;padding:6px 12px;width:170px" ><span class="mu">Search title</span></div><div class="btn sm">+ New Routine</div></div></div>
    <div style="margin-bottom:12px">{cats}</div>
    <div class="grid g3" style="margin-bottom:16px">{rc("Full Body A","Strength",6,True)}{rc("Morning Cardio","Cardio",3,False)}{rc("HIIT 20","HIIT",5,True)}</div>
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px"><h1 style="font-size:17px">Shared With Me</h1><span class="mu sm">Only active shares are listed</span></div>
    <div class="grid g3">{rc("Push Day","Strength",5,False,False,"Ahmed")}{rc("Mobility Flow","Flexibility",8,True,False,"Sara")}
      <div class="card" style="border-color:var(--li)"><h3 style="color:var(--li)">Share "Full Body A"</h3>
        <label>Recipient's registered e-mail</label><div class="in" style="margin-bottom:8px">sara@example.com</div><div class="btn sm">Share (read-only)</div>
        <div style="margin-top:10px;border-top:1px solid var(--bd);padding-top:8px" class="sm"><div style="display:flex;justify-content:space-between"><span>ahmed@example.com</span><span style="color:var(--re)">Revoke</span></div>
        <div style="display:flex;justify-content:space-between;margin-top:5px"><span>nour@example.com</span><span style="color:var(--re)">Revoke</span></div></div>
        <div class="note" style="margin-top:6px">In-application only. No public link, no e-mail sent.</div></div></div>'''
    page(shell("Routines", "Workout Routines", "Create, favorite, share and copy routines", content), "fig16_ui5_routines_sharing", h=570)

if __name__ == "__main__":
    ui1(); ui2(); ui3(); ui4(); ui5()
    from PIL import Image
    for f in sorted(os.listdir(IMG)):
        if f.startswith("fig1") and "ui" in f:
            print(f, Image.open(f"{IMG}/{f}").size)
