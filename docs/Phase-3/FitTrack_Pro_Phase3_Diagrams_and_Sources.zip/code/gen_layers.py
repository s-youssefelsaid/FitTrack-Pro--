import subprocess, os
ROOT="/home/claude/fittrack_sdd"; IMG=f"{ROOT}/img"; UI=f"{ROOT}/src/ui"
CSS="""*{box-sizing:border-box;margin:0;padding:0}body{font-family:'Liberation Sans',Arial,sans-serif;width:1000px;background:#fff;padding:10px;color:#111}
.grid{display:grid;gap:8px;align-items:start}.c3{grid-template-columns:repeat(3,1fr)}.c2{grid-template-columns:repeat(2,1fr)}
.k{border:1.5px solid var(--b);border-radius:4px;background:var(--f);font-size:10.3px;line-height:1.32;overflow:hidden}
.k h4{background:var(--b);color:#fff;font-size:12px;padding:3px 6px;text-align:center}
.k h4 small{display:block;font-weight:400;font-size:9px}
.k div{padding:3px 6px;font-family:'Liberation Mono','DejaVu Sans Mono',monospace;font-size:9.6px;white-space:normal;word-break:break-word}
.k div.u{font-family:'Liberation Sans',Arial,sans-serif;font-style:italic;border-top:1px solid var(--b);color:#333;white-space:normal;font-size:9.6px}
.ctl{--b:#D98A00;--f:#FFF3DC}.svc{--b:#7456D6;--f:#EEE9FF}.rep{--b:#1E9A8E;--f:#DDF4F1}.rul{--b:#6FA600;--f:#EDF7D6}.base{--b:#8A5A00;--f:#FFE7BF}
.band{font-weight:700;font-size:12px;margin:2px 0 6px;padding:3px 8px;background:#eee;border-left:5px solid #555}
.note{font-size:10.5px;color:#333;margin-top:6px}
"""
def K(cls,name,items,uses=None,stereo=None,ital=False):
    h=f"<h4>{'<small>&laquo;'+stereo+'&raquo;</small>' if stereo else ''}{'<i>'+name+'</i>' if ital else name}</h4>"
    b="".join(f"<div>{i}</div>" for i in items)
    u=f"<div class='u'>uses: {uses}</div>" if uses else ""
    return f"<div class='k {cls}'>{h}{b}{u}</div>"
def page(body,name,h):
    open(f"{UI}/{name}.html","w").write(f"<!doctype html><html><head><meta charset='utf-8'><style>{CSS}</style></head><body>{body}</body></html>")
    subprocess.run(["google-chrome","--headless=new","--no-sandbox","--disable-gpu","--hide-scrollbars",f"--window-size=1020,{h}","--force-device-scale-factor=2.5",f"--screenshot={IMG}/{name}.png",f"file://{UI}/{name}.html"],check=True,capture_output=True)

# ---- controllers
C=[("AuthController",["+register(f: RegisterForm): Response","+login(f: LoginForm): Response","+logout(): Response"],"AuthService"),
("ProfileController",["+show(): Response","+update(f: ProfileForm): Response"],"ProfileService"),
("GoalController",["+list(): Response","+create(f: GoalForm): Response","+update(id: Long, f: GoalForm): Response","+deactivate(id: Long): Response","+reactivate(id: Long): Response"],"GoalService, GoalProgressService"),
("WorkoutController",["+prefill(routineId: Long): Response","+log(f: WorkoutForm): Response","+edit(id: Long, f: WorkoutForm): Response","+delete(id: Long): Response"],"WorkoutService, RoutineService"),
("MealController",["+search(q: String): Response","+logMeal(f: MealForm): Response","+editMeal(id: Long, f: MealForm): Response","+deleteMeal(id: Long): Response","+addCustomFood(f: FoodForm): Response"],"NutritionService"),
("WeightController",["+list(): Response","+record(f: WeightForm): Response","+edit(id: Long, f: WeightForm): Response","+delete(id: Long): Response"],"WeightService"),
("HistoryController",["+workouts(f: HistoryFilter, page: int): Response","+meals(f: HistoryFilter, page: int): Response"],"HistoryService"),
("DashboardController",["+show(day: Date, range: DateRange): Response"],"DashboardService, SmartCoachService"),
("ReportController",["+generate(range: DateRange): Response"],"ReportService"),
("RoutineController",["+list(): Response","+create(f: RoutineForm): Response","+edit(id: Long, f: RoutineForm): Response","+delete(id: Long): Response","+share(id: Long, email: String): Response","+revoke(shareId: Long): Response","+favorite(id: Long): Response","+copyShared(id: Long): Response"],"RoutineService"),
("ReminderController",["+list(): Response","+create(f: ReminderForm): Response","+edit(id: Long, f: ReminderForm): Response","+toggle(id: Long): Response","+delete(id: Long): Response"],"ReminderService"),
("SmartCoachController",["+panel(): Response","+dismiss(recId: Long): Response","+explain(recId: Long): Response"],"SmartCoachService")]
def ctl():
    base=K("base","BaseController",["#currentUser(): User","#requireLogin(): void","#requireOwner(res: Ownable, u: User): void","#render(view: String, vm: ViewModel): Response","#redirect(url: String): Response","#startSession(userId: Long): void","#flash(msg: String): void"],None,"abstract",True)
    cards="".join(K("ctl",n,m,u) for n,m,u in C)
    body=f"<div class='band'>Controller layer: every controller extends BaseController (generalisation) and depends on the services listed under &laquo;uses&raquo;</div><div style='width:50%;margin:0 auto 8px'>{base}</div><div class='note' style='text-align:center;margin:-2px 0 8px'>&#9651; each controller below inherits from BaseController</div><div class='grid c3'>{cards}</div><div class='note'>Controllers read the signed session, validate forms (via InputValidator in the Model), check ownership, call one service method per use case and choose a view. They contain no business rules and no SQL.</div>"
    page(body,"fig06_class_controllers",815)
# ---- services
S=[("AuthService",["+register(d: RegistrationData): User","+authenticate(email: String, pw: String): User","+hashPassword(plain: String): String"],"UserRepository"),
("ProfileService",["+getProfile(uid: Long): User","+update(uid: Long, d: ProfileData): User"],"UserRepository"),
("GoalService",["+create(uid: Long, d: GoalData): FitnessGoal","+update(uid, gid, d): FitnessGoal","+deactivate(uid, gid): void","+reactivate(uid, gid): void","+listFor(uid: Long): List&lt;FitnessGoal&gt;"],"GoalRepository"),
("GoalProgressService",["+progress(goals: List&lt;FitnessGoal&gt;, today: Date): List&lt;GoalProgress&gt;"],"GoalRepository, WorkoutRepository, MealRepository, WeightRepository"),
("WorkoutService",["+log(uid: Long, d: WorkoutData): Workout","+update(uid, wid, d): Workout","+delete(uid, wid): void","+history(uid, f, page): Page&lt;Workout&gt;"],"WorkoutRepository, CalorieBurnService"),
("CalorieBurnService",["+estimate(w: Workout, weightKg: Decimal): Decimal?","+totalFor(ws: List&lt;Workout&gt;, weightKg: Decimal): BurnTotal"],"MET table (configuration)"),
("NutritionService",["+logMeal(uid: Long, d: MealData): MealEntry","+updateMeal(uid, mid, d): MealEntry","+deleteMeal(uid, mid): void","+dailyTotals(uid, date): DailyNutrition","+addCustomFood(uid, d: FoodData): Food","+searchFoods(uid, q): List&lt;Food&gt;"],"MealRepository, FoodRepository"),
("WeightService",["+record(uid: Long, d: WeightData): WeightEntry","+update(uid, id, d): WeightEntry","+delete(uid, id): void","+trend(uid, r: DateRange): List&lt;WeightEntry&gt;"],"WeightRepository"),
("HistoryService",["+workoutHistory(uid, f, page): Page&lt;Workout&gt;","+mealHistory(uid, f, page): Page&lt;MealEntry&gt;"],"WorkoutRepository, MealRepository"),
("DashboardService",["+summary(user: User, day: Date, r: DateRange): DashboardData"],"WorkoutRepository, MealRepository, WeightRepository, GoalProgressService, CalorieBurnService, ReminderService"),
("ReportService",["+build(uid: Long, r: DateRange): Report"],"WorkoutRepository, MealRepository, WeightRepository, CalorieBurnService"),
("RoutineService",["+create(uid, d: RoutineData): WorkoutRoutine","+update(uid, rid, d): WorkoutRoutine","+delete(uid, rid): void","+share(uid, rid, email): RoutineShare","+revoke(uid, shareId): void","+toggleFavorite(uid, rid): void","+copyShared(uid, rid): WorkoutRoutine","+sharedWith(uid): List&lt;WorkoutRoutine&gt;"],"RoutineRepository, UserRepository"),
("ReminderService",["+create(uid, d: ReminderData): Reminder","+update(uid, id, d): Reminder","+toggle(uid, id): void","+delete(uid, id): void","+dueNow(uid, now): List&lt;Reminder&gt;"],"ReminderRepository"),
("SmartCoachService",["+recommendations(user: User, now: DateTime): List&lt;SmartRecommendation&gt;","+dismiss(user, recId): void","+explain(user, recId): String"],"SmartRuleEvaluator, RecommendationRepository"),
("SmartRuleEvaluator",["+evaluateAll(user: User, now: DateTime): List&lt;Draft&gt;","-buildContext(user, now): CoachContext"],"SmartRule (4 strategies), WorkoutRepository, RoutineRepository, GoalRepository"),
("InputValidator",["+validate(d: FormData, rules: RuleSet): ValidationResult","+isFutureDate(d: Date, today: Date): boolean","+isEmail(s: String): boolean","+isStrongPassword(s: String): boolean"],None)]
def svc():
    cards="".join(K("svc",n,m,u) for n,m,u in S)
    body=f"<div class='band'>Model layer: application and domain services (each method is one use-case step; a service owns the transaction boundary)</div><div class='grid c3'>{cards}</div><div class='note'>Services depend only on repositories, other services listed under &laquo;uses&raquo;, and configuration constants; they never reference controllers or views.</div>"
    page(body,"fig07_class_services",960)
# ---- repos + rules
R=[("UserRepository",["+findById(id: Long): User?","+findByEmail(e: String): User?","+save(u: User): User","+updateLockout(u: User): void"]),
("GoalRepository",["+findByUser(uid: Long): List&lt;FitnessGoal&gt;","+findActive(uid, type): FitnessGoal?","+save(g: FitnessGoal): FitnessGoal"]),
("WorkoutRepository",["+save(w: Workout): Workout","+findById(id: Long): Workout?","+findInRange(uid, r): List&lt;Workout&gt;","+findByUser(uid, f, page): Page&lt;Workout&gt;","+delete(w: Workout): void"]),
("MealRepository",["+save(m: MealEntry): MealEntry","+findByDay(uid, d): List&lt;MealEntry&gt;","+findInRange(uid, r): List&lt;MealEntry&gt;","+findByUser(uid, f, page): Page&lt;MealEntry&gt;","+delete(m: MealEntry): void"]),
("FoodRepository",["+search(uid: Long, q: String): List&lt;Food&gt;","+findVisible(foodId, uid): Food?","+save(f: Food): Food"]),
("WeightRepository",["+save(e: WeightEntry): WeightEntry","+findByUserAndDate(uid, d): WeightEntry?","+latestOnOrBefore(uid, d): WeightEntry?","+findByUser(uid, r): List&lt;WeightEntry&gt;","+delete(e: WeightEntry): void"]),
("RoutineRepository",["+save(r: WorkoutRoutine): WorkoutRoutine","+findOwned(routineId, ownerId): WorkoutRoutine?","+findVisibleTo(uid: Long): List&lt;WorkoutRoutine&gt;","+addShare(s: RoutineShare): RoutineShare","+removeFavoritesFor(rid, uid): void","+toggleFavorite(uid, rid): void"]),
("ReminderRepository",["+save(r: Reminder): Reminder","+findByUser(uid: Long): List&lt;Reminder&gt;","+countByUser(uid: Long): int","+delete(r: Reminder): void"]),
("RecommendationRepository",["+findActive(uid: Long): List&lt;SmartRecommendation&gt;","+recentDismissed(uid, days): List&lt;SmartRecommendation&gt;","+save(r: SmartRecommendation): void","+expireStale(uid): void"])]
RU=[("SR01RoutineForGoal",["+evaluate(ctx): Candidate?"]),("SR02FrequencyDecline",["+evaluate(ctx): Candidate?"]),("SR03GoalReview",["+evaluate(ctx): Candidate?"]),("SR04CategoryMatch",["+evaluate(ctx): Candidate?"])]
def repo():
    rp="".join(K("rep",n,m,None,"repository") for n,m in R)
    abs_=K("rul","SmartRule",["+ruleId(): String","+evaluate(ctx: CoachContext): Candidate?","#explain(ctx): String"],None,"abstract",True)
    rl="".join(K("rul",n,m) for n,m in RU)
    body=f"<div class='band'>Model layer: data access (repositories, one per aggregate; SQL stays inside this sub-layer)</div><div class='grid c3'>{rp}</div><div class='band' style='margin-top:12px'>Model layer: Smart Coach rule hierarchy (Strategy pattern, rule-based, no machine learning)</div><div style='width:42%;margin:0 auto 4px'>{abs_}</div><div class='note' style='text-align:center'>&#9651; SR01 to SR04 specialise SmartRule; SmartRuleEvaluator holds one instance of each</div><div class='grid' style='grid-template-columns:repeat(4,1fr);margin-top:4px'>{rl}</div><div class='note'>SR01: routine suggestion for a goal. SR02: decline in workout frequency. SR03: goal review. SR04: category match with the preferred routine category. Thresholds are named constants (Design Decision D-06).</div>"
    page(body,"fig08_class_repositories_rules",655)
ctl(); svc(); repo()
from PIL import Image
for f in ["fig06_class_controllers","fig07_class_services","fig08_class_repositories_rules"]:
    print(f,Image.open(f"{IMG}/{f}.png").size)
