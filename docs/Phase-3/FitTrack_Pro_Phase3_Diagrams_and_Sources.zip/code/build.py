import subprocess, re, os, sys, shutil
sys.path.insert(0, "/home/claude/fittrack_sdd/src")
from dlib import Doc
import content, checks
from model_data import FIGS
OUT = "/home/claude/fittrack_sdd/out"; os.makedirs(OUT, exist_ok=True)
DOCX = f"{OUT}/FitTrack_Pro_Phase3_Design_Document.docx"; PDF = DOCX.replace(".docx", ".pdf")

def make(toc_entries, lof_entries, toc_pages, lof_pages, results):
    d = Doc()
    d.header_footer(d.d.sections[0], content.HEADER, content.RIGHT)
    content.build(d, results, toc_entries, lof_entries, toc_pages, lof_pages)
    d.save(DOCX)
    return d

def to_pdf():
    subprocess.run(["soffice", "--headless", "--convert-to", "pdf", "--outdir", OUT, DOCX], check=True, capture_output=True)

def pages_text():
    n = int(re.search(r"Pages:\s+(\d+)", subprocess.run(["pdfinfo", PDF], capture_output=True, text=True).stdout).group(1))
    pg = []
    for i in range(1, n + 1):
        pg.append(subprocess.run(["pdftotext", "-f", str(i), "-l", str(i), "-layout", PDF, "-"], capture_output=True, text=True).stdout)
    return pg

def find_pages(pg, toc_entries, lof_entries, front):
    tp, lp = {}, {}
    norm = lambda s: re.sub(r"\s+", " ", s).strip()
    for lvl, text in toc_entries:
        for i in range(front, len(pg)):
            if any(norm(l) == norm(text) for l in pg[i].splitlines()):
                tp[text] = i + 1; break
    for n, text in lof_entries:
        key = f"Figure {n} – {text}"
        for i in range(front, len(pg)):
            if norm(key)[:60] in norm(pg[i]):
                lp[n] = i + 1; break
    return tp, lp

if __name__ == "__main__":
    results = checks.run_checks()
    lof = [(v[0], v[3]) for v in sorted(FIGS.values(), key=lambda v: v[0])]
    d0 = make([], [], {}, {}, results)               # pass 0: collect headings
    toc_entries = [(l, t) for l, t in d0.headings if l <= 3]
    d1 = make(toc_entries, lof, {}, {}, results); to_pdf()
    pg = pages_text()
    front = 3   # cover, TOC and list of figures occupy the first pages; detect real end
    for i, t in enumerate(pg):
        if re.search(r"^\s*1 Introduction\s*$", t, re.M) and "Table of Contents" not in t: front = i; break
    tp, lp = find_pages(pg, toc_entries, lof, front)
    d2 = make(toc_entries, lof, tp, lp, results); to_pdf()
    pg2 = pages_text()
    tp2, lp2 = find_pages(pg2, toc_entries, lof, front)
    stable = (tp == tp2 and lp == lp2)
    if not stable:
        d3 = make(toc_entries, lof, tp2, lp2, results); to_pdf()
    print("pages:", len(pg2), "front:", front, "stable:", stable, "missing toc:", [t for _, t in toc_entries if t not in tp2], "missing lof:", [n for n, _ in lof if n not in lp2])
