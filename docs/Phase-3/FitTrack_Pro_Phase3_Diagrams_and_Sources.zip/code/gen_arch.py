import subprocess, sys, os
ROOT = "/home/claude/fittrack_sdd"
SRC, IMG = f"{ROOT}/src", f"{ROOT}/img"

FONT = "Liberation Sans"
C = dict(view="#DCEBFF", viewb="#3B7BD6", ctl="#FFE7BF", ctlb="#D98A00", svc="#E8E0FF", svcb="#7456D6",
         mod="#E6F6C9", modb="#6FA600", repo="#D4F1EE", repob="#1E9A8E", db="#E7E7E7", dbb="#555555",
         cfg="#FFF4D6", cfgb="#B8860B", cli="#FFFFFF", clib="#333333")

def render(name, dot, dpi=220):
    p = f"{SRC}/{name}.dot"
    open(p, "w").write(dot)
    subprocess.run(["dot", "-Tpng", f"-Gdpi={dpi}", p, "-o", f"{IMG}/{name}.png"], check=True)
    subprocess.run(["dot", "-Tsvg", p, "-o", f"{SRC}/{name}.svg"], check=True)

def box(title, items, fill, border, width=None, fs=11):
    rows = "".join(f'<TR><TD ALIGN="LEFT" BORDER="0"><FONT POINT-SIZE="{fs}">{i}</FONT></TD></TR>' for i in items)
    return (f'<<TABLE BORDER="1" COLOR="{border}" CELLBORDER="0" CELLSPACING="0" CELLPADDING="3" BGCOLOR="{fill}">'
            f'<TR><TD BGCOLOR="{border}"><FONT COLOR="white" POINT-SIZE="{fs+1}"><B>{title}</B></FONT></TD></TR>{rows}</TABLE>>')

# ---------------------------------------------------------------- Figure 1 architecture
def architecture():
    d = f'''digraph G {{
  graph [rankdir=TB, fontname="{FONT}", nodesep=0.3, ranksep=0.32, pad=0.15, newrank=true];
  node  [fontname="{FONT}", shape=plaintext, fontsize=11];
  edge  [fontname="{FONT}", fontsize=10, color="#333333", penwidth=1.3];

  browser [label={box("Client: Web Browser", ["Chrome, Firefox, Edge (360 px and wider)","HTML forms, CSS dark theme, JavaScript, Chart.js"], C["cli"], C["clib"])}];

  subgraph cluster_app {{
    label=<<B>FitTrack Pro: one deployable application (modular monolith)</B>>;
    labeljust=l; fontsize=12; style="dashed,rounded"; color="#444444"; margin=12;

    views [label={box("View: Presentation Layer",
       ["Login and Registration, Dashboard, Profile, Goals, Workout Form and","History, Meal Logging, Weight, Routines, Shared With Me, Reports,","Reminders, Smart Coach panel"], C["view"], C["viewb"])}];
    ctl [label={box("Controller Layer",
       ["AuthController, ProfileController, GoalController, WorkoutController,","MealController, WeightController, HistoryController, DashboardController,","ReportController, RoutineController, ReminderController, SmartCoachController","<I>Per request: session check, input validation, ownership check</I>"], C["ctl"], C["ctlb"])}];
    svc [label={box("Model: Application and Domain Services",
       ["AuthService, ProfileService, GoalService, GoalProgressService,","WorkoutService, CalorieBurnService, NutritionService, WeightService,","HistoryService, DashboardService, ReportService, RoutineService,","ReminderService, SmartCoachService, SmartRuleEvaluator, InputValidator"], C["svc"], C["svcb"])}];
    ent [label={box("Model: Domain Entities", ["User, FitnessGoal, Workout, ExerciseEntry,","MealEntry, Food, WeightEntry, WorkoutRoutine,","RoutineExercise, RoutineShare, FavoriteRoutine,","Reminder, SmartRecommendation"], C["mod"], C["modb"])}];
    cfg [label={box("Internal Configuration", ["MET table by activity type","Smart Coach rules SR-01 to SR-04","and thresholds (named constants)","Validation limits, session timeout,","lock-out policy"], C["cfg"], C["cfgb"])}];
    repo [label={box("Model: Data Access (Repositories)", ["UserRepository, GoalRepository, WorkoutRepository,","MealRepository, FoodRepository, WeightRepository,","RoutineRepository, ReminderRepository,","RecommendationRepository"], C["repo"], C["repob"])}];
    {{rank=same; svc; cfg}}
    {{rank=same; repo; ent}}
  }}

  db [label={box("Relational Database (PostgreSQL, proposed)", ["13 tables, foreign keys, CHECK and unique constraints","Transactions per save; password hashes only"], C["db"], C["dbb"])}];

  browser -> views  [dir=both, label=<  <B>1</B> HTTP(S) request<BR ALIGN="LEFT"/>  <B>8</B> HTML response<BR ALIGN="LEFT"/>>];
  views -> ctl      [dir=both, label=<  <B>2</B> routed action, form data<BR ALIGN="LEFT"/>  <B>7</B> view model<BR ALIGN="LEFT"/>>];
  ctl -> svc        [dir=both, label=<  <B>3</B> use-case call<BR ALIGN="LEFT"/>  <B>6</B> result or error<BR ALIGN="LEFT"/>>];
  svc -> repo       [dir=both, label=<  <B>4</B> query or command<BR ALIGN="LEFT"/>  <B>5</B> entities<BR ALIGN="LEFT"/>>];
  repo -> db        [dir=both, label=<  SQL over a local connection>];
  svc -> cfg        [dir=none, style=dashed, label=<reads>];
  svc -> ent        [dir=none, style=dashed, constraint=false, label=<creates, updates>];
  repo -> ent       [dir=none, style=dashed, constraint=false];
}}'''
    render("fig01_architecture", d)

# ---------------------------------------------------------------- Figure 2 MVC interaction (Log a Meal)
def mvc_interaction():
    def n(id_, num, title, sub, fill, border):
        return (f'{id_} [label=<<TABLE BORDER="1" COLOR="{border}" CELLBORDER="0" CELLSPACING="0" CELLPADDING="3" BGCOLOR="{fill}">'
                f'<TR><TD ALIGN="LEFT"><B>{num}  {title}</B></TD></TR><TR><TD ALIGN="LEFT"><FONT POINT-SIZE="10">{sub}</FONT></TD></TR></TABLE>>];')
    d = f'''digraph G {{
  graph [rankdir=LR, fontname="{FONT}", nodesep=0.2, ranksep=0.18, pad=0.15, newrank=true];
  node [fontname="{FONT}", shape=plaintext, fontsize=11];
  edge [fontname="{FONT}", fontsize=10, color="#333333", penwidth=1.3];
  subgraph cluster_cli {{ label="Client"; style="filled,rounded"; margin=6; fillcolor="#FFFFFF"; color="{C['clib']}";
     {n("s1","1","Submit Log Meal form","POST: date, type,<BR ALIGN='LEFT'/>food, quantity", C["cli"], C["clib"])}
     {n("s9","9","Browser shows result","updated meal list<BR ALIGN='LEFT'/>and day total", C["cli"], C["clib"])} }}
  subgraph cluster_view {{ label="View"; style="filled,rounded"; margin=6; fillcolor="#F3F8FF"; color="{C['viewb']}";
     {n("s8","8","MealLogView","template renders list,<BR ALIGN='LEFT'/>totals, empty states", C["view"], C["viewb"])} }}
  subgraph cluster_ctl {{ label="Controller"; style="filled,rounded"; margin=6; fillcolor="#FFFAF0"; color="{C['ctlb']}";
     {n("s2","2","MealController<BR ALIGN='LEFT'/>   .logMeal()","session valid?<BR ALIGN='LEFT'/>fields valid?<BR ALIGN='LEFT'/>food visible to user?", C["ctl"], C["ctlb"])}
     {n("s7","7","Build view model","MealEntry + DailyNutrition;<BR ALIGN='LEFT'/>choose view", C["ctl"], C["ctlb"])} }}
  subgraph cluster_model {{ label="Model"; style="filled,rounded"; margin=6; fillcolor="#F6FBEA"; color="{C['modb']}";
     {n("s3","3","NutritionService","snapshot = Food values<BR ALIGN='LEFT'/>x quantity", C["svc"], C["svcb"])}
     {n("s4","4","MealRepository<BR ALIGN='LEFT'/>   .save()","one transaction", C["repo"], C["repob"])}
     {n("s6","6","dailyTotals()","sum of stored snapshots;<BR ALIGN='LEFT'/>flag incomplete data", C["svc"], C["svcb"])} }}
  subgraph cluster_db {{ label="Database"; style="filled,rounded"; margin=6; fillcolor="#F2F2F2"; color="{C['dbb']}";
     {n("s5","5","INSERT meal_entries","commit; rows returned", C["db"], C["dbb"])} }}
  {{rank=same; s1; s9; s8}} {{rank=same; s2; s7}} {{rank=same; s3; s4; s6}} {{rank=same; s5}}
  s1 -> s2 [style=invis]; s2 -> s3 [constraint=true]; s3 -> s5 [style=invis];
  s1 -> s2 [constraint=false]; s3 -> s4; s4 -> s5 [constraint=false]; s5 -> s6 [constraint=false]; s6 -> s7 [constraint=false];
  s7 -> s8 [constraint=false]; s8 -> s9 [constraint=false];
}}'''
    render("fig02_mvc_interaction", d)

if __name__ == "__main__":
    architecture(); mvc_interaction()
    from PIL import Image
    for f in ["fig01_architecture", "fig02_mvc_interaction"]:
        im = Image.open(f"{IMG}/{f}.png"); print(f, im.size, round(im.size[0]/220, 1), "x", round(im.size[1]/220, 1), "in")
