-- FitTrack Pro proposed PostgreSQL schema (generated from schema.py)

CREATE TABLE users (
  user_id BIGINT  -- Identity, NOT NULL,
  full_name VARCHAR(60)  -- NOT NULL; CHECK length 2-60,
  email VARCHAR(254)  -- NOT NULL; unique on lower(email),
  password_hash VARCHAR(255)  -- NOT NULL,
  height_cm NUMERIC(4,1)  -- NULL; CHECK 50-250,
  preferred_routine_category VARCHAR(12)  -- NULL; CHECK in routine categories,
  registration_date TIMESTAMPTZ  -- NOT NULL; DEFAULT now(),
  failed_login_count SMALLINT  -- NOT NULL; DEFAULT 0,
  failed_window_start TIMESTAMPTZ  -- NULL,
  lockout_until TIMESTAMPTZ  -- NULL
);

CREATE TABLE fitness_goals (
  goal_id BIGINT  -- Identity, NOT NULL,
  user_id BIGINT  -- NOT NULL; FK users(user_id),
  goal_type VARCHAR(10)  -- NOT NULL; CHECK in CALORIES, FREQUENCY, DURATION, WEIGHT,
  title VARCHAR(60)  -- NOT NULL,
  target_value NUMERIC(8,2)  -- NOT NULL; CHECK range per goal_type (FR-04 limits),
  unit VARCHAR(12)  -- NOT NULL,
  start_date DATE  -- NOT NULL,
  end_date DATE  -- NULL; CHECK end_date >= start_date,
  status VARCHAR(8)  -- NOT NULL; DEFAULT 'ACTIVE'; CHECK in ACTIVE, INACTIVE
);

CREATE TABLE workouts (
  workout_id BIGINT  -- Identity, NOT NULL,
  user_id BIGINT  -- NOT NULL; FK users(user_id),
  workout_date DATE  -- NOT NULL,
  activity_type VARCHAR(16)  -- NOT NULL; CHECK in the 8 activity types,
  duration_minutes SMALLINT  -- NOT NULL; CHECK 1-600,
  notes VARCHAR(500)  -- NULL
);

CREATE TABLE exercise_entries (
  exercise_id BIGINT  -- Identity, NOT NULL,
  workout_id BIGINT  -- NOT NULL; FK workouts ON DELETE CASCADE,
  exercise_name VARCHAR(60)  -- NOT NULL,
  sets SMALLINT  -- NOT NULL; CHECK 1-20,
  repetitions SMALLINT  -- NOT NULL; CHECK 1-200,
  resistance_kg NUMERIC(6,2)  -- NULL; CHECK 0-1000,
  notes VARCHAR(200)  -- NULL,
  sequence_number SMALLINT  -- NOT NULL; UNIQUE (workout_id, sequence_number)
);

CREATE TABLE foods (
  food_id BIGINT  -- Identity, NOT NULL,
  food_name VARCHAR(60)  -- NOT NULL,
  serving_description VARCHAR(80)  -- NOT NULL,
  calories_per_serving NUMERIC(7,2)  -- NOT NULL; CHECK 0-5000,
  protein_g NUMERIC(6,2)  -- NULL; CHECK 0-1000,
  carbs_g NUMERIC(6,2)  -- NULL; CHECK 0-1000,
  fat_g NUMERIC(6,2)  -- NULL; CHECK 0-1000,
  source VARCHAR(6)  -- NOT NULL; CHECK in SYSTEM, CUSTOM,
  owner_user_id BIGINT  -- NULL; FK users(user_id); CHECK (source='SYSTEM') = (owner_user_id IS NULL)
);

CREATE TABLE meal_entries (
  meal_entry_id BIGINT  -- Identity, NOT NULL,
  user_id BIGINT  -- NOT NULL; FK users(user_id),
  food_id BIGINT  -- NOT NULL; FK foods(food_id) ON DELETE RESTRICT,
  meal_date DATE  -- NOT NULL,
  meal_type VARCHAR(9)  -- NOT NULL; CHECK in BREAKFAST, LUNCH, DINNER, SNACK,
  serving_quantity NUMERIC(5,2)  -- NOT NULL; CHECK 0.1-50,
  estimated_calories NUMERIC(8,2)  -- NOT NULL,
  estimated_protein_g NUMERIC(8,2)  -- NULL,
  estimated_carbs_g NUMERIC(8,2)  -- NULL,
  estimated_fat_g NUMERIC(8,2)  -- NULL,
  nutrition_complete BOOLEAN  -- NOT NULL,
  notes VARCHAR(200)  -- NULL
);

CREATE TABLE weight_entries (
  weight_id BIGINT  -- Identity, NOT NULL,
  user_id BIGINT  -- NOT NULL; FK users(user_id),
  measurement_date DATE  -- NOT NULL; UNIQUE (user_id, measurement_date),
  weight_kg NUMERIC(4,1)  -- NOT NULL; CHECK 20-400,
  note VARCHAR(200)  -- NULL
);

CREATE TABLE workout_routines (
  routine_id BIGINT  -- Identity, NOT NULL,
  user_id BIGINT  -- NOT NULL; FK users(user_id),
  title VARCHAR(60)  -- NOT NULL; CHECK length 3-60; UNIQUE (user_id, lower(title)),
  category VARCHAR(12)  -- NOT NULL; CHECK in STRENGTH, CARDIO, FLEXIBILITY, HIIT, MIXED, OTHER,
  description VARCHAR(500)  -- NULL,
  created_at TIMESTAMPTZ  -- NOT NULL; DEFAULT now(),
  updated_at TIMESTAMPTZ  -- NOT NULL; DEFAULT now()
);

CREATE TABLE routine_exercises (
  item_id BIGINT  -- Identity, NOT NULL,
  routine_id BIGINT  -- NOT NULL; FK workout_routines ON DELETE CASCADE,
  exercise_name VARCHAR(60)  -- NOT NULL,
  target_sets SMALLINT  -- NOT NULL; CHECK 1-20,
  target_repetitions SMALLINT  -- NOT NULL; CHECK 1-200,
  target_resistance NUMERIC(6,2)  -- NULL; CHECK 0-1000,
  sequence_number SMALLINT  -- NOT NULL; UNIQUE (routine_id, sequence_number)
);

CREATE TABLE routine_shares (
  share_id BIGINT  -- Identity, NOT NULL,
  routine_id BIGINT  -- NOT NULL; FK workout_routines ON DELETE CASCADE,
  recipient_user_id BIGINT  -- NOT NULL; FK users(user_id),
  shared_at TIMESTAMPTZ  -- NOT NULL; DEFAULT now(),
  revoked_at TIMESTAMPTZ  -- NULL
);

CREATE TABLE favorite_routines (
  favorite_id BIGINT  -- Identity, NOT NULL,
  user_id BIGINT  -- NOT NULL; FK users(user_id),
  routine_id BIGINT  -- NOT NULL; FK workout_routines ON DELETE CASCADE; UNIQUE (user_id, routine_id),
  saved_at TIMESTAMPTZ  -- NOT NULL; DEFAULT now()
);

CREATE TABLE reminders (
  reminder_id BIGINT  -- Identity, NOT NULL,
  user_id BIGINT  -- NOT NULL; FK users(user_id),
  reminder_type VARCHAR(7)  -- NOT NULL; CHECK in WORKOUT, MEAL,
  reminder_time TIME  -- NOT NULL,
  days_of_week SMALLINT  -- NOT NULL; CHECK 1-127,
  label VARCHAR(60)  -- NULL,
  is_active BOOLEAN  -- NOT NULL; DEFAULT TRUE
);

CREATE TABLE smart_recommendations (
  recommendation_id BIGINT  -- Identity, NOT NULL,
  user_id BIGINT  -- NOT NULL; FK users(user_id),
  rule_id VARCHAR(5)  -- NOT NULL; CHECK in SR-01 to SR-04,
  message VARCHAR(300)  -- NOT NULL,
  explanation VARCHAR(600)  -- NOT NULL,
  created_at TIMESTAMPTZ  -- NOT NULL; DEFAULT now(),
  status VARCHAR(9)  -- NOT NULL; DEFAULT 'ACTIVE'; CHECK in ACTIVE, DISMISSED, EXPIRED,
  dismissed_at TIMESTAMPTZ  -- NULL,
  goal_id BIGINT  -- NULL; FK fitness_goals(goal_id),
  routine_id BIGINT  -- NULL; FK workout_routines ON DELETE CASCADE
);

CREATE UNIQUE INDEX uq_users_email ON users (lower(email));
CREATE UNIQUE INDEX uq_goal_one_active_per_type ON fitness_goals (user_id, goal_type) WHERE status = 'ACTIVE';
CREATE UNIQUE INDEX uq_share_one_active_per_pair ON routine_shares (routine_id, recipient_user_id) WHERE revoked_at IS NULL;
CREATE UNIQUE INDEX uq_routine_title_per_owner ON workout_routines (user_id, lower(title));
CREATE INDEX ix_workouts_user_date ON workouts (user_id, workout_date DESC);
CREATE INDEX ix_meals_user_date ON meal_entries (user_id, meal_date DESC);
CREATE INDEX ix_shares_recipient ON routine_shares (recipient_user_id) WHERE revoked_at IS NULL;
CREATE INDEX ix_reco_user_rule ON smart_recommendations (user_id, rule_id, status);
CREATE INDEX ix_foods_owner ON foods (owner_user_id);