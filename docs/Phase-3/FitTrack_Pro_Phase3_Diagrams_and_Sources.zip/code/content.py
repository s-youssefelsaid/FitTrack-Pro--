import os
from dlib import *
from dlib import _font
from schema import TABLES, RELS, INDEXES, n_columns
from model_data import *
import checks

IMG = "/home/claude/fittrack_sdd/img"
def img(k): return os.path.join(IMG, FIGS[k][2])
LIGHT = "F2F2F2"

HEADER = "FitTrack Pro – Software Design Document (Phase 3)"
RIGHT = "CSAI 203 – Fall 2026"

def contrast(h1, h2):
    def lum(h):
        c = [int(h[i:i+2], 16) / 255 for i in (0, 2, 4)]
        c = [x / 12.92 if x <= .03928 else ((x + .055) / 1.055) ** 2.4 for x in c]
        return .2126 * c[0] + .7152 * c[1] + .0722 * c[2]
    a, b = sorted((lum(h1), lum(h2)), reverse=True)
    return (a + .05) / (b + .05)

# ====================================================================== sequence descriptions
SEQ = {
 "s1a": dict(h="Scenario 1A: Register Account", uc="UC-01 Register Account (includes UC-02 Validate Input Data)", fr="FR-01", actor="Visitor",
   pre="The Visitor is not logged in and the registration page is reachable.",
   trig="The Visitor submits the sign-up form (full name, e-mail, password, confirmation, optional height).",
   main="1. RegistrationLoginView sends the RegisterForm to AuthController.register.\n2. AuthController checks every field with InputValidator (UC-02).\n3. AuthService.register asks UserRepository.findByEmail whether the address is already used; none is found.\n4. AuthService hashes the password with a salt and creates the User entity.\n5. UserRepository.save inserts the users row in one transaction.\n6. AuthController returns a success message with a link to Log In. No session is started.",
   alt="A1. A rule fails (name 2-60 characters, e-mail format, password rule, confirmation, height 50-250 cm): messages appear beside the fields, entered values are kept except passwords, nothing is stored.\nA2. The e-mail is already registered (compared case-insensitively): the form is shown again with an 'email already registered' message; nothing is stored.\nA3. A logged-in user opens the page: redirected to the Dashboard.",
   exc="E1. Storage failure: the transaction is rolled back, a generic retry message is shown and no partial account exists.",
   post="Success: exactly one users row exists and it holds only the salted hash. Failure: no data stored."),
 "s1b": dict(h="Scenario 1B: Log In with lock-out check", uc="UC-03 Log In (UC-04 Log Out is described as alternative flow A4); includes UC-02", fr="FR-02", actor="Visitor (account holder); Registered User for Log Out",
   pre="An account exists and the user is not logged in.",
   trig="The Visitor submits e-mail and password.",
   main="1. RegistrationLoginView sends the LoginForm to AuthController.login.\n2. AuthController checks that both fields are present and calls AuthService.authenticate.\n3. AuthService reads the account with UserRepository.findByEmail.\n4. AuthService asks User.isLocked(now); the account is not locked.\n5. User.verifyPassword compares the password with the stored hash; it matches.\n6. AuthService calls User.resetFailedLogins and returns the authenticated User.\n7. AuthController.startSession(userId) opens a session that expires after 30 minutes of inactivity.\n8. The browser is redirected to the Dashboard (or to the page originally requested).",
   alt="A1. Unknown e-mail: the same generic message as for a wrong password is returned; no session.\nA2. Wrong password: User.recordFailedLogin(now) counts the failure inside a 15-minute window; the fifth failure sets lockoutUntil to now + 15 minutes. The generic message is shown.\nA3. Account locked: the attempt is refused with a lock notice until lockoutUntil.\nA4. Log Out (UC-04, not drawn): AuthController.logout ends the session; protected URLs then redirect to Log In and pages are sent with no-store caching so the Back button shows no personal data.\nA5. Expired session: redirect to Log In with a notice.",
   exc="E1. Data store unreachable: a generic error is shown and no session is created.",
   post="Success: an authenticated session bound to the user exists and the failure counter is zero. Failure: no session; the failure counter is updated."),
 "s2": dict(h="Scenario 2: Log Workout", uc="UC-10 Log Workout, UC-11 Record Exercise Details; includes UC-02", fr="FR-07, FR-08 (FR-09 edit and delete reuse the same validate and save path)", actor="Registered User",
   pre="The user is logged in.",
   trig="The user selects Save Workout on the Log Workout form.",
   main="1. The user enters date, activity type, duration and notes in WorkoutView; optionally WorkoutController.prefill copies the exercise rows of an own or shared routine once (no link is kept).\n2. The user adds exercise rows (name, sets, repetitions, resistance).\n3. WorkoutView sends the WorkoutForm to WorkoutController.log.\n4. WorkoutController checks the session and validates the data (UC-02).\n5. WorkoutService.log creates the Workout and one ExerciseEntry per row, numbered in the order added.\n6. WorkoutRepository.save inserts the workouts row and all exercise_entries rows in one transaction.\n7. WorkoutController loads the updated history and totals through WorkoutService.history and returns the view.",
   alt="A1. Invalid date (in the future), duration outside 1-600, missing type, sets outside 1-20 or repetitions outside 1-200: messages beside the fields, form kept, nothing stored.\nA2. Several workouts on one day are allowed; a workout without exercise rows is valid.\nA3. Edit or delete (UC-12): the owner check is applied first; delete asks for confirmation and removes the workout with its entries; totals are recalculated at once.",
   exc="E1. Save failure: the transaction is rolled back, an error is shown and the form stays filled.",
   post="One workouts row and its exercise_entries rows exist, owned by the user, and appear in history and dashboard totals."),
 "s3": dict(h="Scenario 3: Log Meal and calculate nutrition", uc="UC-15 Log Meal, UC-17 Calculate Nutrition Totals; includes UC-02; UC-16 Add Custom Food as alternative flow", fr="FR-11, FR-13 (FR-12 in alternative flow A2)", actor="Registered User",
   pre="The user is logged in.",
   trig="The user selects Add to Meal.",
   main="1. The user chooses date, meal type, a food and a serving quantity in MealView.\n2. MealView sends the MealForm to MealController.logMeal.\n3. MealController checks the session and validates the data (quantity 0.1-50, date not in the future).\n4. NutritionService.logMeal asks FoodRepository.findVisible for the food (system food or own custom food).\n5. Food.nutritionFor(quantity) returns calories and the known macronutrients multiplied by the quantity.\n6. MealEntry.applySnapshot stores these values; unknown macronutrients stay NULL and nutritionComplete is true only when all three are known.\n7. MealRepository.save inserts the meal_entries row.\n8. NutritionService loads the day with MealRepository.findByDay, sums the stored snapshots (dailyTotals) and compares them with the active calorie goal.\n9. MealController returns the meal list, the day total, the amount remaining or over, and a 'based on X of Y entries' label when data is incomplete.",
   alt="A1. Invalid quantity or date: messages, nothing stored.\nA2. The food is missing or belongs to another user: the user is offered Add Custom Food (UC-16 through MealController.addCustomFood).\nA3. No calorie goal exists: totals are shown with a prompt to create one.",
   exc="E1. Save failure: the transaction is rolled back, an error is shown and the form stays filled.",
   post="One meal_entries row with its nutrition snapshot exists; later edits of the food never change it."),
 "s4": dict(h="Scenario 4: View Dashboard and goal progress", uc="UC-07 View Dashboard, UC-08 Monitor Goal Progress, UC-09 Select Date Range", fr="FR-06, FR-15, FR-16, FR-17", actor="Registered User",
   pre="The user is logged in.",
   trig="The user opens the Dashboard or changes the period.",
   main="1. DashboardView requests DashboardController.show with the day and the range.\n2. DashboardController checks the session and the range.\n3. DashboardService.summary reads workouts (WorkoutRepository.findInRange), meal entries (MealRepository.findInRange) and the latest weight (WeightRepository.latestOnOrBefore).\n4. GoalProgressService.progress loops over the active goals and applies the formula of FR-06 to each.\n5. DashboardService adds totals, the estimated calories burned (CalorieBurnService) with the number of excluded workouts, and the chart series.\n6. DashboardController returns the cards, charts and empty states.\nDue reminders (ReminderService.dueNow, FR-23) and the Smart Coach panel (Figure 16) are added to the same view model; they are left out of the figure for legibility.",
   alt="A1. Start after end or range over 366 days: a message is shown and the previous range is kept.\nA2. A goal has no records: 'No data yet' (never 0%); a goal that has not started: 'Starts on <date>'.\nA3. A widget has no data: an explicit empty state with a link to the logging action; a new user sees only empty states.\nA4. No weight entry or activity type Other: the workout shows 'Not enough data' and is excluded from the burned total with a note.",
   exc="E1. A read fails: an error page with a retry link is shown; no partial figures are displayed.",
   post="Read-only; no data is changed."),
 "s5a": dict(h="Scenario 5A: Create Workout Routine", uc="UC-21 Manage Workout Routines; includes UC-02", fr="FR-18", actor="Registered User (owner)",
   pre="The user is logged in.",
   trig="The user selects Save on the New Routine form.",
   main="1. RoutineView sends the RoutineForm (title, category, description, exercises) to RoutineController.create.\n2. RoutineService.create checks title 3-60 characters, a category, 1-30 exercises and a title not yet used by this owner (case-insensitive).\n3. RoutineService builds the WorkoutRoutine with its RoutineExercise items in order.\n4. RoutineRepository.save inserts the routine and its items in one transaction.\n5. RoutineController shows the routine card; the routine is private.",
   alt="A1. Duplicate title or no exercise: a message is shown and the form is kept.\nA2. Edit or delete (owner only): delete asks for confirmation and removes the routine's shares and favorites.",
   exc="E1. Save failure: rollback and an error message; nothing is stored.",
   post="A private routine with its ordered exercises exists and is owned by the user."),
 "s5b": dict(h="Scenario 5B: Share and revoke a routine", uc="UC-23 Share Routine, UC-24 Revoke Routine Sharing (UC-22 favorites affected)", fr="FR-20, FR-19", actor="Registered User (owner)",
   pre="The owner is logged in and owns the routine.",
   trig="The owner enters a recipient's e-mail and selects Share.",
   main="1. RoutineView sends routineId and e-mail to RoutineController.share.\n2. RoutineService.share confirms ownership with RoutineRepository.findOwned.\n3. UserRepository.findByEmail finds the recipient.\n4. RoutineService checks that the recipient is not the owner and has no active share.\n5. A read-only RoutineShare is created.\n6. RoutineRepository.addShare inserts the routine_shares row.\n7. RoutineController returns the updated recipient list. No e-mail is sent and no public link exists.",
   alt="A1. Routine not owned or missing: 'not found' without revealing whether it exists.\nA2. E-mail not registered: a neutral 'no registered user with that email'.\nA3. Self-share or an active share already exists: rejected, nothing changes.\nA4. Revoke later: RoutineController.revoke leads to RoutineShare.revoke(now), which sets revoked_at; the recipient's favorite of that routine is deleted; the recipient loses access at once while copies already made stay independent.\nA5. Revoking an already revoked share has no effect.",
   exc="E1. Storage failure: rollback, an error message and no change.",
   post="The share is active (recipient can view, favorite and copy) or revoked (recipient sees nothing)."),
 "s6": dict(h="Scenario 6: Smart Coach recommendations", uc="UC-26 View Smart Coach Recommendations, UC-27 Evaluate Smart Rules", fr="FR-22", actor="Registered User (through the Dashboard or the Coach panel)",
   pre="The user is logged in.",
   trig="The user opens the Dashboard or the Coach panel.",
   main="1. DashboardView calls SmartCoachController.panel.\n2. SmartCoachService.recommendations(user, now) reads dismissals of the last 14 days (RecommendationRepository.recentDismissed).\n3. SmartRuleEvaluator.evaluateAll reads the last 14 days of workouts, the routines visible to the user and the active goals.\n4. SR-01 to SR-04 are evaluated in a loop; each rule whose condition is met returns a draft with its explanation.\n5. SmartCoachService drops drafts matching a dismissal (same rule and same goal or routine within 14 days) and keeps at most three.\n6. SmartRecommendation entities are created and saved; stale ones are expired.\n7. SmartCoachController returns cards with the message, the 'Why am I seeing this?' text and the disclaimer.",
   alt="A1. Too little data for a rule: the rule is skipped, never guessed.\nA2. No rule applies: 'No suggestions right now'.\nA3. The user dismisses a card: SmartCoachService.dismiss calls SmartRecommendation.dismiss(now); status becomes DISMISSED with dismissed_at, starting the 14-day suppression.",
   exc="E1. A read fails: the panel shows a short notice and the rest of the Dashboard remains usable.",
   post="At most three ACTIVE recommendations exist; each has an explanation; no medical statement is made."),
}

def seq_table(doc, key):
    s = SEQ[key]
    doc.table(["Field", "Description"], [
        ("Use Case ID", s["uc"]), ("Related FRs", s["fr"]), ("Primary Actor", s["actor"]), ("Preconditions", s["pre"]),
        ("Trigger", s["trig"]), ("Main Success Scenario", s["main"]), ("Alternative Flows", s["alt"]),
        ("Exception Flows", s["exc"]), ("Postconditions", s["post"])],
        [3.6, 22.5], size=10, first_bold=True, zebra=False, title=f"Description of {s['h'].split(':')[0]} ({s['h'].split(': ')[1]})", break_before=True)

def seq_block(doc, key, heading):
    n = FIGS[key][0]
    doc.h(4, heading, toc=False)
    doc.figure(img(key), FIGS[key][3], max_w_cm=25.2, max_h_cm=15.4)
    seq_table(doc, key)

# ====================================================================== body
def build(doc, results, toc_entries, lof_entries, toc_pages, lof_pages):
    d = doc
    doc.toc_entries = toc_entries; doc.toc_pages = toc_pages
    ph = checks.phase2_check()
    ncol = n_columns()
    # ---------------------------------------------------------------- cover
    def center(t, size, bold=False, after=6, color=None, italic=False, before=0):
        p = d.d.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.line_spacing = 1.15; p.paragraph_format.space_after = Pt(after); p.paragraph_format.space_before = Pt(before)
        r = p.add_run(t); _font(r, size, bold, italic, color); return p
    center("Zewail City of Science, Technology and Innovation", 16, True, 2, before=20)
    center("School of Computational Sciences and Artificial Intelligence", 13, False, 2)
    center("CSAI 203 – Introduction to Software Engineering", 13, False, 2)
    center("Fall 2026", 13, False, 46)
    center("FitTrack Pro", 34, True, 2, TEAL)
    center("Smart Health & Fitness Tracker", 16, False, 30, "404040")
    center("Phase 3 – Software Design Document", 22, True, 4)
    center("(SDD)", 14, False, 40, "404040")
    d.table(["Team member", "Student ID"], [("Youssef Hassan Elsaid", "202402456"), ("Ali Elwakeel", "202402383")], [8.0, 4.5], size=11, zebra=False)
    p = d.d.paragraphs[-1]
    center("Instructor: Dr. Mohamed Sami Rakha", 13, False, 40, before=10)
    d.table(["Document control", ""], [
        ("Version", "1.0 (review draft)"),
        ("Baseline", "FitTrack Pro Phase 2 Software Requirements Specification (review draft)"),
        ("Date", "November 2026"),
        ("Status", "Design only. Nothing described here has been implemented or tested."),
    ], [3.6, 11.0], size=10, first_bold=True, zebra=False)
    # section break after cover -> body section with header/footer
    d.pagebreak()
    # ---------------------------------------------------------------- TOC
    p = d.d.add_paragraph(); r = p.add_run("Table of Contents"); _font(r, 16, True)
    p.paragraph_format.space_after = Pt(8); p.paragraph_format.keep_with_next = True
    d.toc()
    # list of figures
    p = d.d.add_paragraph(); p.paragraph_format.space_before = Pt(14); p.paragraph_format.keep_with_next = True
    r = p.add_run("List of Figures"); _font(r, 16, True)
    first = True
    for i, (n, text) in enumerate(lof_entries):
        p = d.d.add_paragraph(style="TOC 2"); p.paragraph_format.left_indent = Cm(0)
        if first:
            r = p.add_run(); fc = OxmlElement("w:fldChar"); fc.set(qn("w:fldCharType"), "begin"); r._r.append(fc)
            r = p.add_run(); it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = ' TOC \\h \\z \\c "Figure" '; r._r.append(it)
            r = p.add_run(); fc = OxmlElement("w:fldChar"); fc.set(qn("w:fldCharType"), "separate"); r._r.append(fc)
            first = False
        r = p.add_run(f"Figure {n} – {text}\t{lof_pages.get(n, '0')}"); _font(r, 10)
        p.paragraph_format.space_after = Pt(1)
        if i == len(lof_entries) - 1:
            r = p.add_run(); fc = OxmlElement("w:fldChar"); fc.set(qn("w:fldCharType"), "end"); r._r.append(fc)
    d.pagebreak()

    # ================================================================ 1 INTRODUCTION
    d.h(1, "1 Introduction")
    d.h(2, "1.1 Purpose")
    d.p("This Software Design Document (SDD) is the Phase 3 deliverable of the FitTrack Pro project for CSAI 203. It turns the Phase 2 Software Requirements Specification (SRS) into a design that the two-person team can implement without having to invent structure while coding. The SRS states what the system must do; this document states how the system is organised to do it: its architecture, its Model-View-Controller (MVC) structure, its classes and their interactions, its screens and its stored data.")
    d.p("Every design element is traceable to a numbered Phase 2 requirement. Section 6 holds the traceability matrix, a consistency review and the list of design decisions and open questions.")
    d.h(2, "1.2 Scope")
    d.p("The design covers the complete Phase 2 baseline: **24 functional requirements** (FR-01 to FR-24), **28 use cases** (UC-01 to UC-28), the **five non-functional requirements** (NFR-01 to NFR-05), the Smart Coach rules SR-01 to SR-04, the common rules CR-1 to CR-5, and the business and privacy rules stated in the SRS. FitTrack Pro remains a web application in which a registered user records workouts, meals, body weight and goals, follows progress on a dashboard, builds and shares workout routines inside the application, and receives explainable suggestions from a rule-based Smart Coach.")
    d.p("The following stay out of scope, exactly as in Phase 2: medical advice or health-outcome promises, machine learning, external food, AI, e-mail, SMS or push services, wearables, native mobile apps, an administrator role, challenges and data export. This document contains no source code, no test results and no claim that any part of the system exists. Statements about technology are proposals until the team confirms them (Section 3.3).")
    d.p("No Phase 2 requirement is changed. Where the design needs something the SRS does not state, the addition is labelled with a decision number (D-01, D-02, ...) and listed in Section 6.3 for team approval.")
    d.h(2, "1.3 Audience")
    d.table(["Reader", "How the reader uses this document"], [
        ("Project team (Youssef Hassan Elsaid, Ali Elwakeel)", "Implement the system from the architecture, class, sequence, interface and data designs; split work along the modules of Section 2.1."),
        ("Instructor and teaching assistants", "Check that the design follows the SRS, that MVC is applied consistently, and that every requirement can be traced to a design element."),
        ("Testers", "Derive test cases from the sequence diagrams (main, alternative and exception flows), the data dictionary constraints and the formulas of FR-06, FR-13 and FR-17."),
        ("Future maintainers", "Find where each rule lives (layer, class, table) and which decisions were taken and why."),
    ], [5.6, 11.4], size=10, title="Intended readers", first_bold=True)
    d.h(2, "1.4 Overview")
    d.p("Section 2 describes the system and separates what Phase 2 already fixed from what this phase chooses. Section 3 presents the architecture, the request and security flows, and a proposed technology stack. Section 4 contains the detailed design: MVC (4.1), UML class and sequence diagrams (4.2), user-interface mockups (4.3) and data design (4.4). Section 5 summarises the phase and Section 6 contains the traceability matrix, the consistency review and the decisions and open questions.")
    d.table(["Convention", "Meaning"], [
        ("FR-nn, UC-nn, NFR-nn, SR-nn, CR-n", "Identifiers of the Phase 2 SRS, used unchanged."),
        ("D-nn", "A design decision or an addition to the Phase 2 data needed by the design (Section 6.3)."),
        ("Q-nn", "An open question that needs a team or instructor decision (Section 6.3)."),
        ("\"Proposed\"", "A choice the team has not yet confirmed; it can change without changing any requirement."),
        ("Diagram colours", "View: blue. Controller: orange. Model services: violet. Model entities and rules: green. Model data access: teal. Database: grey."),
        ("MVC, ER, PK, FK, UQ", "Model-View-Controller; entity-relationship; primary key; foreign key; unique constraint."),
    ], [5.6, 11.4], size=10, title="Conventions and abbreviations used in this document", first_bold=True)

    # ================================================================ 2 SYSTEM OVERVIEW
    d.h(1, "2 System Overview")
    d.h(2, "2.1 Description")
    d.p("FitTrack Pro is a standalone web application with no external service dependency. A Visitor can only register and log in. A Registered User has full access to his or her own records and read-only access to routines that another user has actively shared. No administrator role exists; the team maintains the internal food list and the activity table (SRS 2.3).")
    d.p("The functions of the SRS are grouped into nine modules. A module is a set of cooperating controller, service, entity and repository classes with one clear responsibility; modules are not separately deployed.")
    d.table(["Module", "Responsibility", "Requirements"], [
        ("Accounts and Profile", "Registration, log in and out, lock-out, profile", "FR-01 to FR-03"),
        ("Goals", "Four goal types, one active goal per type, progress formulas", "FR-04 to FR-06"),
        ("Workout Tracking", "Workouts, exercise details, edit and delete, history with filters", "FR-07 to FR-10"),
        ("Nutrition", "Meal entries with snapshots, system and custom foods, daily totals", "FR-11 to FR-13"),
        ("Weight", "One weight entry per date, trend", "FR-14"),
        ("Dashboard and Reports", "Daily summary, charts, date ranges, estimated calories burned, reports", "FR-15 to FR-17, FR-24"),
        ("Routines", "Routines, favorites, read-only sharing, revocation, copies", "FR-18 to FR-21"),
        ("Smart Coach", "Rule-based, explainable recommendations (SR-01 to SR-04)", "FR-22"),
        ("Reminders", "Workout and meal reminders shown in the application", "FR-23"),
    ], [4.2, 8.8, 4.0], size=10, title="Modules and the requirements they realise", first_bold=True)
    d.h(2, "2.2 Design Goals and Constraints")
    d.p("The design is driven by six goals, listed in priority order: (1) correct and consistent calculations (NFR-04); (2) privacy and security of personal records (NFR-02, CR-1); (3) simplicity that two students can build, explain and defend; (4) testability, so that each rule can be checked without a browser; (5) acceptable speed on the dashboard and on saves (NFR-01); (6) usability on phone, tablet and desktop (NFR-03, NFR-05).")
    d.p("Phase 2 fixed some things and left others open. The two tables below keep the two groups apart so that no design choice is mistaken for a requirement.", keep=True)
    d.table(["Fixed by Phase 2 (requirement or constraint)", "Source"], [
        ("MVC architecture; web application; no external food, AI, e-mail, SMS or push services", "SRS 2.6, 3.5"),
        ("Smart Coach is rule-based (SR-01 to SR-04), explainable, at most 3 recommendations, 14-day dismissal; no machine learning and no medical advice", "FR-22"),
        ("Users reach only their own records; routines are shared read-only, revocable, in-application only", "CR-1, FR-20"),
        ("Passwords stored only as salted hashes; session timeout 30 minutes; lock-out after 5 failures in 15 minutes; HTTPS when public", "FR-02, NFR-02"),
        ("Nutrition values are stored as a snapshot with each meal entry; unknown macronutrients stay empty, never zero; reports and dashboard are calculated on demand", "FR-11 to FR-13, FR-24"),
        ("Premium dark interface (black and charcoal with lime-green accents); navigation: Dashboard, Goals, Workouts, Nutrition, Weight, Routines, Reports, Reminders, Profile", "SRS 3.5.1"),
        ("Measurable targets: dashboard in 3 s, saves in 2 s, 30 calculation cases, 360, 768 and 1366 px widths", "NFR-01 to NFR-05"),
    ], [13.0, 4.0], size=9.5, title="Fixed by the Phase 2 SRS")
    d.table(["Design choice made in this phase (proposed)", "Reason"], [
        ("Modular monolith: one deployable application with internal modules", "Smallest operational effort for two developers; no network calls between modules."),
        ("MVC refined into View, thin Controllers and a Model made of services, entities and repositories", "Keeps rules testable and keeps SQL out of controllers."),
        ("Server-rendered views with Chart.js for charts", "No separate front-end application to build and secure."),
        ("Smart rules as one class per rule (Strategy pattern)", "Each rule can be tested and its threshold changed alone."),
        ("Relational schema of 13 tables with surrogate keys and database constraints", "Integrity is enforced twice: in services and in the database."),
        ("Six small additions to the Phase 2 data (D-01 to D-05)", "Needed to implement lock-out, ordering, labels and dismissal; see Section 6.3."),
    ], [8.0, 9.0], size=9.5, title="Design choices of this document")
    d.p("**Constraints.** Team of two; one academic term; no budget for paid services; the brief names no framework, language or database, so the stack in Section 3.3 is a proposal; browsers: current Chrome, Firefox and Edge from 360 px width upward; no result of any test may be claimed until tests are run.")

    # ================================================================ 3 ARCHITECTURE
    d.h(1, "3 Architectural Design", page_break=True)
    d.h(2, "3.1 Architecture Diagram")
    d.p(f"Figure {F('arch')} shows the layers of FitTrack Pro and the numbered path of one request. The dashed boundary marks the single deployable unit.", keep=True)
    d.figure(img("arch"), FIGS["arch"][3], max_w_cm=16.4, max_h_cm=21.0)
    d.h(2, "3.2 Architectural Style and Components")
    d.p("**Style.** FitTrack Pro is a layered, modular monolith that applies MVC. It is not a microservice system. One process serves all pages and one database stores all data. The decision follows from the size of the team and of the product: there is no independent scaling need, no external integration and no team boundary that would justify network calls between modules. Modules (Section 2.1) are separated by package and by rule: a module may use another module only through that module's service.")
    d.table(["Layer / component", "Responsibility"], [
        ("Client (web browser)", "Shows pages, submits forms, draws charts from data delivered with the page."),
        ("View layer", "Server-rendered templates for each screen; show validation messages, empty states and flash notices."),
        ("Controller layer", "One controller per module. Reads the session, validates input, checks ownership, calls one service method per use case, picks a view."),
        ("Model: services", "Business rules and calculations: goal limits and progress, calorie estimate, nutrition snapshot and totals, routine sharing rules, Smart Coach evaluation."),
        ("Model: entities", "Domain objects with their own behaviour (for example User.isLocked, MealEntry.applySnapshot, RoutineShare.revoke)."),
        ("Model: repositories", "The only code that talks to the database; one repository per aggregate; transactions per save."),
        ("Internal configuration", "MET table, Smart Rule thresholds, validation limits, session timeout and lock-out policy as named constants."),
        ("Database", "13 tables with keys, CHECK and unique constraints; stores password hashes only."),
    ], [4.4, 12.6], size=10, title="Components and responsibilities", first_bold=True)
    d.p("**Request flow.** The numbers refer to Figure 1. (1) The browser sends an HTTP(S) request. (2) The router maps it to a controller action and passes form data. (3) The controller calls a service method for the use case. (4) The service asks a repository for data or to store data. (5) The repository returns entities. (6) The service returns a result or a typed error to the controller. (7) The controller builds a view model. (8) The view renders HTML, which the browser displays. A worked example for Log Meal appears in Section 4.1.4.")
    d.p("**Security and authorization flow.** Every request to a protected route passes the same checks, in this order:", keep=True)
    d.bullets([
        "**Transport.** HTTPS with Secure and HttpOnly session cookies when the instance is public (NFR-02); passwords and session identifiers never appear in URLs.",
        "**Authentication.** BaseController.requireLogin finds a valid, non-expired session (30 minutes of inactivity); otherwise the request is redirected to Log In with a notice.",
        "**Request integrity.** Every state-changing form carries a CSRF token (proposed; supported by the proposed framework).",
        "**Validation.** InputValidator checks all fields before a service is called; errors are returned beside the field and entered data is kept (CR-4).",
        "**Authorization.** The controller asks requireOwner for the record, and every repository query on user-owned data includes the owner id, so another user's record is never loaded. A record that is not owned, or does not exist, produces the same 'not found' page (CR-1).",
        "**Shared routines.** A routine is visible to a recipient only while an active RoutineShare exists (revoked_at is NULL); the recipient can view, favorite and copy but never edit.",
        "**Password and lock-out.** AuthService compares a salted hash; User.recordFailedLogin and lockoutUntil enforce the 5-failures-in-15-minutes rule; the failure message is generic.",
        "**Response.** Pages with personal data are sent with no-store caching so that the Back button after Log Out shows nothing.",
    ], spacing=1.25)
    d.table(["Resource", "Visitor", "Owner (Registered User)", "Recipient of an active share"], [
        ("Own profile, goals, workouts, meals, weight, reminders, recommendations", "No access", "Full", "No access"),
        ("Own routine", "No access", "Full (edit, delete, share, revoke)", "Not applicable"),
        ("Routine shared with the user", "No access", "Not applicable", "View, favorite, copy; no edit"),
        ("System food", "No access", "Read", "Read"),
        ("Custom food", "No access", "Read, edit (own only)", "No access to the owner's foods"),
    ], [6.4, 2.2, 4.6, 3.8], size=9.5, title="Authorization matrix", first_bold=True)
    d.h(2, "3.3 Technology Stack")
    d.p("**Proposed, requires team confirmation (Q-01).** The brief names no technology. The stack below is chosen for beginners: one language for the whole back end, widely documented libraries, and no front-end build step. Any other MVC-capable stack would leave the design unchanged because classes, tables and flows are technology-neutral.", keep=True)
    d.table(["Layer", "Proposed technology", "Why it fits"], [
        ("Language and web framework", "Python with Flask (blueprints act as controllers)", "Small, easy to learn, explicit routing; matches the controller classes of Figure 6."),
        ("Views", "Jinja2 templates, HTML5, custom CSS dark theme, small JavaScript", "Server-side rendering; no single-page application needed."),
        ("Charts", "Chart.js", "Line and bar charts with axis titles and tooltips (FR-16)."),
        ("Persistence", "PostgreSQL accessed through SQLAlchemy (repositories wrap the queries)", "Foreign keys, CHECK constraints, partial unique indexes and transactions as required by Section 4.4."),
        ("Authentication and sessions", "Flask-Login with signed cookies; bcrypt for salted password hashes; Flask-WTF for forms and CSRF", "Proven libraries; avoids hand-written security code."),
        ("Testing", "pytest for services and repositories", "Rules are in plain classes and can be tested without a browser."),
        ("Version control and diagrams", "Git and GitHub; Mermaid, Graphviz and HTML/SVG sources", "Diagram sources are text and are kept with the code."),
        ("Hosting", "Not decided (Q-02)", "NFR-02 needs HTTPS on a public instance; a local instance is enough for development."),
    ], [3.6, 6.4, 7.0], size=9.5, title="Proposed technology stack (requires team confirmation)", first_bold=True)

    # ================================================================ 4 DETAILED DESIGN
    d.h(1, "4 Detailed Design", page_break=True)
    d.h(2, "4.1 Model-View-Controller (MVC) Design")
    d.h(3, "4.1.1 Description of MVC in FitTrack Pro")
    d.p("MVC is mandatory in Phase 2 and is applied as follows. The **Model** holds everything that is true about fitness data regardless of how it is shown: entities, the services that enforce the rules and perform the calculations, and the repositories that store and read the data. Data access is a sub-layer of the Model (decision D-13) so that no SQL appears in a controller. The **View** is the set of server-rendered templates that turn a view model into HTML. The **Controller** receives each request, checks the session, validates input, checks ownership, calls the Model and chooses the View. A controller never calculates a result and a view never decides a business rule.")
    d.h(3, "4.1.2 Component Mapping")
    d.table(["Component / Class", "MVC Layer", "Responsibility"], MVC_ROWS, [6.6, 2.6, 7.8], size=9, title="Mapping of components and classes to MVC layers")
    d.h(3, "4.1.3 Layer Responsibilities and Dependency Rules")
    d.bullets([
        "**View** may read only the view model given to it. It does not call services or repositories.",
        "**Controller** may call services and InputValidator and may build view models. It does not contain business rules, calculations or SQL.",
        "**Model services** may call repositories, entities, other services and configuration. They know nothing about HTTP, sessions or HTML.",
        "**Repositories** may use the database and create entities. They contain no business decisions except the owner filter.",
        "Dependencies point one way only: View, then Controller, then Service, then Repository, then Database. No lower layer refers to a higher one.",
    ], spacing=1.25)
    d.h(3, "4.1.4 Request Lifecycle and MVC Interaction")
    d.p(f"Figure {F('mvc')} follows one request, Log a Meal (UC-15), through the three MVC roles. Steps: (1) the browser posts the form; (2) MealController.logMeal checks the session, the fields and that the food is visible to the user; (3) NutritionService computes the snapshot (food values multiplied by the quantity); (4) MealRepository.save stores it in one transaction; (5) the database commits; (6) NutritionService.dailyTotals sums the stored snapshots and flags incomplete data; (7) the controller builds a view model; (8) MealLogView renders the meal list, totals and empty states; (9) the browser shows the result.", keep=True)
    d.figure(img("mvc"), FIGS["mvc"][3], max_w_cm=17.0, max_h_cm=14.0)

    d.h(2, "4.2 UML Design", page_break=True)
    d.h(3, "4.2.1 Use Case Model Reference")
    d.p("The use case model belongs to Phase 2 (three use case diagrams and 28 descriptions) and is not redrawn. The table shows where each use case is realised in this design.", keep=True)
    rows = []
    for uc, name, actor in UCS:
        k, note = UC_COVER[uc]
        cov = (f"Figure {F(k)}" if k else "Pattern") + (f" ({note})" if note else "")
        rows.append((uc, name, actor, cov))
    d.table(["UC", "Name", "Primary actor", "Realised in"], rows, [1.6, 5.0, 4.4, 6.0], size=9, title="Use cases and their design coverage", first_bold=True)
    d.p("Use cases marked \"Pattern\" have no diagram of their own because they repeat a drawn pattern (validate, call a service, save, show a result). Their controllers and services are named in the traceability matrix (Section 6.1).")

    d.h(3, "4.2.2 Detailed Design Class Diagram", page_break=True)
    d.p(f"The class model is shown in six figures (Figures {F('dom1')} to {F('repo')}) so that every attribute and method stays readable. Figures {F('dom1')} to {F('dom3')} show the Model entities; Figure {F('ctl')} the Controller layer; Figure {F('svc')} the Model services; Figure {F('repo')} the repositories and the Smart Coach rule hierarchy. The View layer consists of templates, not classes, and is listed in the component mapping table of Section 4.1.2.")
    d.p("**Notation.** Visibility: + public, - private, # protected. Attributes are written name: Type; a trailing ? means the value may be empty. Methods are written name(parameters): ReturnType. Multiplicities stand at the line ends. A filled diamond marks composition; a triangle marks generalisation. Enumerations are listed in Figure 3. Layer colours follow Section 1.4.")
    d.figure(img("dom1"), FIGS["dom1"][3], max_w_cm=16.0, max_h_cm=12.5)
    d.figure(img("dom2"), FIGS["dom2"][3], max_w_cm=15.0, max_h_cm=12.5)
    d.figure(img("dom3"), FIGS["dom3"][3], max_w_cm=17.0, max_h_cm=12.5)
    d.p("**Relationships and why they are drawn this way.**", keep=True)
    d.bullets([
        "**Composition**: Workout contains 0..* ExerciseEntry, and WorkoutRoutine contains 1..30 RoutineExercise. The parts have no meaning without the whole and are deleted with it (database ON DELETE CASCADE).",
        "**Association with multiplicity**: User owns many goals, workouts, meals, weights, routines, favorites, reminders and recommendations (1 to 0..*); a User has at most 10 Reminders (0..10, enforced in ReminderService).",
        "**MealEntry uses one Food** and keeps its own nutrition snapshot, so a later edit of the Food never changes past entries.",
        "**RoutineShare** is a class of its own, not a list inside WorkoutRoutine, because it has a recipient, a creation time and a revocation time (revokedAt).",
        "**Generalisation**: all controllers extend BaseController (shared session and ownership checks); the four rule classes extend SmartRule (Strategy pattern), so a fifth rule needs no change in SmartRuleEvaluator beyond registration.",
        "**Dependencies**: controllers depend on services; services depend on repositories and entities; repositories depend on the database (Section 4.1.3). They are shown as «uses» lines in Figures 6 and 7 rather than arrows to keep the figures readable.",
    ], spacing=1.25)
    d.figure(img("ctl"), FIGS["ctl"][3], max_w_cm=17.0, max_h_cm=15.5)
    d.figure(img("svc"), FIGS["svc"][3], max_w_cm=17.0, max_h_cm=16.5)
    d.figure(img("repo"), FIGS["repo"][3], max_w_cm=17.0, max_h_cm=13.0)

    s_ = d.new_section(landscape=True); d.header_footer(s_, HEADER, RIGHT)
    d.h(3, "4.2.3 Sequence Diagrams")
    d.p(f"Eight sequence diagrams cover the six required scenarios (Figures {F('s1a')} to {F('s6')}). Scenarios 1 and 5 are split in two (1A and 1B, 5A and 5B) so that each diagram stays legible. Every diagram uses the real classes of Section 4.2.2 grouped by MVC layer: View (blue), Controller (orange), Model (green) and Data access (teal); the Database is the last participant and no generic \"System\" participant is used. Activation bars show the span of each call; alt, opt and loop fragments show alternatives, optional steps and repetition. Each diagram is followed by a table that describes the full flow, including steps that the figure only summarises. The diagrams are wide, so they sit on landscape pages; full-resolution PNG files are delivered with the document.", size=11, spacing=1.2)
    d.table(["Scenario", "Use cases", "Related FRs", "Figure"], [
        ("1A Registration", "UC-01, UC-02", "FR-01", f"Figure {F('s1a')}"), ("1B Authentication", "UC-03, UC-04, UC-02", "FR-02", f"Figure {F('s1b')}"),
        ("2 Log Workout", "UC-10, UC-11, UC-02", "FR-07, FR-08", f"Figure {F('s2')}"), ("3 Log Meal and Nutrition", "UC-15, UC-17, UC-02, UC-16", "FR-11, FR-13, FR-12", f"Figure {F('s3')}"),
        ("4 Dashboard and Goal Progress", "UC-07, UC-08, UC-09", "FR-06, FR-15, FR-16, FR-17", f"Figure {F('s4')}"), ("5A Create Routine", "UC-21, UC-02", "FR-18", f"Figure {F('s5a')}"),
        ("5B Share and Revoke Routine", "UC-23, UC-24, UC-22", "FR-20, FR-19", f"Figure {F('s5b')}"), ("6 Smart Coach", "UC-26, UC-27", "FR-22", f"Figure {F('s6')}"),
    ], [7.0, 7.5, 7.5, 4.1], size=10, title="Sequence diagrams and the scenarios they cover", first_bold=True)
    seq_block(d, "s1a", "Scenario 1A: Registration (UC-01)")
    seq_block(d, "s1b", "Scenario 1B: Authentication (UC-03, UC-04)")
    seq_block(d, "s2", "Scenario 2: Log Workout (UC-10, UC-11)")
    seq_block(d, "s3", "Scenario 3: Log Meal and Nutrition (UC-15, UC-17)")
    seq_block(d, "s4", "Scenario 4: Dashboard and Goal Progress (UC-07, UC-08)")
    seq_block(d, "s5a", "Scenario 5A: Create Routine (UC-21)")
    seq_block(d, "s5b", "Scenario 5B: Share and Revoke Routine (UC-23, UC-24)")
    seq_block(d, "s6", "Scenario 6: Smart Coach (UC-26, UC-27)")

    # ---------------------------------------------------------------- 4.3 UI
    s_ = d.new_section(landscape=False); d.header_footer(s_, HEADER, RIGHT)
    d.h(2, "4.3 UI/UX Design")
    d.p("The five mockups below are low-effort wireframes in the Premium Dark style of SRS 3.5.1. They use invented sample data, are meant to show structure and behaviour, and are not final visual design. The Profile, Goals, Weight, History, Reports and Reminders screens are not mocked up (five were required); they reuse the same cards, forms, tables and empty-state patterns and are covered in the traceability matrix.")
    d.table(["Design token", "Value", "Use"], [
        ("Background / surface", "#0B0B0C / #141416, #1B1B1E", "Page, sidebar, cards"),
        ("Border", "#2B2B30", "Cards, inputs, table rules"),
        ("Primary text / muted text", "#F3F3F1 / #9B9BA3", "Body, labels"),
        ("Accent (lime green)", "#B9F23B", "Primary buttons, selected navigation, progress bars, key figures"),
        ("Warning / error", "#F5B93B / #F26B5B", "Behind target, validation errors; always with text, never colour alone"),
        ("Typeface", "Inter (one family)", "All text; system sans-serif as fallback"),
    ], [4.6, 5.0, 7.4], size=9.5, title="Visual design tokens", first_bold=True)
    c1 = contrast("B9F23B", "0B0B0C"); c2 = contrast("F3F3F1", "141416"); c3 = contrast("9B9BA3", "1B1B1E")
    d.p(f"Contrast ratios computed from these values: accent on background {c1:.1f}:1, primary text on surface {c2:.1f}:1, muted text on card {c3:.1f}:1; each is above the 4.5:1 level for normal text. The persistent left navigation lists Dashboard, Goals, Workouts, Nutrition, Weight, Routines, Reports, Reminders and Profile; below 768 px it collapses into a menu button, forms become one column and cards stack (NFR-05). Controls have visible labels and focus outlines (NFR-03).")
    def ui_block(key, title, purpose, comps, inter, rel):
        d.h(3, title)
        d.figure(img(key), FIGS[key][3], max_w_cm=17.0, max_h_cm=13.2)
        d.table(["Item", "Description"], [("Purpose", purpose), ("Components", comps), ("Interactions", inter), ("Related FRs / UCs", rel)],
                [3.2, 13.8], size=9.5, first_bold=True, zebra=False, title=f"Description of {FIGS[key][3].split(': ')[1]} mockup")
    ui_block("ui1", "4.3.1 Login and Registration",
      "Let a Visitor create an account or log in. It is the only screen available without a session.",
      "Logo and tagline; Log In card (e-mail, password with Show toggle, Log In button, link to Sign Up, lock-out hint); Create Account card (full name, e-mail, password, confirmation, optional height, Sign Up button, link to Log In); inline error text; medical-advice notice.",
      "Submit Log In: valid credentials open the Dashboard, anything else shows one generic message. Submit Sign Up: each broken rule shows its own message beside the field and keeps the input except passwords; success shows a message with a link to Log In. After five failures the account is locked for 15 minutes with a notice. On phones the two cards stack.",
      "FR-01, FR-02; UC-01, UC-02, UC-03; Figures 9 and 10")
    ui_block("ui2", "4.3.2 Dashboard",
      "Summarise the selected period and day: activity, nutrition, weight, goals, suggestions and reminders, with explicit empty states.",
      "Navigation sidebar; period chips (This week, Last 7 days, This month, Last 30 days, Custom range); four summary cards (workouts today, calories consumed against target, estimated calories burned marked \"estimated\", latest weight); three charts (minutes per day, calories per day with target line, weight over time); goal progress card with On track, Behind and Starts-on labels; Smart Coach card with \"Why am I seeing this?\" and Dismiss; reminders due; quick actions Log Workout and Log Meal.",
      "Choosing a period updates every widget consistently; an invalid range shows a message and keeps the previous one. A widget without data names the missing record and links to the logging action; unknown values read \"Not enough data\", never 0. Dismissing a recommendation hides it for 14 days; the explanation opens in place.",
      "FR-06, FR-15, FR-16, FR-17, FR-22, FR-23; UC-07, UC-08, UC-09, UC-26; Figures 13 and 16")
    ui_block("ui3", "4.3.3 Workout Logging",
      "Record one workout session with optional exercise details, quickly.",
      "Form with date (default today), activity type list of eight fixed types, duration, notes; optional routine prefill; exercise table (name, sets, repetitions, resistance, computed volume, Remove); Add exercise; Save and Cancel; side panel with weekly progress and recent workouts with Edit and Delete.",
      "Save validates and stores the workout and its entries together; errors appear beside fields and the form stays filled. Prefill copies a routine's exercises once without keeping a link. Delete asks for confirmation. Volume is informational only and empty resistance is allowed.",
      "FR-07, FR-08, FR-09, FR-10; UC-10, UC-11, UC-12, UC-13; Figure 11")
    ui_block("ui4", "4.3.4 Meal Logging and Nutrition",
      "Log foods with serving quantities and see the day's totals against the calorie goal.",
      "Date and meal-type chips (Breakfast, Lunch, Dinner, Snack); food search over system and own custom foods with an Add Custom Food link; quantity field with stepper; live nutrition preview; Add to Meal and Clear; today's meals table; daily totals card with progress bar, remaining kcal and an incompleteness label.",
      "Selecting a food and quantity shows the preview (values per serving multiplied by the quantity); saving stores that snapshot. A missing food leads to Add Custom Food. Totals show \"based on X of Y entries\" when a macronutrient is unknown. Edit and delete are owner-only; delete asks for confirmation.",
      "FR-11, FR-12, FR-13; UC-15, UC-16, UC-17; Figure 12")
    ui_block("ui5", "4.3.5 Routines and Sharing",
      "Create, find, favorite, share, revoke and copy workout routines.",
      "Tabs My Routines, Favorites and Shared With Me; title search and category filter chips; routine cards with category tag, exercise count, privacy or read-only tag, favorite star, Edit, Share, View and Copy to My Routines; share panel with recipient e-mail, Share (read-only) and a list of recipients with Revoke.",
      "Share creates a read-only grant visible only to the recipient; unknown e-mail, self-share and duplicates are rejected with neutral messages. Revoke takes effect at once and removes the routine from the recipient's favorites. Copy creates an independent routine named with \"(copy)\". Only active shares are listed.",
      "FR-18, FR-19, FR-20, FR-21; UC-21, UC-22, UC-23, UC-24, UC-25, UC-28; Figures 14 and 15")

    # ---------------------------------------------------------------- 4.4 data
    d.h(2, "4.4 Data Design", page_break=True)
    d.h(3, "4.4.1 Entity-Relationship Diagram")
    d.p(f"The data design stores the Phase 2 logical tables (13 tables, {ncol} columns: {ph[0]} from the Phase 2 data dictionary plus {len(ph[2])} design additions D-01 to D-04). Figure {F('er')} is drawn in crow's-foot notation on the next page; the data dictionary in Section 4.4.3 lists every column of that figure, and both are generated from the same schema source.")
    # landscape section for ER
    s = d.new_section(landscape=True); d.header_footer(s, HEADER, RIGHT)
    d.figure(img("er"), FIGS["er"][3], max_w_cm=26.0, max_h_cm=15.0)
    s = d.new_section(landscape=False); d.header_footer(s, HEADER, RIGHT)
    d.p("**Reading the diagram.** A crow's foot means many, a double bar means exactly one, a circle with a bar means zero or one, and a circle with a foot means zero or many; the figures beside the symbols repeat this. The end at the child table shows how many child rows a parent can have, the end at the parent table how many parents a child row has. Verbs on the lines name the relationship.")
    d.h(3, "4.4.2 Data Storage Model")
    d.table(["Topic", "Design"], [
        ("Persistence", "One relational database (PostgreSQL proposed). Every table has a surrogate primary key (BIGINT identity). Dates are stored as DATE and system times as TIMESTAMPTZ. All accesses go through the repositories of Figure 8."),
        ("Relationships", "17 foreign keys, listed in the foreign-key table below with their delete behaviour. User is the parent of all personal data; WorkoutRoutine is the parent of its exercises, shares, favorites and suggested recommendations."),
        ("Referential integrity", "Every foreign key is declared. Parts of a composition (exercise_entries, routine_exercises) and links that make no sense without the routine (routine_shares, favorite_routines, recommendations that suggest it) use ON DELETE CASCADE. meal_entries.food_id uses RESTRICT so that a food used by a meal cannot be removed. Deleting a user account is outside the SRS (D-09)."),
        ("Transactions", "Each service method that changes data runs in one transaction opened by the repository save: a workout and its entries, a routine and its items, a meal entry, a share together with its recipient favorite clean-up. A failure rolls everything back, so no partial record can exist (FR-01, NFR-04)."),
        ("Ownership", "Every personal row carries user_id (or owner_user_id for custom foods). Repository queries always filter by the logged-in user's id; shared routines are reached only through an active routine_shares row (CR-1)."),
        ("Deletion", "Workout delete removes its exercise entries; routine delete removes its items, shares and favorites; goals are never erased but set to INACTIVE (FR-05); shares are never deleted but receive revoked_at, which keeps a history of grants; deletion of meals, workouts, weights and routines needs confirmation (CR-3)."),
        ("Password storage", "users.password_hash holds a salted one-way hash (bcrypt proposed). The plain password exists only in memory during registration, log in and password change and is never logged or stored."),
        ("Historical snapshots", "meal_entries keeps estimated_calories and the three macronutrients as computed at logging time, plus nutrition_complete. Editing a food therefore never alters history (FR-12, FR-13). Unknown macronutrients are NULL, never 0."),
        ("Derived data not stored", "Dashboard figures, charts, goal progress and reports are calculated on demand from records (FR-24). Only smart_recommendations is stored, because dismissal and the explanation must be traceable (FR-22)."),
        ("Constraints in the database", "CHECK constraints carry the numeric limits of the SRS (for example duration 1 to 600, sets 1 to 20, weight 20 to 400). Partial unique indexes carry the rules one active goal per type per user, one active share per routine and recipient, and one weight entry per user and date."),
        ("Constraints in services", "Rules the database cannot state simply stay in services and are tested there: date not in the future, at most 10 reminders per user, 1 to 30 items per routine, no share to oneself, goal sanity limits per type, lock-out (D-10)."),
    ], [3.6, 13.4], size=9.5, title="Data storage model", first_bold=True)
    tmap = {t[0]: {c[0]: c for c in t[2]} for t in TABLES}
    fk_rows = []
    for ch, col, par, cc, pc, lab, od in RELS:
        null = "optional" if tmap[ch][col][3].startswith("NULL") else "required"
        fk_rows.append((f"{ch}.{col}", f"{par}", f"{cc} : {pc}", null, od or "NO ACTION"))
    d.table(["Foreign key (child)", "Parent table", "Cardinality child : parent", "Reference", "ON DELETE"], fk_rows, [5.0, 3.6, 3.4, 2.4, 2.6], size=9, title="Foreign keys and delete behaviour", mono_cols=(0,))
    idx = [(a, b, c) for a, b, c in INDEXES]
    d.table(["Index / constraint", "Table", "Definition"], idx, [5.4, 3.8, 7.8], size=9, title="Unique and performance indexes", mono_cols=(0,))
    d.h(3, "4.4.3 Data Dictionary")
    d.p("The tables below list every column of the ER diagram. \"Key/Constraint\" gives the key type first and then nullability, defaults and CHECK rules. Column types are those of the proposed PostgreSQL schema; (D-nn) refers to Section 6.3.")
    for name, purpose, cols in TABLES:
        rows = []
        for c, t, k, cons, desc in cols:
            kc = (k + "; " + cons) if k else cons
            rows.append((name, c, t, kc, desc))
        d.table(["Table", "Column", "Data Type", "Key/Constraint", "Description"], rows, [2.5, 3.0, 2.3, 4.9, 4.3], size=8, title=f"Data dictionary: {name} ({purpose.rstrip('.')})", mono_cols=(0, 1))

    # ================================================================ 5 CONCLUSION
    d.h(1, "5 Conclusion", page_break=True)
    d.h(2, "5.1 Summary of Design Phase")
    d.p("This phase converted the Phase 2 requirements into a design with a single architecture (a modular monolith that applies MVC), a class model in three layers, eight sequence diagrams for the six required scenarios, five interface mockups and a 13-table data design. The design keeps the Phase 2 scope and terminology and changes no requirement. Six small data additions and a few interpretation choices are listed as decisions for approval.")
    d.table(["Item", "Result"], [
        ("Functional requirements traced to design", "24 of 24 (Section 6.1)"),
        ("Use cases placed in the design", f"28 of 28 (Section 4.2.1); {sum(1 for v in UC_COVER.values() if v[0])} drawn in sequence diagrams, {sum(1 for v in UC_COVER.values() if not v[0])} follow a drawn pattern"),
        ("Architecture", "1 diagram; modular monolith; MVC in every diagram"),
        ("Class diagrams", "6 figures: 13 entities, 12 controllers plus BaseController, 16 services, 9 repositories, 5 rule classes"),
        ("Sequence diagrams", "8 diagrams covering the 6 scenarios; every diagram shows View, Controller and Model classes"),
        ("UI mockups", "5, in the dark and lime-green style"),
        ("Data design", f"13 tables, {ncol} columns, 17 foreign keys, 9 indexes and unique constraints"),
        ("Decisions and open questions", "15 decisions and 14 open questions, none yet approved"),
    ], [6.4, 10.6], size=10, title="Results of the design phase", first_bold=True)
    d.p("**Honest limits.** Nothing in this document has been implemented or tested. The technology stack is a proposal. The MET table and the internal food list must still be sourced by the team (SRS A3), and the Smart Rule thresholds are the project defaults of Table 1 in the SRS. Estimated figures in the mockups are invented examples. Fonts: the document uses Times New Roman; the PDF copy was produced on a system that substitutes the metric-compatible Liberation Serif.")
    d.p("**Next steps.** Confirm the open questions of Section 6.3, confirm the stack, create the repository and database schema from Section 4.4, implement the modules in the order of Section 2.1 starting with Accounts, and derive test cases from the sequence diagrams and the data constraints.")

    # ================================================================ 6 TRACEABILITY
    s = d.new_section(landscape=True); d.header_footer(s, HEADER, RIGHT)
    d.h(1, "6 Requirements-to-Design Traceability")
    d.h(2, "6.1 Traceability Matrix")
    d.p("Each row follows one functional requirement to the controller, the Model classes, the sequence diagram, the UI screen and the database tables that realise it. A text beginning with \"Pattern\" or \"Not mocked up\" means that no figure of its own exists and the shared pattern is named. The same matrix, with a use-case sheet, is delivered as a spreadsheet.", size=11, spacing=1.15)
    rows = [(r[0] + " " + r[1], r[2], r[3], r[4], fmt_seq(r[5]), fmt_ui(r[6]), r[7]) for r in TRACE]
    d.table(["Phase 2 Req / UC", "UCs", "Controller", "Model / Service", "Sequence Diagram", "UI Screen", "Database Tables"], rows,
            [3.6, 2.0, 4.2, 5.6, 3.2, 3.4, 4.1], size=8, title="Requirements-to-design traceability matrix", first_bold=True)
    s = d.new_section(landscape=False); d.header_footer(s, HEADER, RIGHT)
    d.h(2, "6.2 Consistency Review")
    r = results
    mvc_ok = all(v[0] for v in r["mvc"].values())
    n_msgs = r["msg_total"]; hit = r["msg_hit"]
    n2, missing, added = ph
    d.p("The checks below were run on the sources of this document (schema, diagram sources and matrix data), not only read by eye.", keep=True)
    d.table(["Check", "Result", "Evidence"], [
        ("ER diagram matches the data dictionary", "Pass" if (r["er_tables"] and r["er_cols"]) else "FAIL",
         f"{r['er_n_tables']} tables and {r['er_n_cols']} columns drawn in the ER source equal the {len(TABLES)} tables and {ncol} columns of the dictionary (same schema source)."),
        ("Relationships drawn equal foreign keys", "Pass" if (r["er_rels"] and r["fk_ok"]) else "FAIL",
         f"{r['n_rels']} relationship lines; every one uses a column flagged FK; {r['fk_flagged']} FK columns exist."),
        ("Phase 2 data fully present", "Pass" if not missing else "FAIL",
         f"All {n2} fields of the Phase 2 data dictionary appear; {len(added)} columns are design additions (D-01 to D-04)."),
        ("All 24 functional requirements traced", "Pass" if r["fr_ok"] else "FAIL", "FR-01 to FR-24 each have a controller, model classes, a sequence diagram or named pattern, a UI screen and tables."),
        ("MVC in every sequence diagram", "Pass" if mvc_ok else "FAIL", "All 8 diagrams contain at least one View, one Controller and one Model participant; none uses a generic \"System\" participant."),
        ("Sequence participants exist in the class diagrams", "Pass" if not r["unknown_participants"] else "FAIL", "Every participant is a class of Figures 3 to 8 or a View template of Section 4.1.2."),
        ("Sequence messages exist as methods", "Pass" if not r["msg_miss"] else "Partial", f"{hit} of {n_msgs} named operation calls in the sequence diagrams are declared as methods in the class diagrams."),
        ("Terminology and rules equal Phase 2", "Reviewed by hand", "Goal types, 8 activity types, meal types, routine categories, limits and rule IDs were compared with SRS 3.1 and Table 1."),
        ("Scope: nothing outside Phase 2", "Pass", "No new feature was added; additions are data fields for existing requirements and are listed in Section 6.3."),
        ("Required outline", "Pass with one note", "Sections 1 to 4 follow the required outline. The Conclusion is numbered 5 and the matrix 6 so that numbering is continuous (Q-14)."),
    ], [5.0, 2.4, 9.6], size=9, title="Consistency review", first_bold=True)
    d.table(["Requirement", "Design provision"], [
        ("NFR-01 Performance", "Dashboard reads use the indexes (user_id, date); on-demand sums over at most 366 days; one transaction per save."),
        ("NFR-02 Security and privacy", "Section 3.2 security flow; salted hashes; owner filter in every repository query; CSRF tokens; HTTPS and Secure, HttpOnly cookies when public."),
        ("NFR-03 Usability", "Section 4.3: inline errors, empty states, consistent navigation, labelled controls."),
        ("NFR-04 Data integrity and accuracy", "Snapshots, constraints, transactions, calculations in testable services, NULL instead of 0 for unknown data."),
        ("NFR-05 Responsive compatibility", "Section 4.3: stacking cards and one-column forms below 768 px; layout verified later at 360, 768 and 1366 px."),
    ], [4.6, 12.4], size=9.5, title="Non-functional requirements and the design provision for each", first_bold=True)
    d.h(2, "6.3 Design Decisions and Open Questions")
    d.table(["ID", "Decision", "Reason", "Effect on Phase 2"], [
        ("D-01", "Add users.failed_login_count, failed_window_start and lockout_until.", "FR-02 needs the 5-failures-in-15-minutes rule; Phase 2 stores no counter or window.", "Three columns added; no change to FR-02."),
        ("D-02", "Add exercise_entries.sequence_number.", "FR-08 keeps entries in the order added; routine items already have sequenceNumber.", "One column added."),
        ("D-03", "Add reminders.label (optional).", "FR-23 names an optional label; the Phase 2 Reminder class has none.", "One column added."),
        ("D-04", "Add smart_recommendations.dismissed_at and the status value EXPIRED.", "The 14-day suppression needs the time of dismissal; stale suggestions need a state.", "One column and one status value added."),
        ("D-05", "Routine titles are unique per owner, ignoring case.", "FR-18 forbids duplicates but does not say how case is treated.", "Interpretation only."),
        ("D-06", "Smart Rule thresholds are named constants in configuration.", "FR-22 and A6 ask that thresholds can be adjusted.", "None."),
        ("D-07", "Custom food names may repeat for one owner after a warning; no unique constraint.", "FR-12 says the warning can be accepted.", "None."),
        ("D-08", "foods referenced by meal entries use ON DELETE RESTRICT; custom foods cannot be deleted while used.", "Protects history; FR-12 defines edit but not delete.", "Interpretation only."),
        ("D-09", "Account deletion is not designed.", "No requirement or use case asks for it.", "None."),
        ("D-10", "Future-date, 10-reminder, 1 to 30 items and no-self-share rules are enforced in services.", "They are awkward as pure SQL constraints and must give friendly messages.", "None."),
        ("D-11", "A dismissal suppresses a recommendation with the same rule and the same goal or routine for 14 days.", "FR-22 says not repeated for 14 days without naming the key.", "Interpretation only."),
        ("D-12", "reminders.days_of_week is a bit mask (Mon=1 to Sun=64).", "Simplest storage for a set of weekdays; a child table is possible if preferred.", "None."),
        ("D-13", "Repositories form a data-access sub-layer of the Model.", "Keeps SQL out of controllers and services testable.", "MVC unchanged."),
        ("D-14", "Server-rendered views with small scripts and Chart.js, not a single-page application.", "Least complexity for the team and the security model.", "None."),
        ("D-15", "Session is a signed cookie with a sliding 30-minute inactivity limit.", "Matches FR-02; a fixed 30-minute limit is the alternative.", "Interpretation only."),
    ], [1.3, 6.0, 6.2, 3.5], size=8.5, title="Design decisions (proposed, awaiting team approval)", first_bold=True)
    d.table(["ID", "Open question", "Needed from"], [
        ("Q-01", "Confirm the proposed technology stack (Section 3.3) or name another.", "Team / instructor"),
        ("Q-02", "Where will the application be hosted, and will a public HTTPS instance exist for NFR-02?", "Team"),
        ("Q-03", "Who prepares and sources the MET table and the internal food list (SRS A3)?", "Team"),
        ("Q-04", "Confirm lock-out semantics: five consecutive failures inside 15 minutes, a success resets the count (D-01).", "Team / instructor"),
        ("Q-05", "Approve the data additions D-01 to D-04.", "Team / instructor"),
        ("Q-06", "Confirm case-insensitive routine titles (D-05).", "Team"),
        ("Q-07", "Should custom foods be deletable when unused (D-08)?", "Team"),
        ("Q-08", "Confirm that account deletion and data retention stay out of scope (D-09).", "Team / instructor"),
        ("Q-09", "Confirm the time-zone rule: dates are taken from the browser's local time and stored as dates.", "Team"),
        ("Q-10", "The Team ID and any representative details for the cover page were not supplied and are omitted.", "Team"),
        ("Q-11", "Are Mermaid, Graphviz and HTML/SVG acceptable diagram tools under the course rules (not supplied in Phase 2)?", "Instructor"),
        ("Q-12", "Are additional mockups (Profile, Goals, Weight, History, Reports, Reminders) wanted beyond the five required?", "Instructor"),
        ("Q-13", "Approve the recommendation suppression key of D-11.", "Team"),
        ("Q-14", "Confirm that the length of this document and the numbering Conclusion = 5, Traceability = 6 are acceptable.", "Instructor"),
    ], [1.3, 12.5, 3.2], size=9, title="Open questions that need approval", first_bold=True)
