"""Programmatic consistency checks used both for the document text and for QC."""
import re, os, glob
from schema import TABLES, RELS, n_columns
from model_data import TRACE, FIGS
SRC = "/home/claude/fittrack_sdd/src"

MVC_BOXES = ("View", "Controller", "Model", "Data access")

def seq_files():
    return [FIGS[k][2] for k in ("s1a","s1b","s2","s3","s4","s5a","s5b","s6")]

def parse_seq(path):
    txt = open(path).read()
    boxes, cur, parts, msgs = {}, None, {}, []
    for ln in txt.splitlines():
        s = ln.strip()
        m = re.match(r"box\s+rgb\([^)]*\)\s+(.*)", s)
        if m: cur = m.group(1).strip(); boxes[cur] = []; continue
        if s == "end": cur = None; continue
        m = re.match(r"(participant|actor)\s+(\w+)\s+as\s+(.*)", s)
        if m:
            parts[m.group(2)] = m.group(3).strip()
            if cur: boxes[cur].append(m.group(3).strip())
            continue
        m = re.match(r"(\w+)\s*(-->>|->>)[+-]?\s*(\w+):\s*(.*)", s)
        if m: msgs.append((m.group(1), m.group(3), m.group(4)))
    return boxes, parts, msgs

DOMAIN = {"User","FitnessGoal","Workout","ExerciseEntry","MealEntry","Food","WeightEntry","Reminder","WorkoutRoutine","RoutineExercise",
          "RoutineShare","FavoriteRoutine","SmartRecommendation"}
CTL = {"AuthController","ProfileController","GoalController","WorkoutController","MealController","WeightController","HistoryController",
       "DashboardController","ReportController","RoutineController","ReminderController","SmartCoachController"}
SVC = {"AuthService","ProfileService","GoalService","GoalProgressService","WorkoutService","CalorieBurnService","NutritionService","WeightService",
       "HistoryService","DashboardService","ReportService","RoutineService","ReminderService","SmartCoachService","SmartRuleEvaluator","InputValidator"}
REPO = {"UserRepository","GoalRepository","WorkoutRepository","MealRepository","FoodRepository","WeightRepository","RoutineRepository","ReminderRepository","RecommendationRepository"}
VIEWS = {"Registration / Login View","DashboardView","WorkoutView","MealView","RoutineView"}
EXTRA = {"Database","Visitor","Registered User","Owner"}
KNOWN = DOMAIN | CTL | SVC | REPO | VIEWS | EXTRA
# participants named differently in sequence diagrams (alias -> class)
ALIAS = {"WorkoutRoutine": "WorkoutRoutine"}

def method_names():
    """method names declared in the class figures (domain + layer figures)."""
    names = set()
    for f in ("gen_class.py", "gen_layers.py"):
        t = open(os.path.join(SRC, f)).read()
        names |= set(re.findall(r"[+#\-]([a-zA-Z]\w*)\(", t))
    return names

def run_checks():
    res = {}
    # 1 MVC in every sequence diagram
    mvc = {}
    for f in seq_files():
        boxes, parts, msgs = parse_seq(os.path.join(SRC, f.replace(".png", ".mmd")))
        ok = all(boxes.get(b) for b in MVC_BOXES[:3])
        mvc[f] = (ok, {b: boxes.get(b, []) for b in MVC_BOXES}, parts, msgs)
    res["mvc"] = mvc
    # 2 participants exist in class diagrams
    unknown = {}
    for f, (_ok, _b, parts, _m) in mvc.items():
        bad = [v for v in parts.values() if v not in KNOWN]
        if bad: unknown[f] = bad
    res["unknown_participants"] = unknown
    # 3 message names exist as methods
    mn = method_names()
    tot, hit, miss = 0, 0, []
    for f, (_ok, _b, parts, msgs) in mvc.items():
        for a, b, text in msgs:
            m = re.match(r"(\w+)\(", text)
            if not m: continue
            tot += 1
            nm = m.group(1)
            if nm in mn: hit += 1
            else: miss.append((f, a, b, text))
    res["msg_total"], res["msg_hit"], res["msg_miss"] = tot, hit, miss
    # 4 FR coverage
    frs = {t[0] for t in TRACE}
    res["fr_ok"] = frs == {f"FR-{i:02d}" for i in range(1, 25)}
    # 5 ER svg vs schema
    svg = open(os.path.join(SRC, "fig22_er_diagram.svg")).read()
    names = re.findall(r'font-weight="700" fill="#fff">([a-z_]+)</text>', svg)
    cols = re.findall(r'font-size="13.5" fill="#111"(?: font-style="italic")?>([a-z_]+)</text>', svg)
    res["er_tables"] = sorted(names) == sorted(t[0] for t in TABLES)
    res["er_cols"] = len(cols) == n_columns()
    schema_cols = sorted(c[0] + "." + t[0] for t in TABLES for c in t[2])
    res["er_n_tables"], res["er_n_cols"] = len(names), len(cols)
    # relationships drawn = RELS
    res["er_rels"] = svg.count("<polyline") == len(RELS)
    # FK columns declared in RELS exist and are flagged FK in schema
    tmap = {t[0]: {c[0]: c for c in t[2]} for t in TABLES}
    res["fk_ok"] = all(tmap[ch][col][2] == "FK" for ch, col, *_ in RELS)
    n_fk = sum(1 for t in TABLES for c in t[2] if c[2] == "FK")
    res["fk_flagged"], res["n_rels"] = n_fk, len(RELS)
    return res

# Phase 2 data dictionary fields -> snake_case column present in schema
PHASE2_FIELDS = {
 "users": "user_id full_name email password_hash height_cm preferred_routine_category registration_date",
 "fitness_goals": "goal_id user_id goal_type title target_value unit start_date end_date status",
 "workouts": "workout_id user_id workout_date activity_type duration_minutes notes",
 "exercise_entries": "exercise_id workout_id exercise_name sets repetitions resistance_kg notes",
 "meal_entries": "meal_entry_id user_id food_id meal_date meal_type serving_quantity estimated_calories estimated_protein_g estimated_carbs_g estimated_fat_g nutrition_complete notes",
 "foods": "food_id food_name serving_description calories_per_serving protein_g carbs_g fat_g source owner_user_id",
 "weight_entries": "weight_id user_id measurement_date weight_kg note",
 "workout_routines": "routine_id user_id title category description created_at updated_at",
 "routine_exercises": "item_id routine_id exercise_name target_sets target_repetitions target_resistance sequence_number",
 "routine_shares": "share_id routine_id recipient_user_id shared_at revoked_at",
 "favorite_routines": "favorite_id user_id routine_id saved_at",
 "reminders": "reminder_id user_id reminder_type reminder_time days_of_week is_active",
 "smart_recommendations": "recommendation_id user_id rule_id message explanation created_at status goal_id routine_id",
}
def phase2_check():
    tmap = {t[0]: {c[0] for c in t[2]} for t in TABLES}
    missing = [(t, f) for t, fs in PHASE2_FIELDS.items() for f in fs.split() if f not in tmap.get(t, set())]
    n2 = sum(len(v.split()) for v in PHASE2_FIELDS.values())
    added = [(t, c) for t in tmap for c in tmap[t] if c not in PHASE2_FIELDS[t].split()]
    return n2, missing, sorted(added)

if __name__ == "__main__":
    r = run_checks()
    for f, (ok, b, p, m) in r["mvc"].items(): print(f, ok, {k: len(v) for k, v in b.items()})
    print("unknown participants:", r["unknown_participants"])
    print("messages:", r["msg_hit"], "/", r["msg_total"]);
    for x in r["msg_miss"]: print("  miss", x)
    print({k: v for k, v in r.items() if k.startswith(("fr_", "er_", "fk_", "n_"))})
    print(phase2_check())
