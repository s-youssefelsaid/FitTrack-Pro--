import subprocess
from gen_arch import render, C, FONT, IMG
from PIL import Image

def cls(name, attrs, meths, fill, border, stereo=None, fs=9, abstract=False):
    def rows(items):
        if not items:
            return '<TR><TD ALIGN="LEFT" BORDER="0"> </TD></TR>'
        return "".join(f'<TR><TD ALIGN="LEFT" BORDER="0"><FONT POINT-SIZE="{fs}">{i}</FONT></TD></TR>' for i in items)
    st = f'<FONT POINT-SIZE="{fs}">&#171;{stereo}&#187;</FONT><BR/>' if stereo else ""
    nm = f"<I>{name}</I>" if abstract else name
    return (f'<<TABLE BORDER="1" COLOR="{border}" CELLBORDER="0" CELLSPACING="0" CELLPADDING="2" BGCOLOR="{fill}">'
            f'<TR><TD BGCOLOR="{border}">{st.replace("<FONT", "<FONT COLOR=\'white\'")}<FONT COLOR="white" POINT-SIZE="{fs+2}"><B>{nm}</B></FONT></TD></TR>'
            f'<TR><TD><TABLE BORDER="0" CELLBORDER="0" CELLSPACING="0" CELLPADDING="1">{rows(attrs)}</TABLE></TD></TR>'
            f'<HR/><TR><TD><TABLE BORDER="0" CELLBORDER="0" CELLSPACING="0" CELLPADDING="1">{rows(meths)}</TABLE></TD></TR></TABLE>>')

HEAD = f'''graph [rankdir=TB, fontname="{FONT}", nodesep=0.12, ranksep=0.3, pad=0.15, newrank=true, splines=true];
  node [fontname="{FONT}", shape=plaintext];
  edge [fontname="{FONT}", fontsize=9, color="#333333", arrowsize=0.8, labeldistance=1.3, labelfontsize=9];'''

def assoc(a, b, ta, hb, label=""):
    return f'{a} -> {b} [dir=none, taillabel="{ta}", headlabel="{hb}", label="{label}"];'
def comp(a, b, ta, hb, label=""):
    return f'{a} -> {b} [dir=back, arrowtail=diamond, taillabel="{ta}", headlabel="{hb}", label="{label}", arrowhead=none];'

# ------------------------------------------------------------------ Figure 3: domain / model layer
def domain():
    M, MB = C["mod"], C["modb"]
    n = {}
    n["User"] = cls("User", ["-userId: Long", "-fullName: String", "-email: String", "-passwordHash: String", "-heightCm: Decimal?",
                             "-preferredRoutineCategory: RoutineCategory?", "-registrationDate: DateTime", "-failedLoginCount: int", "-failedWindowStart: DateTime?", "-lockoutUntil: DateTime?"],
                    ["+verifyPassword(plain: String): boolean", "+isLocked(now: DateTime): boolean", "+recordFailedLogin(now: DateTime): void", "+resetFailedLogins(): void"], M, MB, "entity")
    n["FitnessGoal"] = cls("FitnessGoal", ["-goalId: Long", "-goalType: GoalType", "-title: String", "-targetValue: Decimal", "-unit: String", "-startDate: Date", "-endDate: Date?", "-status: GoalStatus"],
                    ["+isActive(): boolean", "+deactivate(): void", "+reactivate(): void", "+withinLimits(): boolean"], M, MB, "entity")
    n["Workout"] = cls("Workout", ["-workoutId: Long", "-workoutDate: Date", "-activityType: ActivityType", "-durationMinutes: int", "-notes: String?"],
                    ["+addExercise(e: ExerciseEntry): void", "+getExercises(): List&lt;ExerciseEntry&gt;", "+isValid(today: Date): boolean"], M, MB, "entity")
    n["ExerciseEntry"] = cls("ExerciseEntry", ["-exerciseId: Long", "-exerciseName: String", "-sets: int", "-repetitions: int", "-resistanceKg: Decimal?", "-notes: String?", "-sequenceNumber: int"],
                    ["+volume(): Decimal?"], M, MB, "entity")
    n["MealEntry"] = cls("MealEntry", ["-mealEntryId: Long", "-mealDate: Date", "-mealType: MealType", "-servingQuantity: Decimal", "-estimatedCalories: Decimal", "-estimatedProteinG: Decimal?",
                    "-estimatedCarbsG: Decimal?", "-estimatedFatG: Decimal?", "-nutritionComplete: boolean", "-notes: String?"],
                    ["+applySnapshot(f: Food, qty: Decimal): void"], M, MB, "entity")
    n["Food"] = cls("Food", ["-foodId: Long", "-foodName: String", "-servingDescription: String", "-caloriesPerServing: Decimal", "-proteinG: Decimal?", "-carbsG: Decimal?", "-fatG: Decimal?",
                    "-source: FoodSource", "-ownerUserId: Long?"],
                    ["+isVisibleTo(userId: Long): boolean", "+nutritionFor(qty: Decimal): Nutrition"], M, MB, "entity")
    n["WeightEntry"] = cls("WeightEntry", ["-weightId: Long", "-measurementDate: Date", "-weightKg: Decimal", "-note: String?"], ["+isInRange(): boolean"], M, MB, "entity")
    n["Reminder"] = cls("Reminder", ["-reminderId: Long", "-reminderType: ReminderType", "-reminderTime: Time", "-daysOfWeek: Set&lt;DayOfWeek&gt;", "-label: String?", "-isActive: boolean"],
                    ["+isDueAt(now: DateTime): boolean", "+setActive(on: boolean): void"], M, MB, "entity")
    n["WorkoutRoutine"] = cls("WorkoutRoutine", ["-routineId: Long", "-title: String", "-category: RoutineCategory", "-description: String?", "-createdAt: DateTime", "-updatedAt: DateTime"],
                    ["+addItem(i: RoutineExercise): void", "+isOwnedBy(userId: Long): boolean", "+copyFor(owner: User): WorkoutRoutine"], M, MB, "entity")
    n["RoutineExercise"] = cls("RoutineExercise", ["-itemId: Long", "-exerciseName: String", "-targetSets: int", "-targetRepetitions: int", "-targetResistance: Decimal?", "-sequenceNumber: int"], [], M, MB, "entity")
    n["RoutineShare"] = cls("RoutineShare", ["-shareId: Long", "-sharedAt: DateTime", "-revokedAt: DateTime?"], ["+isActive(): boolean", "+revoke(now: DateTime): void"], M, MB, "entity")
    n["FavoriteRoutine"] = cls("FavoriteRoutine", ["-favoriteId: Long", "-savedAt: DateTime"], [], M, MB, "entity")
    n["SmartRecommendation"] = cls("SmartRecommendation", ["-recommendationId: Long", "-ruleId: String", "-message: String", "-explanation: String", "-createdAt: DateTime", "-status: RecommendationStatus", "-dismissedAt: DateTime?"],
                    ["+dismiss(now: DateTime): void", "+suppressedAt(now: DateTime): boolean"], M, MB, "entity")
    enum = ('<<TABLE BORDER="1" COLOR="#777777" CELLBORDER="0" CELLSPACING="0" CELLPADDING="1" BGCOLOR="#F4F4F4">'
            '<TR><TD BGCOLOR="#777777"><FONT COLOR="white" POINT-SIZE="9">&#171;enumerations&#187;</FONT></TD></TR>'
            + "".join(f'<TR><TD ALIGN="LEFT"><FONT POINT-SIZE="8">{t}</FONT></TD></TR>' for t in [
              "GoalType: CALORIES, FREQUENCY, DURATION, WEIGHT", "GoalStatus: ACTIVE, INACTIVE",
              "ActivityType: RUNNING, WALKING, CYCLING, SWIMMING, STRENGTH, YOGA, HIIT, OTHER",
              "MealType: BREAKFAST, LUNCH, DINNER, SNACK", "RoutineCategory: STRENGTH, CARDIO, FLEXIBILITY, HIIT, MIXED, OTHER",
              "FoodSource: SYSTEM, CUSTOM", "ReminderType: WORKOUT, MEAL", "RecommendationStatus: ACTIVE, DISMISSED, EXPIRED"]) + '</TABLE>>')
    def stub(name, attrs):
        return cls(name, attrs, ["..."], "#F2F2F2", "#888888", "entity (see Figure 3)", 9)
    def graph(nodes, edges, ranks, extra=""):
        d = "digraph G {\n  " + HEAD + "\n"
        for k, v in nodes.items():
            d += f"  {k} [label={v}];\n"
        for e in edges: d += "  " + e + "\n"
        for r in ranks: d += "  {rank=same; " + "; ".join(r) + "}\n"
        return d + extra + "}"
    A = {k: n[k] for k in ["User","FitnessGoal","Reminder","WeightEntry"]}
    A["Enums"] = enum
    EA = [assoc("User","FitnessGoal","1","0..*","sets"), assoc("User","Reminder","1","0..10","schedules"), assoc("User","WeightEntry","1","0..*","records")]
    render("fig03_class_domain_account", graph(A, EA, [["Reminder","User","FitnessGoal"],["WeightEntry","Enums"]]))
    T = {k: n[k] for k in ["Workout","ExerciseEntry","MealEntry","Food"]}
    T["User"] = stub("User", ["-userId: Long", "-email: String"])
    ET = [assoc("User","Workout","1","0..*","logs"), assoc("User","MealEntry","1","0..*","logs"), assoc("User","Food","0..1","0..*","owns custom"),
          comp("Workout","ExerciseEntry","1","0..*","contains"), assoc("MealEntry","Food","0..*","1","uses")]
    render("fig04_class_domain_tracking", graph(T, ET, [["Workout","User","Food"],["ExerciseEntry","MealEntry"]]))
    B = {k: n[k] for k in ["WorkoutRoutine","RoutineExercise","RoutineShare","FavoriteRoutine","SmartRecommendation"]}
    B["User"] = stub("User", ["-userId: Long", "-email: String", "-preferredRoutineCategory: RoutineCategory?"])
    B["FitnessGoal"] = stub("FitnessGoal", ["-goalId: Long", "-goalType: GoalType"])
    EB = [assoc("User","WorkoutRoutine","1","0..*","owns"), assoc("User","FavoriteRoutine","1","0..*","stars"), assoc("User","RoutineShare","1","0..*","receives"),
          assoc("User","SmartRecommendation","1","0..*","receives"),
          comp("WorkoutRoutine","RoutineExercise","1","1..30","contains"), assoc("WorkoutRoutine","RoutineShare","1","0..*","shared via"),
          assoc("WorkoutRoutine","FavoriteRoutine","1","0..*","saved as"), assoc("SmartRecommendation","FitnessGoal","0..*","0..1","refers to"),
          assoc("SmartRecommendation","WorkoutRoutine","0..*","0..1","suggests")]
    render("fig05_class_domain_routines_coach", graph(B, EB, [["FitnessGoal","User","SmartRecommendation"],["RoutineShare","WorkoutRoutine","FavoriteRoutine"],["RoutineExercise"]]))

if __name__ == "__main__":
    domain()
    for f in ["fig03_class_domain_account","fig04_class_domain_tracking","fig05_class_domain_routines_coach"]:
        im = Image.open(f"{IMG}/{f}.png"); print(f, round(im.size[0]/220, 1), "x", round(im.size[1]/220, 1), "in")
