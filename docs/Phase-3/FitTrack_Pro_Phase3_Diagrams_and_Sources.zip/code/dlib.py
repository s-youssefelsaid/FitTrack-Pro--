"""python-docx helpers for the FitTrack Pro SDD."""
import re, os
from docx import Document
from docx.shared import Pt, Cm, RGBColor, Emu
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_LINE_SPACING, WD_TAB_ALIGNMENT, WD_TAB_LEADER
from docx.enum.section import WD_ORIENT, WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from PIL import Image

FONT = "Times New Roman"
TEAL = "1E6F66"
CHAR = "262626"

def _font(run_or_style, size=None, bold=None, italic=None, color=None):
    f = run_or_style.font
    f.name = FONT
    rpr = run_or_style.element.get_or_add_rPr() if hasattr(run_or_style.element, "get_or_add_rPr") else None
    el = run_or_style.element
    rPr = el.find(qn("w:rPr")) if el.find(qn("w:rPr")) is not None else None
    if size: f.size = Pt(size)
    if bold is not None: f.bold = bold
    if italic is not None: f.italic = italic
    if color: f.color.rgb = RGBColor.from_string(color)
    # east-asian / cs font names so Word never substitutes
    r = run_or_style.element.get_or_add_rPr() if hasattr(run_or_style.element, "get_or_add_rPr") else run_or_style.element.find(qn("w:rPr"))
    if r is not None:
        rf = r.find(qn("w:rFonts"))
        if rf is None:
            rf = OxmlElement("w:rFonts"); r.insert(0, rf)
        for a in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
            rf.set(qn(a), FONT)

class Doc:
    def __init__(self):
        self.d = Document()
        self.fig_n = 0
        self.tbl_n = 0
        self.headings = []       # (level, text)
        self.toc_pages = {}      # text -> page (filled on pass 2)
        self._styles()
        s = self.d.sections[0]
        s.page_width, s.page_height = Cm(21.0), Cm(29.7)
        s.left_margin = s.right_margin = Cm(2.0)
        s.top_margin, s.bottom_margin = Cm(2.3), Cm(2.0)
        s.header_distance = Cm(1.0); s.footer_distance = Cm(0.9)
        s.different_first_page_header_footer = True

    # ------------------------------------------------------------ styles
    def _styles(self):
        st = self.d.styles
        n = st["Normal"]; _font(n, 12)
        pf = n.paragraph_format
        pf.line_spacing = 1.5; pf.space_after = Pt(6); pf.space_before = Pt(0)
        n.element.get_or_add_pPr()
        for name, size, before, after in (("Heading 1", 16, 0, 10), ("Heading 2", 14, 12, 4), ("Heading 3", 12, 10, 3)):
            h = st[name]; _font(h, size, True, False, "000000")
            h.paragraph_format.space_before = Pt(before); h.paragraph_format.space_after = Pt(after)
            h.paragraph_format.keep_with_next = True; h.paragraph_format.line_spacing = 1.15
        st["Heading 3"].font.italic = False
        st["Header"].paragraph_format.tab_stops.clear_all(); st["Footer"].paragraph_format.tab_stops.clear_all()
        for nm in ("Caption",):
            c = st[nm]; _font(c, 10, True, False, "000000")
            c.paragraph_format.space_before = Pt(3); c.paragraph_format.space_after = Pt(10); c.paragraph_format.line_spacing = 1.0
        for lvl, ind in ((1, 0), (2, 0.6), (3, 1.2)):
            try:
                t = st[f"TOC {lvl}"]
            except KeyError:
                t = st.add_style(f"TOC {lvl}", 1)
            _font(t, 12 if lvl == 1 else 11, lvl == 1)
            t.paragraph_format.left_indent = Cm(ind); t.paragraph_format.space_after = Pt(2 if lvl > 1 else 3)
            t.paragraph_format.line_spacing = 1.15
            t.paragraph_format.tab_stops.add_tab_stop(Cm(17.0), WD_TAB_ALIGNMENT.RIGHT, WD_TAB_LEADER.DOTS)
        for nm in ("List Bullet",):
            b = st[nm]; _font(b, 12); b.paragraph_format.line_spacing = 1.5; b.paragraph_format.space_after = Pt(2)

    # ------------------------------------------------------------ low level
    def _runs(self, p, text, size=None, color=None, italic=None):
        """**bold**, *italic*, `code` markup."""
        for part in re.split(r"(\*\*.+?\*\*|`.+?`|__.+?__)", text):
            if not part: continue
            if part.startswith("**"):
                r = p.add_run(part[2:-2]); _font(r, size, True, italic, color)
            elif part.startswith("__"):
                r = p.add_run(part[2:-2]); _font(r, size, None, True, color)
            elif part.startswith("`"):
                r = p.add_run(part[1:-1]); _font(r, size, None, italic, color)
                r.font.name = "Courier New"
                rf = r.element.get_or_add_rPr().find(qn("w:rFonts"))
                for a in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"): rf.set(qn(a), "Courier New")
            else:
                r = p.add_run(part); _font(r, size, None, italic, color)

    def field(self, p, instr, cached="1", size=None, bold=None):
        def mk(t):
            r = p.add_run(); _font(r, size, bold)
            fc = OxmlElement("w:fldChar"); fc.set(qn("w:fldCharType"), t); r._r.append(fc); return r
        mk("begin")
        r = p.add_run(); _font(r, size, bold)
        it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = f" {instr} "; r._r.append(it)
        mk("separate")
        r = p.add_run(cached); _font(r, size, bold)
        mk("end")

    # ------------------------------------------------------------ text blocks
    def h(self, level, text, page_break=False, toc=True):
        p = self.d.add_paragraph(style=f"Heading {level}")
        if page_break: p.paragraph_format.page_break_before = True
        r = p.add_run(text); _font(r)
        if toc: self.headings.append((level, text))
        return p

    def p(self, text, size=None, align=None, after=None, keep=False, italic=None, spacing=None):
        p = self.d.add_paragraph()
        self._runs(p, text, size, None, italic)
        if align == "center": p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        elif align == "justify": p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        if after is not None: p.paragraph_format.space_after = Pt(after)
        if keep: p.paragraph_format.keep_with_next = True
        if spacing: p.paragraph_format.line_spacing = spacing
        return p

    def bullets(self, items, size=None, spacing=None):
        for t in items:
            p = self.d.add_paragraph(style="List Bullet")
            self._runs(p, t, size)
            if spacing: p.paragraph_format.line_spacing = spacing

    def pagebreak(self):
        self.d.add_paragraph().add_run().add_break(WD_BREAK.PAGE)

    def _caption(self, kind, n, title, above=False):
        p = self.d.add_paragraph(style="Caption")
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.keep_with_next = above
        r = p.add_run(f"{kind} "); _font(r, 10, True)
        self.field(p, f"SEQ {kind} \\* ARABIC", str(n), 10, True)
        r = p.add_run(f" – {title}"); _font(r, 10, True)
        return p

    # ------------------------------------------------------------ figures
    def figure(self, path, title, max_w_cm=17.0, max_h_cm=21.5, dpi=300):
        self.fig_n += 1
        im = Image.open(path)
        w, h = im.size
        scale = min(max_w_cm / 2.54 * 1.0 / (w / 96.0 * 0 + 1) / w * w, 1)  # placeholder, real fit below
        wcm = max_w_cm; hcm = wcm * h / w
        if hcm > max_h_cm: hcm = max_h_cm; wcm = hcm * w / h
        # downsample to the print size at `dpi`
        tw = int(wcm / 2.54 * dpi)
        if tw < w:
            im = im.convert("RGB").resize((tw, int(tw * h / w)), Image.LANCZOS)
            tmp = f"/tmp/_fig{self.fig_n}.png"; im.save(tmp, optimize=True); path = tmp
        p = self.d.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.keep_with_next = True; p.paragraph_format.space_after = Pt(2); p.paragraph_format.line_spacing = 1.0
        p.add_run().add_picture(path, width=Cm(wcm))
        self._caption("Figure", self.fig_n, title)
        return self.fig_n

    # ------------------------------------------------------------ tables
    def _shade(self, cell, fill):
        tcPr = cell._tc.get_or_add_tcPr()
        sh = OxmlElement("w:shd"); sh.set(qn("w:val"), "clear"); sh.set(qn("w:color"), "auto"); sh.set(qn("w:fill"), fill); tcPr.append(sh)

    def _borders(self, tbl, color="808080"):
        tblPr = tbl._tbl.tblPr
        b = OxmlElement("w:tblBorders")
        for e in ("top", "left", "bottom", "right", "insideH", "insideV"):
            x = OxmlElement(f"w:{e}"); x.set(qn("w:val"), "single"); x.set(qn("w:sz"), "4"); x.set(qn("w:space"), "0"); x.set(qn("w:color"), color); b.append(x)
        tblPr.append(b)

    def table(self, headers, rows, widths_cm, size=9, title=None, first_bold=False, zebra=True, header_fill=CHAR, split_rows=True, mono_cols=(), break_before=False):
        if title:
            self.tbl_n += 1
            cp = self._caption("Table", self.tbl_n, title, above=True)
            if break_before: cp.paragraph_format.page_break_before = True
        t = self.d.add_table(rows=1, cols=len(headers))
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        t.autofit = False
        self._borders(t)
        tblPr = t._tbl.tblPr
        lay = OxmlElement("w:tblLayout"); lay.set(qn("w:type"), "fixed"); tblPr.append(lay)
        cm = OxmlElement("w:tblCellMar")
        for side, v in (("top", 30), ("left", 70), ("bottom", 30), ("right", 70)):
            e = OxmlElement(f"w:{side}"); e.set(qn("w:w"), str(v)); e.set(qn("w:type"), "dxa"); cm.append(e)
        tblPr.append(cm)
        def fill(cell, text, hdr=False, bold=False, mono=False):
            cell.text = ""
            lines = str(text).split("\n")
            for i, ln in enumerate(lines):
                para = cell.paragraphs[0] if i == 0 else cell.add_paragraph()
                pf = para.paragraph_format; pf.line_spacing = 1.0; pf.space_after = Pt(1.5 if len(lines) > 1 else 0); pf.space_before = Pt(0)
                if hdr:
                    r = para.add_run(ln); _font(r, size, True, None, "FFFFFF")
                elif mono:
                    r = para.add_run(ln); _font(r, size - 0.5)
                    r.font.name = "Courier New"
                    rf = r._r.get_or_add_rPr().find(qn("w:rFonts"))
                    for a in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"): rf.set(qn(a), "Courier New")
                else:
                    self._runs(para, ("**" + ln + "**") if (bold and ln and "**" not in ln) else ln, size)
        for i, h_ in enumerate(headers):
            c = t.rows[0].cells[i]; fill(c, h_, hdr=True); self._shade(c, header_fill)
        trPr = t.rows[0]._tr.get_or_add_trPr()
        th = OxmlElement("w:tblHeader"); th.set(qn("w:val"), "true"); trPr.append(th)
        cs = OxmlElement("w:cantSplit"); cs.set(qn("w:val"), "true"); trPr.append(cs)
        for ri, row in enumerate(rows):
            cells = t.add_row().cells
            for i, v in enumerate(row):
                fill(cells[i], v, bold=(first_bold and i == 0), mono=(i in mono_cols))
                if zebra and ri % 2 == 1: self._shade(cells[i], "F2F2F2")
            if not split_rows:
                trPr = t.rows[-1]._tr.get_or_add_trPr()
                cs = OxmlElement("w:cantSplit"); cs.set(qn("w:val"), "true"); trPr.append(cs)
        for row in t.rows:
            for i, w in enumerate(widths_cm):
                row.cells[i].width = Cm(w)
        # grid
        grid = t._tbl.tblGrid
        for i, gc in enumerate(grid.findall(qn("w:gridCol"))):
            gc.set(qn("w:w"), str(int(widths_cm[i] / 2.54 * 1440)))
        sp = self.d.add_paragraph(); sp.paragraph_format.space_after = Pt(4); sp.paragraph_format.line_spacing = 1.0
        for r in sp.runs: r.font.size = Pt(4)
        return t

    # ------------------------------------------------------------ sections / header-footer
    def header_footer(self, section, header_text, right_text):
        section.header.is_linked_to_previous = False
        section.footer.is_linked_to_previous = False
        hp = section.header.paragraphs[0]; hp.text = ""
        width = section.page_width - section.left_margin - section.right_margin
        hp.paragraph_format.tab_stops.add_tab_stop(width, WD_TAB_ALIGNMENT.RIGHT)
        r = hp.add_run(header_text + "\t" + right_text); _font(r, 9, None, None, "404040")
        hp.paragraph_format.line_spacing = 1.0; hp.paragraph_format.space_after = Pt(0)
        pPr = hp._p.get_or_add_pPr(); bd = OxmlElement("w:pBdr"); b = OxmlElement("w:bottom")
        b.set(qn("w:val"), "single"); b.set(qn("w:sz"), "6"); b.set(qn("w:space"), "3"); b.set(qn("w:color"), "808080"); bd.append(b); pPr.append(bd)
        fp = section.footer.paragraphs[0]; fp.text = ""
        fp.alignment = WD_ALIGN_PARAGRAPH.CENTER; fp.paragraph_format.line_spacing = 1.0
        r = fp.add_run("FitTrack Pro – Phase 3 SDD  |  Page "); _font(r, 9, None, None, "404040")
        self.field(fp, "PAGE", "1", 9)
        # first-page header/footer left empty
        section.first_page_header.is_linked_to_previous = False
        section.first_page_footer.is_linked_to_previous = False

    def new_section(self, landscape=False):
        s = self.d.add_section(WD_SECTION.NEW_PAGE)
        s.different_first_page_header_footer = False
        if landscape:
            s.orientation = WD_ORIENT.LANDSCAPE
            s.page_width, s.page_height = Cm(29.7), Cm(21.0)
            s.left_margin = s.right_margin = Cm(1.8); s.top_margin = Cm(2.2); s.bottom_margin = Cm(1.8)
        else:
            s.orientation = WD_ORIENT.PORTRAIT
            s.page_width, s.page_height = Cm(21.0), Cm(29.7)
            s.left_margin = s.right_margin = Cm(2.0); s.top_margin = Cm(2.3); s.bottom_margin = Cm(2.0)
        s.header_distance = Cm(1.0); s.footer_distance = Cm(0.9)
        return s

    # ------------------------------------------------------------ TOC
    def toc(self, max_level=3):
        """Real TOC field whose cached result is pre-populated from self.toc_pages."""
        entries = getattr(self, "toc_entries", [])
        first = True
        for i, (lvl, text) in enumerate(entries):
            p = self.d.add_paragraph(style=f"TOC {lvl}")
            if first:
                r = p.add_run(); _font(r)
                fc = OxmlElement("w:fldChar"); fc.set(qn("w:fldCharType"), "begin"); r._r.append(fc)
                r = p.add_run(); it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = f' TOC \\o "1-{max_level}" \\h \\z \\u '; r._r.append(it)
                r = p.add_run(); fc = OxmlElement("w:fldChar"); fc.set(qn("w:fldCharType"), "separate"); r._r.append(fc)
                first = False
            r = p.add_run(text + "\t" + str(self.toc_pages.get(text, "0"))); _font(r, 12 if lvl == 1 else 11, lvl == 1)
            if i == len(entries) - 1:
                r = p.add_run(); fc = OxmlElement("w:fldChar"); fc.set(qn("w:fldCharType"), "end"); r._r.append(fc)
        if not entries:
            self.p("[table of contents]")

    def save(self, path):
        self.d.save(path)
